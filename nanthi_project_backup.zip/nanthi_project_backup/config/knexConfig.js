const path = require("path");

const defaultDbConfig = {
  client: "pg",
  pool: {
    min: Math.trunc(process.env.DB_MIN_CONNECTION || 2),
    max: Math.trunc(process.env.DB_MAX_CONNECTION || 10)
  },
  acquireConnectionTimeout: 10000,
  migrations: {
    tableName: "knex_migrations",
    directory: path.resolve(__dirname, "../migrations")
  }
};

const scmDbConfig = {
  ...defaultDbConfig,
  connection: {
    host: process.env.DB_HOST,
    user: process.env.SCM_DB_USER,
    password: process.env.SCM_DB_PASSWORD,
    database: process.env.SCM_DB_NAME,
    port: Number(process.env.DB_PORT),
    connectionTimeoutMillis: Math.trunc(process.env.DB_CONNECTION_TIMEOUT),
    statementTimeout: Math.trunc(process.env.DB_STATEMENT_TIMEOUT)
  },
  asyncStackTraces: false,
  debug: false
};

module.exports = {
  scmDbConfig
};
