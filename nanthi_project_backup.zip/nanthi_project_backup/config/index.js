const { scmDbConfig } = require("./knexConfig");

module.exports = {
  scmDbConfig
};
