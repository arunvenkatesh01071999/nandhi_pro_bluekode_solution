const getMenuHandler = require("./getMenuHandler");
const menuListHandler = require("./menuListHandler");
const postMenuHandler = require("./postMenuHandler");
const putMenuHandler = require("./putMenuHandler");
const deleteMenuHandler = require("./deleteMenuHandler");

module.exports = {
  getMenuHandler,
  menuListHandler,
  postMenuHandler,
  putMenuHandler,
  deleteMenuHandler
};
