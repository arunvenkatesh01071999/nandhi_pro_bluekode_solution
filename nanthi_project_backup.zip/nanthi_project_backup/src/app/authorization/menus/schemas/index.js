const getMenuSchema = require("./getMenuSchema");
const menuListSchema = require("./menuListSchema");
const postMenuSchema = require("./postMenuSchema");
const putMenuSchema = require("./putMenuSchema");
const deleteMenuSchema = require("./deleteMenuSchema");

module.exports = {
  getMenuSchema,
  menuListSchema,
  postMenuSchema,
  putMenuSchema,
  deleteMenuSchema
};
