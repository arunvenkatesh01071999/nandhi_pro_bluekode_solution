const { errorSchemas } = require("../../../commons/schemas/errorSchemas");

const postMenuSchema = {
  tags: ["POST MENU"],
  summary: "This API is to post menu",
  headers: { $ref: "request-headers#" },
  body: {
    type: "object",
    required: [
      "menu_name",
      "menu_icon",
      "menu_url",
      "menu_order",
      "company_id"
    ],
    properties: {
      menu_name: { type: "string" },
      menu_icon: { type: "string" },
      menu_url: { type: "string" },
      menu_order: { type: "string" },
      company_id: { type: "integer" }
    }
  },
  response: {
    200: {
      type: "object",
      properties: {
        success: { type: "boolean" }
      }
    },
    ...errorSchemas
  }
};

module.exports = postMenuSchema;
