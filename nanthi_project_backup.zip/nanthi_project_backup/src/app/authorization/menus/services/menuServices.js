const menuRepo = require("../repository/menu");

function getMenuService(fastify) {
  const { getMenu } = menuRepo(fastify);

  return async ({ params, body, logTrace, userDetails }) => {
    const knex = fastify.knexMedical;
    const response = await getMenu.call(knex, {
      params,
      body,
      logTrace
    });
    return response;
  };
}
function postMenuService(fastify) {
  const { postMenu } = menuRepo(fastify);
  return async ({ params, body, logTrace, userDetails }) => {
    const knex = fastify.knexMedical;
    const promise1 = postMenu.call(knex, {
      params,
      body,
      logTrace,
      userDetails
    });
    const [response] = await Promise.all([promise1]);
    return response;
  };
}
function putMenuService(fastify) {
  const { putMenu } = menuRepo(fastify);
  return async ({ params, body, logTrace, userDetails }) => {
    const knex = fastify.knexMedical;
    const { menu_id } = params;
    const promise1 = putMenu.call(knex, {
      menu_id,
      body,
      logTrace,
      userDetails
    });
    const [response] = await Promise.all([promise1]);
    return response;
  };
}
function deleteMenuService(fastify) {
  const { deleteMenu } = menuRepo(fastify);
  return async ({ params, body, logTrace }) => {
    const knex = fastify.knexMedical;
    const { menu_id } = params;
    const promise1 = deleteMenu.call(knex, {
      menu_id,
      params,
      body,
      logTrace
    });
    const [response] = await Promise.all([promise1]);
    return response;
  };
}

function menuListService(fastify) {
  const { menuList } = menuRepo(fastify);

  return async ({ params, body, logTrace }) => {
    const knex = fastify.knexMedical;
    const response = await menuList.call(knex, {
      params,
      body,
      logTrace
    });
    return response;
  };
}

module.exports = {
  getMenuService,
  menuListService,
  postMenuService,
  putMenuService,
  deleteMenuService
};
