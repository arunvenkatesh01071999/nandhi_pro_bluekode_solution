const schemas = require("../schemas");
const handlers = require("../handlers");

module.exports = async fastify => {
  fastify.route({
    method: "GET",
    url: "/menuauth/list/:company_id/:role_id/:user_id?",
    schema: schemas.menuAuthListSchema,
    preHandler: fastify.authenticate,
    handler: handlers.menuAuthListHandler(fastify)
  });
  fastify.route({
    method: "POST",
    url: "/menuauth",
    schema: schemas.postMenuAuthSchema,
    preHandler: fastify.authenticate,
    handler: handlers.postMenuAuthHandler(fastify)
  });
  fastify.route({
    method: "GET",
    url: "/menuauth/all/:company_id",
    schema: schemas.menuAuthAllListSchema,
    preHandler: fastify.authenticate,
    handler: handlers.menuAuthAllListHandler(fastify)
  });
};
