const menuAuthRepo = require("../repository/menuauth");

function postMenuAuthService(fastify) {
  const { postMenuAuth } = menuAuthRepo(fastify);
  return async ({ params, body, logTrace, userDetails }) => {
    const knex = fastify.knexMedical;
    const promise1 = postMenuAuth.call(knex, {
      params,
      body,
      logTrace,
      userDetails
    });
    const [response] = await Promise.all([promise1]);
    return response;
  };
}
function menuAuthListService(fastify) {
  const { menuAuthList } = menuAuthRepo(fastify);
  return async ({ params, body, logTrace, userDetails }) => {
    const knex = fastify.knexMedical;
    const promise1 = menuAuthList.call(knex, {
      params,
      body,
      logTrace,
      userDetails
    });
    const [response] = await Promise.all([promise1]);
    // Transform the response data before returning
    const transformedResponse = transformMenuData(response);

    return transformedResponse;
  };
}
function transformMenuData(inputData) {
  const transformedData = [];

  // Grouping the data by menu_id
  const groupedData = inputData.reduce((acc, item) => {
    const key = item.menu_id;
    if (!acc[key]) {
      acc[key] = [];
    }
    acc[key].push(item);
    return acc;
  }, {});

  // Creating the final structure
  Object.keys(groupedData).forEach(menuId => {
    const menuItems = groupedData[menuId];
    const menu = {
      menu_id: menuId,
      menu_name: menuItems[0].menu_name,
      menu_icon: menuItems[0].menu_icon,
      menu_url: menuItems[0].menu_url,
      menu_order: menuItems[0].menu_order,
      submenus: menuItems.map(submenu => ({
        submenu_id: submenu.submenu_id,
        sub_menu_name: submenu.sub_menu_name,
        sub_menu_icon: submenu.sub_menu_icon,
        sub_menu_url: submenu.sub_menu_url,
        sub_menu_order: submenu.sub_menu_order
      }))
    };

    transformedData.push(menu);
  });

  return transformedData;
}
function menuAuthAllListService(fastify) {
  const { menuAuthAllList } = menuAuthRepo(fastify);
  return async ({ params, body, logTrace, userDetails }) => {
    const knex = fastify.knexMedical;
    const promise1 = menuAuthAllList.call(knex, {
      params,
      body,
      logTrace,
      userDetails
    });
    const [response] = await Promise.all([promise1]);
    // Transform the response data before returning
    const transformedResponse = transformMenuData(response);

    return transformedResponse;
  };
}
module.exports = {
  postMenuAuthService,
  menuAuthListService,
  menuAuthAllListService
};
