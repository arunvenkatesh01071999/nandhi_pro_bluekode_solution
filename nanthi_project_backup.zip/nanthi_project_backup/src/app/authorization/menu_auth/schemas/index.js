const postMenuAuthSchema = require("./postMenuAuthSchema");
const menuAuthListSchema = require("./menuAuthListSchema");
const menuAuthAllListSchema = require("./menuAuthAllListSchema");

module.exports = {
  postMenuAuthSchema,
  menuAuthListSchema,
  menuAuthAllListSchema
};
