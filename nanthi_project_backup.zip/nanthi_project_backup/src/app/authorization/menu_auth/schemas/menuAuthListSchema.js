const { errorSchemas } = require("../../../commons/schemas/errorSchemas");

const menuListSchema = {
  tags: ["MENU AUTH LIST"],
  summary: "This API is to fetch menu auth list",
  headers: { $ref: "request-headers#" },
  params: {
    type: "object",
    properties: {
      company_id: { type: "integer" },
      role_id: { type: "integer" }
    }
  },
  response: {
    200: {
      type: "array",
      items: {
        type: "object",
        properties: {
          menu_id: { type: "integer" },
          menu_name: { type: "string" },
          menu_icon: { type: "string" },
          menu_url: { type: "string" },
          menu_order: { type: "integer" },
          submenus: {
            type: "array",
            items: {
              type: "object",
              properties: {
                submenu_id: { type: "integer" },
                sub_menu_name: { type: "string" },
                sub_menu_icon: { type: "string" },
                sub_menu_url: { type: "string" },
                sub_menu_order: { type: "integer" }
              }
            }
          }
        }
      },
      meta: { $ref: "response-meta#" }
    },

    ...errorSchemas
  }
};

module.exports = menuListSchema;
