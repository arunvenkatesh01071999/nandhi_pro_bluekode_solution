const { errorSchemas } = require("../../../commons/schemas/errorSchemas");

const postMenuAuthSchema = {
  tags: ["POST MENUAUTH"],
  summary: "This API is to post menuauth",
  headers: { $ref: "request-headers#" },
  body: {
    type: "object",
    required: ["role_id", "menu_id", "submenu_id", "company_id", "checked"],

    properties: {
      role_id: { type: "integer" },
      user_id: { type: "integer" },
      menu_id: { type: "integer" },
      submenu_id: { type: "integer" },
      checked: { type: "boolean" },
      company_id: { type: "integer" }
    }
  },
  response: {
    200: {
      type: "object",
      properties: {
        success: { type: "boolean" }
      }
    },
    ...errorSchemas
  }
};

module.exports = postMenuAuthSchema;
