const { StatusCodes } = require("http-status-codes");
const { CustomError } = require("../../../errorHandler");
const { logQuery } = require("../../../commons/helpers");
const { MENU } = require("../../menus/commons/constants");
const { SUBMENU } = require("../../menus/commons/constants");
const { MENU_AUTH } = require("../../menus/commons/constants");

function menuAuthRepo(fastify) {
  async function postMenuAuth({ params, body, logTrace, userDetails }) {
    const knex = this;
    const created_by = userDetails.id;
    const query = knex(MENU_AUTH.NAME)
      .where(MENU_AUTH.COLUMNS.ROLE_ID, body.role_id)
      .where(MENU_AUTH.COLUMNS.USER_ID, body.user_id || 0)
      .where(MENU_AUTH.COLUMNS.MENU_ID, body.menu_id)
      .where(MENU_AUTH.COLUMNS.SUBMENU_ID, body.submenu_id)
      .where(MENU_AUTH.COLUMNS.COMPANY_ID, body.company_id);

    const exists_response = await query;

    if (exists_response.length > 0) {
      const query_delete1 = await knex(MENU_AUTH.NAME)
        .where(MENU_AUTH.COLUMNS.ROLE_ID, body.role_id)
        .where(MENU_AUTH.COLUMNS.USER_ID, body.user_id || 0)
        .where(MENU_AUTH.COLUMNS.MENU_ID, body.menu_id)
        .where(MENU_AUTH.COLUMNS.SUBMENU_ID, body.submenu_id)
        .where(MENU_AUTH.COLUMNS.COMPANY_ID, body.company_id)
        .del();
      if (!query_delete1) {
        throw CustomError.create({
          httpCode: StatusCodes.NOT_IMPLEMENTED,
          message: "Error while menu authenticate",
          property: "",
          code: "NOT_IMPLEMENTED"
        });
      }
      return { success: true };
    }

    const query_insert = await knex(`${MENU_AUTH.NAME}`).insert({
      [MENU_AUTH.COLUMNS.ROLE_ID]: body.role_id,
      [MENU_AUTH.COLUMNS.USER_ID]: body.user_id || 0,
      [MENU_AUTH.COLUMNS.MENU_ID]: body.menu_id,
      [MENU_AUTH.COLUMNS.SUBMENU_ID]: body.submenu_id,
      [MENU_AUTH.COLUMNS.COMPANY_ID]: body.company_id,
      [SUBMENU.COLUMNS.CREATED_BY]: created_by,
      [SUBMENU.COLUMNS.UPDATED_BY]: created_by
    });

    const response = await query_insert;

    if (!response) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_IMPLEMENTED,
        message: "Error while creating menu authenticate",
        property: "",
        code: "NOT_IMPLEMENTED"
      });
    }

    return { success: true };
  }
  async function menuAuthList({ params, body, logTrace, userDetails }) {
    const knex = this;
    const query = knex
      .select([
        `${MENU_AUTH.NAME}.${MENU_AUTH.COLUMNS.MENU_ID}`,
        `${MENU.NAME}.${MENU.COLUMNS.MENU_NAME}`,
        `${MENU.NAME}.${MENU.COLUMNS.MENU_ICON}`,
        `${MENU.NAME}.${MENU.COLUMNS.MENU_URL}`,
        `${MENU.NAME}.${MENU.COLUMNS.MENU_ORDER}`,
        `${MENU_AUTH.NAME}.${MENU_AUTH.COLUMNS.SUBMENU_ID}`,
        `${SUBMENU.NAME}.${SUBMENU.COLUMNS.SUBMENU_NAME}`,
        `${SUBMENU.NAME}.${SUBMENU.COLUMNS.SUBMENU_URL}`,
        `${SUBMENU.NAME}.${SUBMENU.COLUMNS.SUBMENU_ICON}`,
        `${SUBMENU.NAME}.${SUBMENU.COLUMNS.SUBMENU_ORDER}`
      ])
      .from(`${MENU_AUTH.NAME} as ${MENU_AUTH.NAME}`)
      .leftJoin(
        `${MENU.NAME} as ${MENU.NAME}`,
        `${MENU_AUTH.NAME}.${MENU_AUTH.COLUMNS.MENU_ID}`,
        `${MENU.NAME}.${MENU.COLUMNS.ID}`
      )
      .leftJoin(
        `${SUBMENU.NAME} as ${SUBMENU.NAME}`,
        `${MENU_AUTH.NAME}.${MENU_AUTH.COLUMNS.SUBMENU_ID}`,
        `${SUBMENU.NAME}.${SUBMENU.COLUMNS.ID}`
      )
      .where(
        `${MENU_AUTH.NAME}.${MENU_AUTH.COLUMNS.COMPANY_ID}`,
        params.company_id
      )
      .where(`${MENU_AUTH.NAME}.${MENU_AUTH.COLUMNS.ROLE_ID}`, params.role_id)
      .orderBy(`${MENU_AUTH.NAME}.${MENU_AUTH.COLUMNS.MENU_ID}`, "ASC")
      .orderBy(`${MENU_AUTH.NAME}.${MENU_AUTH.COLUMNS.SUBMENU_ID}`, "ASC");

    const response = await query;

    if (response.length === 0) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "Menu authentication not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
    return response;
  }
  async function menuAuthAllList({ params, body, logTrace, userDetails }) {
    const knex = this;

    const query = knex
      .select([
        `${MENU.NAME}.${MENU_AUTH.COLUMNS.ID} as menu_id`,
        `${MENU.NAME}.${MENU.COLUMNS.MENU_NAME}`,
        `${MENU.NAME}.${MENU.COLUMNS.MENU_ICON}`,
        `${MENU.NAME}.${MENU.COLUMNS.MENU_URL}`,
        `${MENU.NAME}.${MENU.COLUMNS.MENU_ORDER}`,
        `${SUBMENU.NAME}.${SUBMENU.COLUMNS.ID} as submenu_id`,
        `${SUBMENU.NAME}.${SUBMENU.COLUMNS.SUBMENU_NAME}`,
        `${SUBMENU.NAME}.${SUBMENU.COLUMNS.SUBMENU_URL}`,
        `${SUBMENU.NAME}.${SUBMENU.COLUMNS.SUBMENU_ICON}`,
        `${SUBMENU.NAME}.${SUBMENU.COLUMNS.SUBMENU_ORDER}`
      ])
      .from(`${SUBMENU.NAME} as ${SUBMENU.NAME}`)
      .leftJoin(
        `${MENU.NAME} as ${MENU.NAME}`,
        `${SUBMENU.NAME}.${SUBMENU.COLUMNS.MENU_ID}`,
        `${MENU.NAME}.${MENU.COLUMNS.ID}`
      )
      .where(
        `${SUBMENU.NAME}.${SUBMENU.COLUMNS.COMPANY_ID}`,
        params.company_id
      )
      .orderBy(`${MENU.NAME}.${MENU.COLUMNS.MENU_ORDER}`, "ASC");


    // const query = knex
    //   .select([
    //     `${MENU_AUTH.NAME}.${MENU_AUTH.COLUMNS.MENU_ID}`,
    //     `${MENU.NAME}.${MENU.COLUMNS.MENU_NAME}`,
    //     `${MENU.NAME}.${MENU.COLUMNS.MENU_ICON}`,
    //     `${MENU.NAME}.${MENU.COLUMNS.MENU_URL}`,
    //     `${MENU.NAME}.${MENU.COLUMNS.MENU_ORDER}`,
    //     `${SUBMENU.NAME}.${SUBMENU.COLUMNS.ID} as submenu_id`,
    //     `${SUBMENU.NAME}.${SUBMENU.COLUMNS.SUBMENU_NAME}`,
    //     `${SUBMENU.NAME}.${SUBMENU.COLUMNS.SUBMENU_URL}`,
    //     `${SUBMENU.NAME}.${SUBMENU.COLUMNS.SUBMENU_ICON}`,
    //     `${SUBMENU.NAME}.${SUBMENU.COLUMNS.SUBMENU_ORDER}`
    //   ])
    //   .from(`${SUBMENU.NAME} as ${SUBMENU.NAME}`)
    //   .leftJoin(
    //     `${MENU.NAME} as ${MENU.NAME}`,
    //     `${MENU_AUTH.NAME}.${MENU_AUTH.COLUMNS.MENU_ID}`,
    //     `${MENU.NAME}.${MENU.COLUMNS.ID}`
    //   )
    //   .leftJoin(
    //     `${SUBMENU.NAME} as ${SUBMENU.NAME}`,
    //     `${MENU_AUTH.NAME}.${MENU_AUTH.COLUMNS.SUBMENU_ID}`,
    //     `${SUBMENU.NAME}.${SUBMENU.COLUMNS.ID}`
    //   )
    //   .where(
    //     `${MENU_AUTH.NAME}.${MENU_AUTH.COLUMNS.COMPANY_ID}`,
    //     params.company_id
    //   )
    //   .where(`${MENU_AUTH.NAME}.${MENU_AUTH.COLUMNS.ROLE_ID}`, params.role_id)
    //   .orderBy(`${MENU_AUTH.NAME}.${MENU_AUTH.COLUMNS.MENU_ID}`, "ASC")
    //   .orderBy(`${MENU_AUTH.NAME}.${MENU_AUTH.COLUMNS.SUBMENU_ID}`, "ASC");

    const response = await query;

    if (response.length === 0) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "Menu authentication not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
    return response;
  }
  return {
    postMenuAuth,
    menuAuthList,
    menuAuthAllList
  };
}

module.exports = menuAuthRepo;
