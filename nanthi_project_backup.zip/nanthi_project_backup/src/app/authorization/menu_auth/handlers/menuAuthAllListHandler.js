const menuServices = require("../services/menuauthServices");

function menuAuthAllListHandler(fastify) {
    const menuAuthAllList = menuServices.menuAuthAllListService(fastify);
    return async (request, reply) => {
        const { body, params, logTrace, userDetails } = request;
        const response = await menuAuthAllList({
            body,
            params,
            logTrace,
            userDetails
        });
        return reply.code(200).send(response);
    };
}

module.exports = menuAuthAllListHandler;
