const menuServices = require("../services/submenuServices");

function getSubMenuHandler(fastify) {
  const getSubMenu = menuServices.getSubMenuService(fastify);
  return async (request, reply) => {
    const { body, params, logTrace, userDetails } = request;
    const response = await getSubMenu({
      body,
      params,
      logTrace,
      userDetails
    });
    return reply.code(200).send(response);
  };
}

module.exports = getSubMenuHandler;
