const getSubMenuHandler = require("./getSubMenuHandler");
const submenuListHandler = require("./submenuListHandler");
const postSubMenuHandler = require("./postSubMenuHandler");
const putSubMenuHandler = require("./putSubMenuHandler");
const deleteSubMenuHandler = require("./deleteSubMenuHandler");

module.exports = {
  getSubMenuHandler,
  submenuListHandler,
  postSubMenuHandler,
  putSubMenuHandler,
  deleteSubMenuHandler
};
