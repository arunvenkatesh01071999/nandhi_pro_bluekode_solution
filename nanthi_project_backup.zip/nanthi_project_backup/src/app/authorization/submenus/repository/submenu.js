const { StatusCodes } = require("http-status-codes");
const { CustomError } = require("../../../errorHandler");
const { logQuery } = require("../../../commons/helpers");
const { MENU } = require("../../menus/commons/constants");
const { SUBMENU } = require("../../menus/commons/constants");

function submenuRepo(fastify) {
  async function getSubMenu({ body, params, logTrace }) {
    const knex = this;

    const query = knex
      .select([`${SUBMENU.NAME}.*`, `${MENU.NAME}.${MENU.COLUMNS.MENU_NAME}`])
      .from(`${SUBMENU.NAME} as ${SUBMENU.NAME}`)
      .leftJoin(
        `${MENU.NAME} as ${MENU.NAME}`,
        `${SUBMENU.NAME}.${SUBMENU.COLUMNS.MENU_ID}`,
        `${MENU.NAME}.${MENU.COLUMNS.ID}`
      )
      .where(
        `${SUBMENU.NAME}.${SUBMENU.COLUMNS.COMPANY_ID}`,
        params.company_id
      );
    logQuery({
      logger: fastify.log,
      query,
      context: "Get SubMenus",
      logTrace
    });

    if (params.search && params.search.length >= 1) {
      query.where(SUBMENU.COLUMNS.SUBMENU_NAME, "ilike", `%${params.search}%`);
    }
    const response = await query.paginate({
      pageSize: params.page_size, // Customize as needed
      currentPage: params.current_page // Customize as needed
    });
    if (response.meta.pagination.total_pages < params.current_page) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_ACCEPTABLE,
        message: "Requested page is beyond the available data",
        property: "",
        code: "NOT_ACCEPTABLE"
      });
    }
    if (!response.data.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "Sub menus not found",
        property: "",
        code: "NOT_FOUND"
      });
    }

    return response;
  }
  async function postSubMenu({ params, body, logTrace, userDetails }) {
    const knex = this;
    const created_by = userDetails.id;
    const query = knex(SUBMENU.NAME).where(
      SUBMENU.COLUMNS.SUBMENU_NAME,
      body.sub_menu_name
    );

    const exists_response = await query;

    if (exists_response.length > 0) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_ACCEPTABLE,
        message: "SubMenu already exists",
        property: "",
        code: "NOT_ACCEPTABLE"
      });
    }

    const query_insert = await knex(`${SUBMENU.NAME}`).insert({
      [SUBMENU.COLUMNS.MENU_ID]: body.menu_id,
      [SUBMENU.COLUMNS.SUBMENU_NAME]: body.sub_menu_name,
      [SUBMENU.COLUMNS.SUBMENU_ICON]: body.sub_menu_icon,
      [SUBMENU.COLUMNS.SUBMENU_URL]: body.sub_menu_url,
      [SUBMENU.COLUMNS.SUBMENU_ORDER]: body.sub_menu_order,
      [SUBMENU.COLUMNS.COMPANY_ID]: body.company_id,
      [SUBMENU.COLUMNS.CREATED_BY]: created_by,
      [SUBMENU.COLUMNS.UPDATED_BY]: created_by
    });

    const response = await query_insert;

    if (!response) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_IMPLEMENTED,
        message: "Error while creating SubMenus",
        property: "",
        code: "NOT_IMPLEMENTED"
      });
    }

    return { success: true };
  }
  async function putSubMenu({ submenu_id, body, logTrace, userDetails }) {
    const knex = this;
    const created_by = userDetails.id;

    const query_check = knex(SUBMENU.NAME)
      .whereNot(SUBMENU.COLUMNS.ID, submenu_id)
      .andWhere(function () {
        this.where(SUBMENU.COLUMNS.SUBMENU_NAME, body.sub_menu_name);
      });

    const check_response = await query_check;

    if (check_response.length > 0) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_ACCEPTABLE,
        message: "This submenu name already exsists",
        property: "",
        code: "NOT_ACCEPTABLE"
      });
    }

    const query = knex(SUBMENU.NAME).where(SUBMENU.COLUMNS.ID, submenu_id);

    const exists_response = await query;

    if (!exists_response.length > 0) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_ACCEPTABLE,
        message: "Menu not found to update",
        property: "",
        code: "NOT_ACCEPTABLE"
      });
    }

    const query_update = await knex(`${SUBMENU.NAME}`)
      .where(`${SUBMENU.COLUMNS.ID}`, submenu_id)
      .update({
        [SUBMENU.COLUMNS.MENU_ID]: body.menu_id,
        [SUBMENU.COLUMNS.SUBMENU_NAME]: body.sub_menu_name,
        [SUBMENU.COLUMNS.SUBMENU_ICON]: body.sub_menu_icon,
        [SUBMENU.COLUMNS.SUBMENU_URL]: body.sub_menu_url,
        [SUBMENU.COLUMNS.SUBMENU_ORDER]: body.sub_menu_order,
        [SUBMENU.COLUMNS.COMPANY_ID]: body.company_id,
        [SUBMENU.COLUMNS.UPDATED_BY]: created_by,
        [SUBMENU.COLUMNS.UPDATED_AT]: new Date()
      });

    const response = await query_update;

    if (!response) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_IMPLEMENTED,
        message: "Error while updating SubMenus",
        property: "",
        code: "NOT_IMPLEMENTED"
      });
    }

    return { success: true };
  }
  async function deleteSubMenu({ submenu_id, body, logTrace, params }) {
    const knex = this;
    const query = knex(SUBMENU.NAME).where(SUBMENU.COLUMNS.ID, submenu_id);

    const exists_response = await query;

    if (!exists_response.length > 0) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_ACCEPTABLE,
        message: "Menu not found to delete",
        property: "",
        code: "NOT_ACCEPTABLE"
      });
    }

    const query_delete = knex(SUBMENU.NAME)
      .where(SUBMENU.COLUMNS.ID, submenu_id)
      .del();
    logQuery({
      logger: fastify.log,
      query,
      context: "delete SubMenu",
      logTrace
    });
    const response = await query_delete;
    if (!response) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "SubMenu not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
    // const query_delete1 = await knex(ROLE_MAPPING.NAME)
    //   .where(ROLE_MAPPING.COLUMNS.USER_ID, user_id)
    //   .where(ROLE_MAPPING.COLUMNS.COMPANY_ID, params.company_id)
    //   .del();
    // const query_delete2 = await knex(OUTLET_MAPPING.NAME)
    //   .where(OUTLET_MAPPING.COLUMNS.USER_ID, user_id)
    //   .where(OUTLET_MAPPING.COLUMNS.COMPANY_ID, params.company_id)
    //   .del();
    return { success: true };
  }
  async function submenuList({ body, params, logTrace }) {
    const knex = this;
    const query = knex
      .select([`${SUBMENU.NAME}.*`, `${MENU.NAME}.${MENU.COLUMNS.MENU_NAME}`])
      .from(`${SUBMENU.NAME} as ${SUBMENU.NAME}`)
      .leftJoin(
        `${MENU.NAME} as ${MENU.NAME}`,
        `${SUBMENU.NAME}.${SUBMENU.COLUMNS.MENU_ID}`,
        `${MENU.NAME}.${MENU.COLUMNS.ID}`
      )
      .where(
        `${SUBMENU.NAME}.${SUBMENU.COLUMNS.COMPANY_ID}`,
        params.company_id
      );
    logQuery({
      logger: fastify.log,
      query,
      context: "Get Menus",
      logTrace
    });
    const response = await query;
    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "Menus not found",
        property: "",
        code: "NOT_FOUND"
      });
    }

    return response;
  }
  return {
    getSubMenu,
    postSubMenu,
    putSubMenu,
    deleteSubMenu,
    submenuList
  };
}

module.exports = submenuRepo;
