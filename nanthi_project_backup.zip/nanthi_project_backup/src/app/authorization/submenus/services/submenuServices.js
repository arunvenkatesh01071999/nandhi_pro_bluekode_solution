const submenuRepo = require("../repository/submenu");

function getSubMenuService(fastify) {
  const { getSubMenu } = submenuRepo(fastify);

  return async ({ params, body, logTrace, userDetails }) => {
    const knex = fastify.knexMedical;
    const response = await getSubMenu.call(knex, {
      params,
      body,
      logTrace
    });
    return response;
  };
}
function postSubMenuService(fastify) {
  const { postSubMenu } = submenuRepo(fastify);
  return async ({ params, body, logTrace, userDetails }) => {
    const knex = fastify.knexMedical;
    const promise1 = postSubMenu.call(knex, {
      params,
      body,
      logTrace,
      userDetails
    });
    const [response] = await Promise.all([promise1]);
    return response;
  };
}
function putSubMenuService(fastify) {
  const { putSubMenu } = submenuRepo(fastify);
  return async ({ params, body, logTrace, userDetails }) => {
    const knex = fastify.knexMedical;
    const { submenu_id } = params;
    const promise1 = putSubMenu.call(knex, {
      submenu_id,
      body,
      logTrace,
      userDetails
    });
    const [response] = await Promise.all([promise1]);
    return response;
  };
}
function deleteSubMenuService(fastify) {
  const { deleteSubMenu } = submenuRepo(fastify);
  return async ({ params, body, logTrace }) => {
    const knex = fastify.knexMedical;
    const { submenu_id } = params;
    const promise1 = deleteSubMenu.call(knex, {
      submenu_id,
      params,
      body,
      logTrace
    });
    const [response] = await Promise.all([promise1]);
    return response;
  };
}

function submenuListService(fastify) {
  const { submenuList } = submenuRepo(fastify);

  return async ({ params, body, logTrace }) => {
    const knex = fastify.knexMedical;
    const response = await submenuList.call(knex, {
      params,
      body,
      logTrace
    });
    return response;
  };
}

module.exports = {
  getSubMenuService,
  submenuListService,
  postSubMenuService,
  putSubMenuService,
  deleteSubMenuService
};
