const getSubMenuSchema = require("./getSubMenuSchema");
const submenuListSchema = require("./submenuListSchema");
const postSubMenuSchema = require("./postSubMenuSchema");
const putSubMenuSchema = require("./putSubMenuSchema");
const deleteSubMenuSchema = require("./deleteSubMenuSchema");

module.exports = {
  getSubMenuSchema,
  submenuListSchema,
  postSubMenuSchema,
  putSubMenuSchema,
  deleteSubMenuSchema
};
