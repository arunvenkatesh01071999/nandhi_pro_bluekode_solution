const { errorSchemas } = require("../../../commons/schemas/errorSchemas");

const putSubMenuSchema = {
  tags: ["SUBMENU UPDATION"],
  summary: "This API is to submenu updation",
  headers: { $ref: "request-headers#" },
  params: {
    type: "object",
    properties: {
      submenu_id: { type: "integer" }
    }
  },
  body: {
    type: "object",
    required: [
      "menu_id",
      "sub_menu_name",
      "sub_menu_icon",
      "sub_menu_url",
      "sub_menu_order",
      "company_id"
    ],
    properties: {
      menu_id: { type: "integer" },
      sub_menu_name: { type: "string" },
      sub_menu_icon: { type: "string" },
      sub_menu_url: { type: "string" },
      sub_menu_order: { type: "integer" },
      company_id: { type: "integer" }
    }
  },
  response: {
    200: {
      type: "object",
      properties: {
        success: { type: "boolean" }
      }
    },
    ...errorSchemas
  }
};

module.exports = putSubMenuSchema;
