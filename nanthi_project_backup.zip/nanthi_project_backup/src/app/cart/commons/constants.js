const CART = {
  NAME: "cart",
  COLUMNS: {
    ID: "id",
    CUSTOMERS_ID: "customers_id",
    PRODUCTS_CODE: "products_code",
    UNITS_ID: "units_id",
    CART_QUANTITY: "cart_quantity",
    PRODUCTS_RATE: "products_rate",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at"
  }
};

module.exports = {
  CART
};
