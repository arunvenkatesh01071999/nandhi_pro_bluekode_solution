const { errorSchemas } = require("../../../commons/schemas/errorSchemas");

const putOutletSchema = {
  tags: ["UPDATE OUTLETS"],
  summary: "This API is to update outlets",
  headers: { $ref: "request-headers#" },
  params: {
    type: "object",
    properties: {
      company_id: { type: "integer" }
    }
  },
  body: {
    type: "object",
    required: [
      "code",
      "company_short_name",
      "company_fullname",
      "add1",
      "add2",
      "add3",
      "add4",
      "city",
      "pincode",
      "state",
      "country",
      "phone",
      "mobile",
      "email",
      "website",
      "gstin",
      "fssai",
      "bank_details"
    ],
    properties: {
      code: { type: "string" },
      company_short_name: { type: "string" },
      company_fullname: { type: "string" },
      add1: { type: "string" },
      add2: { type: "string" },
      add3: { type: "string" },
      add4: { type: "string" },
      city: { type: "integer" },
      pincode: { type: "string" },
      state: { type: "integer" },
      country: { type: "integer" },
      phone: { type: "string", pattern: "^[0-9]{10,12}$" },
      mobile: { type: "string", pattern: "^[0-9]{10,12}$" },
      email: { type: "string", format: "email" },
      website: {
        type: "string",
        pattern: "^(https?://)?([\\da-z.-]+)\\.([a-z.]{2,6})([/\\w.-]*)*/?$"
      },
      gstin: { type: "string" },
      fssai: { type: "string" },
      bank_details: {
        type: "array",
        items: {
          type: "object",
          required: ["bank_id", "bankacno", "bankname", "acname", "ifsccode"],
          properties: {
            bank_id: { type: "integer" },
            bankacno: { type: "string" },
            bankname: { type: "string" },
            acname: { type: "string" },
            ifsccode: { type: "string" }
          }
        }
      }
    }
  },
  response: {
    200: {
      type: "object",
      properties: {
        success: { type: "boolean" }
      }
    },
    ...errorSchemas
  }
};

module.exports = putOutletSchema;
