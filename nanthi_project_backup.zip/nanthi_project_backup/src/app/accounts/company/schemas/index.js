const getCompanySchema = require("./getCompanySchema");
const postCompanySchema = require("./postCompanySchema");
const putCompanySchema = require("./putCompanySchema");
const deleteCompanySchema = require("./deleteCompanySchema");
const getCompanyInfoSchema = require("./getCompanyInfoSchema");

module.exports = {
  getCompanySchema,
  postCompanySchema,
  putCompanySchema,
  deleteCompanySchema,
  getCompanyInfoSchema
};
