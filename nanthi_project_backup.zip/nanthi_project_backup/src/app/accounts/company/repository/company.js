const { StatusCodes } = require("http-status-codes");
const { CustomError } = require("../../../errorHandler");
const { logQuery } = require("../../../commons/helpers");
const { ROLES } = require("../commons/constants");
const { COMPANY } = require("../commons/constants");
const { COMPANY_BANK_DETAILS } = require("../commons/constants");
const { STATES } = require("../../../masterData/commons/constants");
const { CITIES } = require("../../../masterData/commons/constants");
const { COUNTRIES } = require("../../../masterData/commons/constants");
const { params } = require("../schemas/getCompanySchema");

function companyRepo(fastify) {
  async function getCompany({ body, params, logTrace }) {
    const knex = this;
    const query = knex
      .select([
        `${COMPANY.NAME}.*`,
        `${STATES.NAME}.${STATES.COLUMNS.NAME} as state_name`,
        `${CITIES.NAME}.${CITIES.COLUMNS.NAME} as city_name`,
        `${COUNTRIES.NAME}.${COUNTRIES.COLUMNS.NAME} as country_name`
      ])
      .from(`${COMPANY.NAME} as ${COMPANY.NAME}`)
      .leftJoin(
        `${STATES.NAME} as ${STATES.NAME}`,
        `${COMPANY.NAME}.${COMPANY.COLUMNS.STATE}`,
        `${STATES.NAME}.${STATES.COLUMNS.ID}`
      )
      .leftJoin(
        `${CITIES.NAME} as ${CITIES.NAME}`,
        `${COMPANY.NAME}.${COMPANY.COLUMNS.CITY}`,
        `${CITIES.NAME}.${CITIES.COLUMNS.ID}`
      )
      .leftJoin(
        `${COUNTRIES.NAME} as ${COUNTRIES.NAME}`,
        `${COMPANY.NAME}.${COMPANY.COLUMNS.COUNTRY}`,
        `${COUNTRIES.NAME}.${COUNTRIES.COLUMNS.ID}`
      )
      .orderBy(COMPANY.COLUMNS.ID, "DESC");

    logQuery({
      logger: fastify.log,
      query,
      context: "Get Company",
      logTrace
    });
    if (params.search && params.search.length >= 1) {
      query
        .where(COMPANY.COLUMNS.CODE, "ilike", `%${params.search}%`)
        .orWhere(COMPANY.COLUMNS.SHORTNAME, "ilike", `%${params.search}%`)
        .orWhere(COMPANY.COLUMNS.FULLNAME, "ilike", `%${params.search}%`)
        .orWhere(COMPANY.COLUMNS.ADD1, "ilike", `%${params.search}%`)
        .orWhere(COMPANY.COLUMNS.ADD2, "ilike", `%${params.search}%`)
        .orWhere(COMPANY.COLUMNS.ADD3, "ilike", `%${params.search}%`)
        .orWhere(COMPANY.COLUMNS.ADD4, "ilike", `%${params.search}%`)
        .orWhere(COMPANY.COLUMNS.PHONE, "ilike", `%${params.search}%`)
        .orWhere(COMPANY.COLUMNS.MOBILE, "ilike", `%${params.search}%`)
        .orWhere(COMPANY.COLUMNS.EMAIL, "ilike", `%${params.search}%`)
        .orWhere(COMPANY.COLUMNS.WEBSITE, "ilike", `%${params.search}%`)
        .orWhere(COMPANY.COLUMNS.GSTIN, "ilike", `%${params.search}%`)
        .orWhere(COMPANY.COLUMNS.FSSAI, "ilike", `%${params.search}%`);
    }
    const response = await query.paginate({
      pageSize: params.page_size, // Customize as needed
      currentPage: params.current_page // Customize as needed
    });
    if (response.meta.pagination.total_pages < params.current_page) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_ACCEPTABLE,
        message: "Requested page is beyond the available data",
        property: "",
        code: "NOT_ACCEPTABLE"
      });
    }
    if (!response.data.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "Role type not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
    const companyWithBankDetails = await Promise.all(
      response.data.map(async company => {
        const bank_details = await knex(COMPANY_BANK_DETAILS.NAME).where(
          COMPANY_BANK_DETAILS.COLUMNS.COMPANY_ID,
          company.id
        );

        return {
          ...company,
          bank_details
        };

        return { ...company, bank_details };
      })
    );
    const combinedResponse = {
      data: companyWithBankDetails,
      meta: response.meta
    };

    return combinedResponse;
  }
  async function getCompanyInfo({ body, params, logTrace }) {
    const knex = this;
    const query = knex
      .select([
        `${COMPANY.NAME}.*`,
        `${STATES.NAME}.${STATES.COLUMNS.NAME} as state_name`,
        `${CITIES.NAME}.${CITIES.COLUMNS.NAME} as city_name`,
        `${COUNTRIES.NAME}.${COUNTRIES.COLUMNS.NAME} as country_name`
      ])
      .from(`${COMPANY.NAME} as ${COMPANY.NAME}`)
      .leftJoin(
        `${STATES.NAME} as ${STATES.NAME}`,
        `${COMPANY.NAME}.${COMPANY.COLUMNS.STATE}`,
        `${STATES.NAME}.${STATES.COLUMNS.ID}`
      )
      .leftJoin(
        `${CITIES.NAME} as ${CITIES.NAME}`,
        `${COMPANY.NAME}.${COMPANY.COLUMNS.CITY}`,
        `${CITIES.NAME}.${CITIES.COLUMNS.ID}`
      )
      .leftJoin(
        `${COUNTRIES.NAME} as ${COUNTRIES.NAME}`,
        `${COMPANY.NAME}.${COMPANY.COLUMNS.COUNTRY}`,
        `${COUNTRIES.NAME}.${COUNTRIES.COLUMNS.ID}`
      )
      .where(`${COMPANY.NAME}.${COMPANY.COLUMNS.ID}`, params.company_id);

    logQuery({
      logger: fastify.log,
      query,
      context: "Get Company",
      logTrace
    });

    const response = await query;

    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "Company info not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
    const companyWithBankDetails = await Promise.all(
      response.map(async company => {
        const bank_details = await knex(COMPANY_BANK_DETAILS.NAME).where(
          COMPANY_BANK_DETAILS.COLUMNS.COMPANY_ID,
          company.id
        );

        return { ...company, bank_details };
      })
    );

    return companyWithBankDetails[0];
  }

  async function postCompany({ params, body, logTrace, userDetails }) {
    const knex = this;
    const created_by = userDetails.id;
    const query_insert = await knex(`${COMPANY.NAME}`)
      .returning("id")
      .insert({
        [COMPANY.COLUMNS.CODE]: body.code,
        [COMPANY.COLUMNS.SHORTNAME]: body.company_short_name,
        [COMPANY.COLUMNS.FULLNAME]: body.company_fullname,
        [COMPANY.COLUMNS.ADD1]: body.add1,
        [COMPANY.COLUMNS.ADD2]: body.add2,
        [COMPANY.COLUMNS.ADD3]: body.add3,
        [COMPANY.COLUMNS.ADD4]: body.add4,
        [COMPANY.COLUMNS.CITY]: body.city,
        [COMPANY.COLUMNS.PINCODE]: body.pincode,
        [COMPANY.COLUMNS.STATE]: body.state,
        [COMPANY.COLUMNS.COUNTRY]: body.country,
        [COMPANY.COLUMNS.PHONE]: body.phone,
        [COMPANY.COLUMNS.MOBILE]: body.mobile,
        [COMPANY.COLUMNS.EMAIL]: body.email,
        [COMPANY.COLUMNS.WEBSITE]: body.website,
        [COMPANY.COLUMNS.GSTIN]: body.gstin,
        [COMPANY.COLUMNS.FSSAI]: body.fssai,
        [COMPANY.COLUMNS.CREATED_BY]: created_by,
        [COMPANY.COLUMNS.UPDATED_BY]: created_by
      });

    const response = await query_insert;
    if (!response) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_IMPLEMENTED,
        message: "Error while creating outlets",
        property: "",
        code: "NOT_IMPLEMENTED"
      });
    }
    const comp_id = response[0].id;
    if (body.bank_details.length > 0) {
      const banks = body.bank_details.map(bank => ({
        [COMPANY_BANK_DETAILS.COLUMNS.BANKACNO]: bank.bankacno,
        [COMPANY_BANK_DETAILS.COLUMNS.BANKNAME]: bank.bankname,
        [COMPANY_BANK_DETAILS.COLUMNS.ACNAME]: bank.acname,
        [COMPANY_BANK_DETAILS.COLUMNS.IFSCCODE]: bank.ifsccode,
        [COMPANY_BANK_DETAILS.COLUMNS.COMPANY_ID]: comp_id,
        [COMPANY_BANK_DETAILS.COLUMNS.UPDATED_BY]: created_by,
        [COMPANY_BANK_DETAILS.COLUMNS.CREATED_BY]: created_by
      }));

      const insertedBanks = await knex(`${COMPANY_BANK_DETAILS.NAME}`).insert(
        banks
      );

      if (!insertedBanks) {
        throw CustomError.create({
          httpCode: StatusCodes.NOT_IMPLEMENTED,
          message: "Error while creating Bank details",
          property: "",
          code: "NOT_IMPLEMENTED"
        });
      }
    }
    return { success: true };
  }
  async function putCompany({ company_id, body, logTrace, userDetails }) {
    const knex = this;
    const created_by = userDetails.id;

    const query_check = knex(COMPANY.NAME)
      .whereNot(COMPANY.COLUMNS.ID, company_id)
      .andWhere(function () {
        this.where(COMPANY.COLUMNS.CODE, body.code)
          .orWhere(COMPANY.COLUMNS.SHORTNAME, body.company_short_name)
          .orWhere(COMPANY.COLUMNS.EMAIL, body.email)
          .orWhere(COMPANY.COLUMNS.FULLNAME, body.company_fullname);
      });

    const check_response = await query_check;

    if (check_response.length > 0) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_ACCEPTABLE,
        message:
          "This code or shortname or fullname or email mapped with another users",
        property: "",
        code: "NOT_ACCEPTABLE"
      });
    }

    const query = knex(COMPANY.NAME).where(COMPANY.COLUMNS.ID, company_id);

    const exists_response = await query;

    if (!exists_response.length > 0) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_ACCEPTABLE,
        message: "company not found to update",
        property: "",
        code: "NOT_ACCEPTABLE"
      });
    }

    const query_update = await knex(`${COMPANY.NAME}`)
      .where(`${COMPANY.COLUMNS.ID}`, company_id)
      .update({
        [COMPANY.COLUMNS.CODE]: body.code,
        [COMPANY.COLUMNS.SHORTNAME]: body.company_short_name,
        [COMPANY.COLUMNS.FULLNAME]: body.company_fullname,
        [COMPANY.COLUMNS.ADD1]: body.add1,
        [COMPANY.COLUMNS.ADD2]: body.add2,
        [COMPANY.COLUMNS.ADD3]: body.add3,
        [COMPANY.COLUMNS.ADD4]: body.add4,
        [COMPANY.COLUMNS.CITY]: body.city,
        [COMPANY.COLUMNS.PINCODE]: body.pincode,
        [COMPANY.COLUMNS.STATE]: body.state,
        [COMPANY.COLUMNS.COUNTRY]: body.country,
        [COMPANY.COLUMNS.PHONE]: body.phone,
        [COMPANY.COLUMNS.MOBILE]: body.mobile,
        [COMPANY.COLUMNS.EMAIL]: body.email,
        [COMPANY.COLUMNS.WEBSITE]: body.website,
        [COMPANY.COLUMNS.GSTIN]: body.gstin,
        [COMPANY.COLUMNS.FSSAI]: body.fssai,
        [COMPANY.COLUMNS.UPDATED_BY]: created_by,
        [COMPANY.COLUMNS.UPDATED_AT]: new Date()
      });

    const response = await query_update;
    if (!response) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_IMPLEMENTED,
        message: "Error while updating outlets",
        property: "",
        code: "NOT_IMPLEMENTED"
      });
    }

    if (body.bank_details.length > 0) {
      const updatedBanks = await Promise.all(
        body.bank_details.map(async bank => {
          const updatedBank = {
            [COMPANY_BANK_DETAILS.COLUMNS.BANKACNO]: bank.bankacno,
            [COMPANY_BANK_DETAILS.COLUMNS.BANKNAME]: bank.bankname,
            [COMPANY_BANK_DETAILS.COLUMNS.ACNAME]: bank.acname,
            [COMPANY_BANK_DETAILS.COLUMNS.IFSCCODE]: bank.ifsccode,
            [COMPANY_BANK_DETAILS.COLUMNS.COMPANY_ID]: company_id,
            [COMPANY.COLUMNS.UPDATED_AT]: new Date(),
            [COMPANY.COLUMNS.UPDATED_BY]: created_by
          };
          if (bank.bank_id > 0) {
            // Assuming bank.bank_id exists to uniquely identify each bank detail
            await knex(`${COMPANY_BANK_DETAILS.NAME}`)
              .where(`${COMPANY_BANK_DETAILS.COLUMNS.ID}`, bank.bank_id)
              .update(updatedBank);

            // return updatedBank;
          } else {
            await knex(`${COMPANY_BANK_DETAILS.NAME}`)
              .where(`${COMPANY_BANK_DETAILS.COLUMNS.ID}`, bank.bank_id)
              .insert(updatedBank);
          }
        })
      );
    }

    // 'updatedBanks' now holds an array of the updated bank details

    return { success: true };
  }
  async function deleteCompany({ company_id, body, logTrace }) {
    const knex = this;
    const query = knex(COMPANY.NAME).where(COMPANY.COLUMNS.ID, company_id);

    const exists_response = await query;

    if (!exists_response.length > 0) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_ACCEPTABLE,
        message: "company not found to delete",
        property: "",
        code: "NOT_ACCEPTABLE"
      });
    }

    const query_delete = knex(COMPANY.NAME)
      .where(COMPANY.COLUMNS.ID, company_id)
      .del();
    logQuery({
      logger: fastify.log,
      query,
      context: "delete Company ",
      logTrace
    });
    const response = await query_delete;
    const query_delete1 = await knex(COMPANY_BANK_DETAILS.NAME)
      .where(COMPANY_BANK_DETAILS.COLUMNS.COMPANY_ID, company_id)
      .del();
    if (!response) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "Company not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
    return { success: true };
  }

  return {
    getCompany,
    postCompany,
    putCompany,
    deleteCompany,
    getCompanyInfo
  };
}

module.exports = companyRepo;
