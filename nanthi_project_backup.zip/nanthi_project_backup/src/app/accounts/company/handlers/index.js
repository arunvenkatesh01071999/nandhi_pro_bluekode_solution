const getCompanyHandler = require("./getCompanyHandler");
const putCompanyHandler = require("./putCompanyHandler");
const postCompanyHandler = require("./postCompanyHandler");
const deleteCompanyHandler = require("./deleteCompanyHandler");
const getCompanyInfoHandler = require("./getCompanyInfoHandler");

module.exports = {
  getCompanyHandler,
  putCompanyHandler,
  postCompanyHandler,
  deleteCompanyHandler,
  getCompanyInfoHandler
};
