const getStockVerifySettingHandler = require("./getStockVerifySettingHandler");
const postStockVerifySettingHandler = require("./postStockVerifySettingHandler");
module.exports = {
    getStockVerifySettingHandler,
    postStockVerifySettingHandler
};
