const getStockVerifySettingSchema = require("./getStockVerifySettingSchema");
const postStockVerifySettingSchema = require("./postStockVerifySettingSchema");

module.exports = {
    getStockVerifySettingSchema,
    postStockVerifySettingSchema,
};
