const { StatusCodes } = require("http-status-codes");
const { CustomError } = require("../../../errorHandler");
const adminRepo = require("../repository/admin");

function getAdminUserService(fastify) {
  const { getAdminUser } = adminRepo(fastify);

  return async ({ params, body, logTrace, userDetails }) => {
    const knex = fastify.knexMedical;

    const created_by = userDetails.id;
    console.log(created_by);
    const response = await getAdminUser.call(knex, {
      params,
      body,
      logTrace
    });

    return response;
  };
}
function postAdminUserService(fastify) {
  const { postAdminUser } = adminRepo(fastify);
  return async ({ params, body, logTrace, userDetails }) => {
    const knex = fastify.knexMedical;
    const promise1 = postAdminUser.call(knex, {
      params,
      body,
      logTrace,
      userDetails
    });
    const [response] = await Promise.all([promise1]);
    return response;
  };
}
function putAdminUserService(fastify) {
  const { putAdminUser } = adminRepo(fastify);
  return async ({ params, body, logTrace, userDetails }) => {
    const knex = fastify.knexMedical;
    const { user_id } = params;
    const promise1 = putAdminUser.call(knex, {
      user_id,
      body,
      logTrace,
      userDetails
    });
    const [response] = await Promise.all([promise1]);
    return response;
  };
}
function deleteAdminUserService(fastify) {
  const { deleteAdminUser } = adminRepo(fastify);
  return async ({ params, body, logTrace }) => {
    const knex = fastify.knexMedical;
    const { user_id } = params;
    const promise1 = deleteAdminUser.call(knex, {
      user_id,
      params,
      body,
      logTrace
    });
    const [response] = await Promise.all([promise1]);
    return response;
  };
}
function adminLoginService(fastify) {
  const { adminLogin, loginCheck, loginFlag } = adminRepo(fastify);
  return async ({ params, body, logTrace }) => {
    const knex = fastify.knexMedical;
    const promise1 = adminLogin.call(knex, {
      body,
      logTrace
    });


    // const response = await promise1;

    const response = await Promise.all([promise1]);


    // const loginCheckResult = await loginCheck.call(knex, {
    //   body,
    //   logTrace
    // });

    // if (loginCheckResult == false) {
    //   throw CustomError.create({
    //     httpCode: StatusCodes.NOT_FOUND,
    //     message: "This users is already logged in somewhere",
    //     property: "",
    //     code: "NOT_FOUND"
    //   });
    // }

    const token = await fastify.jwt.sign({ response });

    const loginFlagResponse = await loginFlag.call(knex, {
      body,
      logTrace,
      token
    });
    return {
      success: true,
      token
    };
  };
}
function getAdminUserInfoService(fastify) {
  const { getAdminUserInfo } = adminRepo(fastify);

  return async ({ params, body, logTrace, userDetails }) => {
    const knex = fastify.knexMedical;
    const response = await getAdminUserInfo.call(knex, {
      params,
      body,
      logTrace,
      userDetails
    });
    return response;
  };
}
function adminLogoutService(fastify) {
  const { adminLogout } = adminRepo(fastify);
  return async ({ params, body, logTrace, userDetails }) => {
    const knex = fastify.knexMedical;
    const promise1 = adminLogout.call(knex, {
      params,
      body,
      logTrace,
      userDetails
    });
    const [response] = await Promise.all([promise1]);
    return response;
  };
}
function clearSessionsService(fastify) {
  const { clearSessions } = adminRepo(fastify);
  return async ({ params, body, logTrace, userDetails }) => {
    const knex = fastify.knexMedical;
    const promise1 = clearSessions.call(knex, {
      params,
      body,
      logTrace,
      userDetails
    });
    const [response] = await Promise.all([promise1]);
    return response;
  };
}

module.exports = {
  getAdminUserService,
  postAdminUserService,
  putAdminUserService,
  deleteAdminUserService,
  adminLoginService,
  getAdminUserInfoService,
  adminLogoutService,
  clearSessionsService
};
