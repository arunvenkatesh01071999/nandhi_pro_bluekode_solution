const adminServices = require("../services/adminServices");

function clearSessionsHandler(fastify) {
    const clearSessions = adminServices.clearSessionsService(fastify);

    return async (request, reply) => {
        const { params, body, logTrace, userDetails } = request;
        const response = await clearSessions({ params, body, logTrace, userDetails });
        return reply.code(200).send(response);
    };
}

module.exports = clearSessionsHandler;
