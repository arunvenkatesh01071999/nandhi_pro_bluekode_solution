const getAdminUserSchema = require("./getAdminUserSchema");
const postAdminUserSchema = require("./postAdminUserSchema");
const putAdminUserSchema = require("./putAdminUserSchema");
const deleteAdminUserSchema = require("./deleteAdminUserSchema");
const adminLoginSchema = require("./adminLoginSchema");
const adminUserInfoSchema = require("./adminUserInfoSchema");
const adminLogoutSchema = require("./adminLogoutSchema");

module.exports = {
  getAdminUserSchema,
  postAdminUserSchema,
  putAdminUserSchema,
  deleteAdminUserSchema,
  adminLoginSchema,
  adminUserInfoSchema,
  adminLogoutSchema
};
