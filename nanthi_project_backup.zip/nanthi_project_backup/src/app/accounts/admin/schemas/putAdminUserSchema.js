const { errorSchemas } = require("../../../commons/schemas/errorSchemas");

const putAdminUserSchema = {
  tags: ["USERS UPDATION"],
  summary: "This API is to users updation",
  headers: { $ref: "request-headers#" },
  params: {
    type: "object",
    properties: {
      user_id: { type: "integer" }
    }
  },
  body: {
    type: "object",
    required: [
      "user_name",
      "user_email",
      "user_mobile",
      "user_password",
      "company_id",
      "roles",
      "outlets",
      "user_type"
    ],
    properties: {
      user_name: { type: "string" },
      user_email: { type: "string", format: "email" },
      user_mobile: { type: "string" },
      user_password: { type: "string" },
      user_type: {
        type: "integer",
        enum: [0, 1, 2]
      },
      company_id: { type: "integer" },
      roles: {
        type: "array",
        items: {
          type: "object",
          required: ["role_id"],
          properties: {
            role_id: { type: "integer" }
          }
        }
      },
      outlets: {
        type: "array",
        items: {
          type: "object",
          required: ["outlet_id"],
          properties: {
            outlet_id: { type: "integer" }
          }
        }
      }
    }
  },
  response: {
    200: {
      type: "object",
      properties: {
        success: { type: "boolean" }
      }
    },
    ...errorSchemas
  }
};

module.exports = putAdminUserSchema;
