const { errorSchemas } = require("../../../commons/schemas/errorSchemas");

const adminUserInfoSchema = {
  tags: ["USER'S INFO"],
  summary: "This API is to get users information",
  headers: { $ref: "request-headers#" },
  response: {
    200: {
      type: "object",
      properties: {
        id: { type: "integer" },
        user_name: { type: "string" },
        user_email: { type: "string" },
        user_mobile: { type: "string" },
        user_password: { type: "string" },
        user_type: {
          type: "integer",
          enum: [0, 1, 2]
        },
        is_active: { type: "boolean" },
        created_at: { type: "string", format: "date-time" },
        updated_at: { type: "string", format: "date-time" },
        roles: {
          type: "array",
          items: {
            type: "object",
            properties: {
              id: { type: "integer" },
              role_name: { type: "string" },
              is_active: { type: "boolean" }
            }
          }
        },
        outlets: {
          type: "array",
          items: {
            type: "object",
            properties: {
              id: { type: "integer" },
              code: { type: "string" },
              short_name: { type: "string" },
              fullname: { type: "string" },
              is_active: { type: "boolean" }
            }
          }
        }
      }
    },
    ...errorSchemas
  }
};

module.exports = adminUserInfoSchema;
