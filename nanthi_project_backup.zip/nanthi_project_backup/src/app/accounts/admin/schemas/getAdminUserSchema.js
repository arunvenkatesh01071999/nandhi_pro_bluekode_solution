const { errorSchemas } = require("../../../commons/schemas/errorSchemas");

const getAdminUserSchema = {
  tags: ["ADMIN USERS"],
  summary: "This API is to get admin users",
  headers: { $ref: "request-headers#" },
  params: {
    type: "object",
    properties: {
      company_id: { type: "integer" },
      page_size: { type: "integer" },
      current_page: { type: "integer" }
    }
  },
  response: {
    200: {
      type: "object",
      properties: {
        data: {
          type: "array",
          items: {
            type: "object",
            properties: {
              id: { type: "integer" },
              user_name: { type: "string" },
              user_email: { type: "string" },
              user_mobile: { type: "string" },
              user_password: { type: "string" },
              user_type: {
                type: "integer",
                enum: [0, 1, 2] // Define the allowed values here
              },
              is_active: { type: "boolean" },
              created_at: { type: "string", format: "date-time" },
              updated_at: { type: "string", format: "date-time" },
              roles: {
                type: "array",
                items: {
                  type: "object",
                  properties: {
                    id: { type: "integer" },
                    role_name: { type: "string" },
                    is_active: { type: "boolean" }
                  }
                }
              },
              outlets: {
                type: "array",
                items: {
                  type: "object",
                  properties: {
                    id: { type: "integer" },
                    code: { type: "string" },
                    short_name: { type: "string" },
                    fullname: { type: "string" },
                    is_active: { type: "boolean" }
                  }
                }
              }
            }
          }
        },
        meta: { $ref: "response-meta#" }
      }
    },
    ...errorSchemas
  }
};

module.exports = getAdminUserSchema;
