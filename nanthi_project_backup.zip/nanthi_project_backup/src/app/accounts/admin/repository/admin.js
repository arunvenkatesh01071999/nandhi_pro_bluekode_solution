const { StatusCodes } = require("http-status-codes");
const crypto = require("crypto");
const { CustomError } = require("../../../errorHandler");
const { logQuery } = require("../../../commons/helpers");
const { USERS } = require("../commons/constants");
const { ROLES } = require("../commons/constants");
const { ROLE_MAPPING } = require("../commons/constants");
const { OUTLET_MAPPING } = require("../commons/constants");
const { OUTLETS } = require("../../outlets/commons/constants");

function adminRepo(fastify) {
  async function getAdminUser({ body, params, logTrace }) {
    const knex = this;
    const query = knex(USERS.NAME).orderBy(USERS.COLUMNS.ID, "DESC");
    logQuery({
      logger: fastify.log,
      query,
      context: "Get Users",
      logTrace
    });

    if (params.search && params.search.length >= 1) {
      query
        .where(USERS.COLUMNS.USER_NAME, "ilike", `%${params.search}%`)
        .orWhere(USERS.COLUMNS.USER_EMAIL, "ilike", `%${params.search}%`)
        .orWhere(USERS.COLUMNS.USER_MOBILE, "ilike", `%${params.search}%`);
    }
    const response = await query.paginate({
      pageSize: params.page_size, // Customize as needed
      currentPage: params.current_page // Customize as needed
    });
    if (response.meta.pagination.total_pages < params.current_page) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_ACCEPTABLE,
        message: "Requested page is beyond the available data",
        property: "",
        code: "NOT_ACCEPTABLE"
      });
    }
    if (!response.data.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "Customers not found",
        property: "",
        code: "NOT_FOUND"
      });
    }

    const usersWithRoleAndOutlets = await Promise.all(
      response.data.map(async user => {
        const roles = await knex
          .select([`${ROLES.NAME}.*`])
          .from(`${ROLE_MAPPING.NAME} as ${ROLE_MAPPING.NAME}`)
          .leftJoin(
            `${ROLES.NAME} as ${ROLES.NAME}`,
            `${ROLE_MAPPING.NAME}.${ROLE_MAPPING.COLUMNS.ROLE_ID}`,
            `${ROLES.NAME}.${ROLES.COLUMNS.ID}`
          )
          .where(
            `${ROLE_MAPPING.NAME}.${ROLE_MAPPING.COLUMNS.USER_ID}`,
            user.id
          )
          .where(
            `${ROLE_MAPPING.NAME}.${ROLE_MAPPING.COLUMNS.COMPANY_ID}`,
            params.company_id
          );
        const outlets = await knex
          .select([`${OUTLETS.NAME}.*`])
          .from(`${OUTLET_MAPPING.NAME} as ${OUTLET_MAPPING.NAME}`)
          .leftJoin(
            `${OUTLETS.NAME} as ${OUTLETS.NAME}`,
            `${OUTLET_MAPPING.NAME}.${OUTLET_MAPPING.COLUMNS.OUTLET_ID}`,
            `${OUTLETS.NAME}.${OUTLETS.COLUMNS.ID}`
          )
          .where(
            `${OUTLET_MAPPING.NAME}.${OUTLET_MAPPING.COLUMNS.USER_ID}`,
            user.id
          )
          .where(
            `${OUTLET_MAPPING.NAME}.${OUTLET_MAPPING.COLUMNS.COMPANY_ID}`,
            params.company_id
          );

        return { ...user, roles, outlets };
      })
    );
    const combinedResponse = {
      data: usersWithRoleAndOutlets,
      meta: response.meta
    };

    return combinedResponse;
  }
  async function postAdminUser({ params, body, logTrace, userDetails }) {
    const knex = this;
    const created_by = userDetails.id;
    const query = knex(USERS.NAME)
      .where(USERS.COLUMNS.USER_EMAIL, body.user_email)
      .orWhere(USERS.COLUMNS.USER_MOBILE, body.user_mobile);

    const exists_response = await query;

    if (exists_response.length > 0) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_ACCEPTABLE,
        message: "User already exists",
        property: "",
        code: "NOT_ACCEPTABLE"
      });
    }
    // Hash the user password with SHA-256
    const hashedPassword = crypto
      .createHash("sha256")
      .update(body.user_password)
      .digest("hex");

    const query_insert = await knex(`${USERS.NAME}`)
      .returning("id")
      .insert({
        [USERS.COLUMNS.USER_NAME]: body.user_name,
        [USERS.COLUMNS.USER_EMAIL]: body.user_email,
        [USERS.COLUMNS.USER_MOBILE]: body.user_mobile,
        [USERS.COLUMNS.USER_PASSWORD]: hashedPassword,
        [USERS.COLUMNS.COMPANY_ID]: body.company_id,
        [USERS.COLUMNS.USER_TYPE]: body.user_type,
        [USERS.COLUMNS.CREATED_BY]: created_by,
        [USERS.COLUMNS.UPDATED_BY]: created_by
      });

    const response = await query_insert;

    if (!response) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_IMPLEMENTED,
        message: "Error while creating Admin Users",
        property: "",
        code: "NOT_IMPLEMENTED"
      });
    }
    const user_id = response[0].id; // productId is auto-generated
    if (body.roles.length > 0) {
      const roles = body.roles.map(role => ({
        [ROLE_MAPPING.COLUMNS.ROLE_ID]: role.role_id,
        [ROLE_MAPPING.COLUMNS.COMPANY_ID]: body.company_id,
        [ROLE_MAPPING.COLUMNS.USER_ID]: user_id,
        [ROLE_MAPPING.COLUMNS.CREATED_BY]: created_by,
        [ROLE_MAPPING.COLUMNS.UPDATED_BY]: created_by
      }));

      const insertedRoles = await knex(`${ROLE_MAPPING.NAME}`).insert(roles);

      if (!insertedRoles) {
        throw CustomError.create({
          httpCode: StatusCodes.NOT_IMPLEMENTED,
          message: "Error while creating Role Mapping",
          property: "",
          code: "NOT_IMPLEMENTED"
        });
      }
    }
    if (body.outlets.length > 0) {
      const outlets = body.outlets.map(outlet => ({
        [OUTLET_MAPPING.COLUMNS.OUTLET_ID]: outlet.outlet_id,
        [OUTLET_MAPPING.COLUMNS.COMPANY_ID]: body.company_id,
        [OUTLET_MAPPING.COLUMNS.USER_ID]: user_id,
        [OUTLET_MAPPING.COLUMNS.CREATED_BY]: created_by,
        [OUTLET_MAPPING.COLUMNS.UPDATED_BY]: created_by
      }));

      const insertedOutlets = await knex(`${OUTLET_MAPPING.NAME}`).insert(
        outlets
      );

      if (!insertedOutlets) {
        throw CustomError.create({
          httpCode: StatusCodes.NOT_IMPLEMENTED,
          message: "Error while creating Outlet Mapping",
          property: "",
          code: "NOT_IMPLEMENTED"
        });
      }
    }
    return { success: true };
  }
  async function putAdminUser({ user_id, body, logTrace, userDetails }) {
    const knex = this;
    const created_by = userDetails.id;

    const query_check = knex(USERS.NAME)
      .whereNot(USERS.COLUMNS.ID, user_id)
      .andWhere(function () {
        this.where(USERS.COLUMNS.USER_EMAIL, body.user_email).orWhere(
          USERS.COLUMNS.USER_MOBILE,
          body.user_mobile
        );
      });

    const check_response = await query_check;

    if (check_response.length > 0) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_ACCEPTABLE,
        message: "This email or mobile mapped with another users",
        property: "",
        code: "NOT_ACCEPTABLE"
      });
    }

    const query = knex(USERS.NAME).where(USERS.COLUMNS.ID, user_id);

    const exists_response = await query;

    if (!exists_response.length > 0) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_ACCEPTABLE,
        message: "Users not found to update",
        property: "",
        code: "NOT_ACCEPTABLE"
      });
    }
    // Hash the user password with SHA-256
    const hashedPassword = crypto
      .createHash("sha256")
      .update(body.user_password)
      .digest("hex");

    const query_update = await knex(`${USERS.NAME}`)
      .where(`${USERS.COLUMNS.ID}`, user_id)
      .update({
        [USERS.COLUMNS.USER_NAME]: body.user_name,
        [USERS.COLUMNS.USER_MOBILE]: body.user_mobile,
        [USERS.COLUMNS.USER_EMAIL]: body.user_email,
        [USERS.COLUMNS.USER_PASSWORD]: hashedPassword,
        [USERS.COLUMNS.COMPANY_ID]: body.company_id,
        [USERS.COLUMNS.USER_TYPE]: body.user_type,
        [USERS.COLUMNS.UPDATED_AT]: new Date(),
        [USERS.COLUMNS.UPDATED_BY]: created_by
      });

    const response = await query_update;

    if (!response) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_IMPLEMENTED,
        message: "Error while updating Admin users",
        property: "",
        code: "NOT_IMPLEMENTED"
      });
    }

    if (body.roles.length > 0) {
      const query_delete = await knex(ROLE_MAPPING.NAME)
        .where(ROLE_MAPPING.COLUMNS.USER_ID, user_id)
        .where(ROLE_MAPPING.COLUMNS.COMPANY_ID, body.company_id)
        .del();
      const roles = body.roles.map(role => ({
        [ROLE_MAPPING.COLUMNS.ROLE_ID]: role.role_id,
        [ROLE_MAPPING.COLUMNS.COMPANY_ID]: body.company_id,
        [ROLE_MAPPING.COLUMNS.USER_ID]: user_id,
        [ROLE_MAPPING.COLUMNS.CREATED_BY]: created_by,
        [ROLE_MAPPING.COLUMNS.UPDATED_BY]: created_by
      }));

      const insertedRoles = await knex(`${ROLE_MAPPING.NAME}`).insert(roles);

      if (!insertedRoles) {
        throw CustomError.create({
          httpCode: StatusCodes.NOT_IMPLEMENTED,
          message: "Error while creating Role Mapping",
          property: "",
          code: "NOT_IMPLEMENTED"
        });
      }
    }
    if (body.outlets.length > 0) {
      const query_delete2 = await knex(OUTLET_MAPPING.NAME)
        .where(OUTLET_MAPPING.COLUMNS.USER_ID, user_id)
        .where(OUTLET_MAPPING.COLUMNS.COMPANY_ID, body.company_id)
        .del();
      const outlets = body.outlets.map(outlet => ({
        [OUTLET_MAPPING.COLUMNS.OUTLET_ID]: outlet.outlet_id,
        [OUTLET_MAPPING.COLUMNS.COMPANY_ID]: body.company_id,
        [OUTLET_MAPPING.COLUMNS.USER_ID]: user_id,
        [OUTLET_MAPPING.COLUMNS.CREATED_BY]: created_by,
        [OUTLET_MAPPING.COLUMNS.UPDATED_BY]: created_by
      }));

      const insertedOutlets = await knex(`${OUTLET_MAPPING.NAME}`).insert(
        outlets
      );

      if (!insertedOutlets) {
        throw CustomError.create({
          httpCode: StatusCodes.NOT_IMPLEMENTED,
          message: "Error while creating Outlet Mapping",
          property: "",
          code: "NOT_IMPLEMENTED"
        });
      }
    }

    return { success: true };
  }
  async function deleteAdminUser({ user_id, body, logTrace, params }) {
    const knex = this;

    const query = knex(USERS.NAME).where(USERS.COLUMNS.ID, user_id);

    const exists_response = await query;

    if (!exists_response.length > 0) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_ACCEPTABLE,
        message: "User not found to delete",
        property: "",
        code: "NOT_ACCEPTABLE"
      });
    }

    const query_delete = knex(USERS.NAME)
      .where(USERS.COLUMNS.ID, user_id)
      .del();
    logQuery({
      logger: fastify.log,
      query,
      context: "delete User",
      logTrace
    });
    const response = await query_delete;
    if (!response) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "User not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
    const query_delete1 = await knex(ROLE_MAPPING.NAME)
      .where(ROLE_MAPPING.COLUMNS.USER_ID, user_id)
      .where(ROLE_MAPPING.COLUMNS.COMPANY_ID, params.company_id)
      .del();
    const query_delete2 = await knex(OUTLET_MAPPING.NAME)
      .where(OUTLET_MAPPING.COLUMNS.USER_ID, user_id)
      .where(OUTLET_MAPPING.COLUMNS.COMPANY_ID, params.company_id)
      .del();
    return { success: true };
  }
  async function adminLogin({ body, params, logTrace }) {
    const knex = this;
    const hashedPassword = crypto
      .createHash("sha256")
      .update(body.password)
      .digest("hex");

    const query = knex(USERS.NAME)
      .where(USERS.COLUMNS.IS_ACTIVE, true)
      .andWhere((builder) => {
        builder.orWhere(USERS.COLUMNS.USER_EMAIL, body.email)
          .orWhere(USERS.COLUMNS.USER_NAME, body.email);
      })
      .andWhere(USERS.COLUMNS.USER_PASSWORD, hashedPassword);

    // const query = knex(USERS.NAME)
    //   .where(USERS.COLUMNS.IS_ACTIVE, true)
    //   .where(USERS.COLUMNS.USER_EMAIL, body.email)
    //   .where(USERS.COLUMNS.USER_PASSWORD, hashedPassword);
    logQuery({
      logger: fastify.log,
      query,
      context: "Get Admin Users",
      logTrace
    });
    const response = await query;

    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "Invalid Credentials",
        property: "",
        code: "NOT_FOUND"
      });
    }

    return response[0];
  }
  async function getAdminUserInfo({ body, params, logTrace, userDetails }) {
    const knex = this;
    const query = knex(USERS.NAME).where(USERS.COLUMNS.ID, userDetails.id);
    logQuery({
      logger: fastify.log,
      query,
      context: "Get Users",
      logTrace
    });
    const response = await query;
    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "Customers not found",
        property: "",
        code: "NOT_FOUND"
      });
    }

    const usersWithRoleAndOutlets = await Promise.all(
      response.map(async user => {
        const roles = await knex
          .select([`${ROLES.NAME}.*`])
          .from(`${ROLE_MAPPING.NAME} as ${ROLE_MAPPING.NAME}`)
          .leftJoin(
            `${ROLES.NAME} as ${ROLES.NAME}`,
            `${ROLE_MAPPING.NAME}.${ROLE_MAPPING.COLUMNS.ROLE_ID}`,
            `${ROLES.NAME}.${ROLES.COLUMNS.ID}`
          )
          .where(
            `${ROLE_MAPPING.NAME}.${ROLE_MAPPING.COLUMNS.USER_ID}`,
            user.id
          )
          .where(
            `${ROLE_MAPPING.NAME}.${ROLE_MAPPING.COLUMNS.COMPANY_ID}`,
            params.company_id
          );
        const outlets = await knex
          .select([`${OUTLETS.NAME}.*`])
          .from(`${OUTLET_MAPPING.NAME} as ${OUTLET_MAPPING.NAME}`)
          .leftJoin(
            `${OUTLETS.NAME} as ${OUTLETS.NAME}`,
            `${OUTLET_MAPPING.NAME}.${OUTLET_MAPPING.COLUMNS.OUTLET_ID}`,
            `${OUTLETS.NAME}.${OUTLETS.COLUMNS.ID}`
          )
          .where(
            `${OUTLET_MAPPING.NAME}.${OUTLET_MAPPING.COLUMNS.USER_ID}`,
            user.id
          )
          .where(
            `${OUTLET_MAPPING.NAME}.${OUTLET_MAPPING.COLUMNS.COMPANY_ID}`,
            params.company_id
          );

        return { ...user, roles, outlets };
      })
    );

    return usersWithRoleAndOutlets[0];
  }
  async function loginCheck({ body, params, logTrace }) {
    const knex = this;
    const hashedPassword = crypto
      .createHash("sha256")
      .update(body.password)
      .digest("hex");

    const query = knex(USERS.NAME)
      .where(USERS.COLUMNS.IS_ACTIVE, true)
      .andWhere((builder) => {
        builder.orWhere(USERS.COLUMNS.USER_EMAIL, body.email)
          .orWhere(USERS.COLUMNS.USER_NAME, body.email);
      })
      .andWhere(USERS.COLUMNS.USER_PASSWORD, hashedPassword)
      .andWhere(USERS.COLUMNS.IS_LOGGING, true);
    logQuery({
      logger: fastify.log,
      query,
      context: "Check Users Logged in or not",
      logTrace
    });
    const response = await query;
    if (!response.length) {
      return true;
    }

    return false;
  }
  async function loginFlag({ user_id, body, logTrace, userDetails }) {
    const knex = this;

    const query_update = knex(`${USERS.NAME}`)
      .where(`${USERS.COLUMNS.USER_EMAIL}`, body.email)
      .orWhere(`${USERS.COLUMNS.USER_NAME}`, body.email)
      .update({
        [USERS.COLUMNS.IS_LOGGING]: true,
        [USERS.COLUMNS.UPDATED_AT]: new Date()
      });

    logQuery({
      logger: fastify.log,
      query: query_update,
      context: "logging in user login status",
      logTrace
    });

    await query_update;
  }
  async function adminLogout({ body, logTrace, userDetails }) {
    const knex = this;
    const user_id = userDetails.id;
    const query_update = knex(`${USERS.NAME}`)
      .where(`${USERS.COLUMNS.ID}`, user_id)
      .update({
        [USERS.COLUMNS.IS_LOGGING]: false,
        [USERS.COLUMNS.UPDATED_AT]: new Date()
      });

    logQuery({
      logger: fastify.log,
      query: query_update,
      context: "log out the user login status",
      logTrace
    });

    await query_update;

    return { success: true }
  }
  async function clearSessions({ body, logTrace, userDetails }) {
    const knex = this;
    const user_id = userDetails.id;
    const query_update = knex(`${USERS.NAME}`)
      .update({
        [USERS.COLUMNS.IS_LOGGING]: false
      });

    logQuery({
      logger: fastify.log,
      query: query_update,
      context: "clear all users sessions",
      logTrace
    });

    await query_update;

    return { success: true }
  }
  return {
    getAdminUser,
    postAdminUser,
    putAdminUser,
    deleteAdminUser,
    adminLogin,
    getAdminUserInfo,
    loginCheck,
    loginFlag,
    adminLogout,
    clearSessions
  };
}

module.exports = adminRepo;
