const getRoleSchema = require("./getRoleSchema");
const postRoleSchema = require("./postRoleSchema");
const putRoleSchema = require("./putRoleSchema");
const deleteRoleSchema = require("./deleteRoleSchema");
const getRoleInfoSchema = require("./getRoleInfoSchema");
const getRoleListSchema = require("./getRoleListSchema");

module.exports = {
  getRoleSchema,
  postRoleSchema,
  putRoleSchema,
  deleteRoleSchema,
  getRoleInfoSchema,
  getRoleListSchema
};
