const { errorSchemas } = require("../../../commons/schemas/errorSchemas");

const putAddressSchema = {
  tags: ["ROLES"],
  summary: "This API is to update roles",
  headers: { $ref: "request-headers#" },
  params: {
    type: "object",
    properties: {
      role_id: { type: "integer" }
    }
  },
  body: {
    type: "object",
    required: ["role_name", "is_active", "company_id"],
    properties: {
      role_name: { type: "string" },
      company_id: { type: "integer" },
      is_active: { type: "boolean" }
    }
  },
  response: {
    200: {
      type: "object",
      properties: {
        success: { type: "boolean" }
      }
    },
    ...errorSchemas
  }
};

module.exports = putAddressSchema;
