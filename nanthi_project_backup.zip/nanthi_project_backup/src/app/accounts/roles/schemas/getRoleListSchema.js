const { errorSchemas } = require("../../../commons/schemas/errorSchemas");

const getRoleListSchema = {
  tags: ["RoleList"],
  summary: "This API is to get SalesMan",
  headers: { $ref: "request-headers#" },
  params: {
    type: "object",
    properties: {
      company_id: { type: "integer" },
      page_size: { type: "integer" },
      current_page: { type: "integer" }
    }
  },
  response: {
    200: {
      type: "array",
      items: {
        type: "object",
        properties: {
          id: { type: "integer" },
          role_name: { type: "string" },
          company_id: { type: "integer" },
          is_active: { type: "boolean" },
          created_at: { type: "string", format: "date-time" },
          updated_at: { type: "string", format: "date-time" }
        }
      }
    },
    ...errorSchemas
  }
};

module.exports = getRoleListSchema;
