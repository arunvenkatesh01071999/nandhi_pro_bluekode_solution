const { errorSchemas } = require("../../../commons/schemas/errorSchemas");

const getRoleInfoSchema = {
  tags: ["ROLE"],
  summary: "This API is to get roles",
  headers: { $ref: "request-headers#" },
  params: {
    type: "object",
    properties: {
      role_id: { type: "integer" }
    }
  },

  response: {
    200: {
      type: "object",
      properties: {
        id: { type: "integer" },
        role_name: { type: "string" },
        company_id: { type: "integer" },
        is_active: { type: "boolean" },
        created_at: { type: "string", format: "date-time" },
        updated_at: { type: "string", format: "date-time" }
      }
    },
    ...errorSchemas
  }
};

module.exports = getRoleInfoSchema;
