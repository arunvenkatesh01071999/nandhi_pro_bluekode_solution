const { errorSchemas } = require("../../../commons/schemas/errorSchemas");

const postRoleSchema = {
  tags: ["ROLES"],
  summary: "This API is to post roles",
  headers: { $ref: "request-headers#" },
  body: {
    type: "object",
    required: ["role_name", "company_id"],
    properties: {
      role_name: { type: "string" },
      company_id: { type: "integer" }
    }
  },
  response: {
    200: {
      type: "object",
      properties: {
        success: { type: "boolean" }
      }
    },
    ...errorSchemas
  }
};

module.exports = postRoleSchema;
