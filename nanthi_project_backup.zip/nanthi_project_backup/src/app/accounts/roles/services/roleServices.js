const roleRepo = require("../repository/roles");

function getRoleService(fastify) {
  const { getRole } = roleRepo(fastify);

  return async ({ params, body, logTrace }) => {
    const knex = fastify.knexMedical;
    const response = await getRole.call(knex, {
      params,
      body,
      logTrace
    });
    return response;
  };
}
function getRoleListService(fastify) {
  const { getRoleList } = roleRepo(fastify);

  return async ({ params, body, logTrace }) => {
    const knex = fastify.knexMedical;
    const response = await getRoleList.call(knex, {
      params,
      body,
      logTrace
    });
    return response;
  };
}
function getRoleInfoService(fastify) {
  const { getRoleInfo } = roleRepo(fastify);

  return async ({ params, body, logTrace }) => {
    const knex = fastify.knexMedical;
    const response = await getRoleInfo.call(knex, {
      params,
      body,
      logTrace
    });
    return response;
  };
}
function postRoleService(fastify) {
  const { postRole } = roleRepo(fastify);
  return async ({ params, body, logTrace, userDetails }) => {
    const knex = fastify.knexMedical;

    const promise1 = postRole.call(knex, {
      params,
      body,
      logTrace,
      userDetails
    });
    const [response] = await Promise.all([promise1]);
    return response;
  };
}
function putRoleService(fastify) {
  const { putRole } = roleRepo(fastify);
  return async ({ params, body, logTrace, userDetails }) => {
    const knex = fastify.knexMedical;
    const { role_id } = params;
    const promise1 = putRole.call(knex, {
      role_id,
      body,
      logTrace,
      userDetails
    });
    const [response] = await Promise.all([promise1]);
    return response;
  };
}
function deleteRoleService(fastify) {
  const { deleteRole } = roleRepo(fastify);
  return async ({ params, body, logTrace }) => {
    const knex = fastify.knexMedical;
    const { role_id } = params;
    const promise1 = deleteRole.call(knex, {
      role_id,
      body,
      logTrace
    });
    const [response] = await Promise.all([promise1]);
    return response;
  };
}

module.exports = {
  getRoleService,
  postRoleService,
  putRoleService,
  deleteRoleService,
  getRoleInfoService,
  getRoleListService
};
