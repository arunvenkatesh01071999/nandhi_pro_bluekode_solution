const roleServices = require("../services/roleServices");

function deleteRoleHandler(fastify) {
  const deleteRole = roleServices.deleteRoleService(fastify);

  return async (request, reply) => {
    const { params, body, logTrace } = request;
    const response = await deleteRole({ params, body, logTrace });
    return reply.code(200).send(response);
  };
}

module.exports = deleteRoleHandler;
