const getRoleHandler = require("./getRoleHandler");
const putRoleHandler = require("./putRoleHandler");
const postRoleHandler = require("./postRoleHandler");
const deleteRoleHandler = require("./deleteRoleHandler");
const getRoleInfoHandler = require("./getRoleInfoHandler");
const getRoleListHandler = require("./getRoleListHandler");

module.exports = {
  getRoleHandler,
  putRoleHandler,
  postRoleHandler,
  deleteRoleHandler,
  getRoleInfoHandler,
  getRoleListHandler
};
