const { StatusCodes } = require("http-status-codes");
const { CustomError } = require("../../../errorHandler");
const { logQuery } = require("../../../commons/helpers");
const { ROLES } = require("../commons/constants");

function roleRepo(fastify) {
  async function getRole({ body, params, logTrace }) {
    const knex = this;
    const query = knex(ROLES.NAME).orderBy(ROLES.COLUMNS.ID, "DESC");
    // const query = knex(ROLES.NAME).where(ROLES.COLUMNS.IS_ACTIVE, true);
    logQuery({
      logger: fastify.log,
      query,
      context: "Get Role",
      logTrace
    });
    if (params.search && params.search.length >= 1) {
      query.where(ROLES.COLUMNS.ROLE_NAME, "ilike", `%${params.search}%`);
    }
    const response = await query.paginate({
      pageSize: params.page_size, // Customize as needed
      currentPage: params.current_page // Customize as needed
    });
    if (response.meta.pagination.total_pages < params.current_page) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_ACCEPTABLE,
        message: "Requested page is beyond the available data",
        property: "",
        code: "NOT_ACCEPTABLE"
      });
    }
    if (!response.data.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "Role type not found",
        property: "",
        code: "NOT_FOUND"
      });
    }

    return response;
  }
  async function getRoleInfo({ body, params, logTrace }) {
    const knex = this;

    const query = knex(ROLES.NAME).where(ROLES.COLUMNS.ID, params.role_id);
    logQuery({
      logger: fastify.log,
      query,
      context: "Get Role",
      logTrace
    });

    const response = await query;

    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "Role not found",
        property: "",
        code: "NOT_FOUND"
      });
    }

    return response[0];
  }
  async function postRole({ params, body, logTrace, userDetails }) {
    const knex = this;
    const created_by = userDetails.id;
    const query = knex(ROLES.NAME)
      .where(ROLES.COLUMNS.ROLE_NAME, body.role_name)
      .where(ROLES.COLUMNS.COMPANY_ID, body.company_id);

    const exists_response = await query;

    if (exists_response.length > 0) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_ACCEPTABLE,
        message: "Role Name Already Exists",
        property: "",
        code: "NOT_ACCEPTABLE"
      });
    }
    const query_insert = await knex(`${ROLES.NAME}`).insert({
      [ROLES.COLUMNS.ROLE_NAME]: body.role_name,
      [ROLES.COLUMNS.COMPANY_ID]: body.company_id,
      [ROLES.COLUMNS.CREATED_BY]: created_by,
      [ROLES.COLUMNS.UPDATED_BY]: created_by
    });

    const response = await query_insert;
    if (!response) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_IMPLEMENTED,
        message: "Error while creating Role type",
        property: "",
        code: "NOT_IMPLEMENTED"
      });
    }

    return { success: true };
  }
  async function putRole({ role_id, body, logTrace, userDetails }) {
    const knex = this;
    const created_by = userDetails.id;
    const query = knex(ROLES.NAME).where(ROLES.COLUMNS.ID, role_id);

    const exists_response = await query;

    if (!exists_response.length > 0) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_ACCEPTABLE,
        message: "Role type not found to update",
        property: "",
        code: "NOT_ACCEPTABLE"
      });
    }

    const query_update = await knex(`${ROLES.NAME}`)
      .where(`${ROLES.COLUMNS.ID}`, role_id)
      .update({
        [ROLES.COLUMNS.ROLE_NAME]: body.role_name,
        [ROLES.COLUMNS.COMPANY_ID]: body.company_id,
        [ROLES.COLUMNS.IS_ACTIVE]: body.is_active,
        [ROLES.COLUMNS.UPDATED_AT]: new Date(),
        [ROLES.COLUMNS.UPDATED_BY]: created_by
      });

    const response = await query_update;
    if (!response) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_IMPLEMENTED,
        message: "Error while updatind Role Type",
        property: "",
        code: "NOT_IMPLEMENTED"
      });
    }

    return { success: true };
  }
  async function deleteRole({ role_id, body, logTrace }) {
    const knex = this;
    const query = knex(ROLES.NAME).where(ROLES.COLUMNS.ID, role_id);

    const exists_response = await query;

    if (!exists_response.length > 0) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_ACCEPTABLE,
        message: "Role not found to delete",
        property: "",
        code: "NOT_ACCEPTABLE"
      });
    }

    const query_delete = knex(ROLES.NAME)
      .where(ROLES.COLUMNS.ID, role_id)
      .del();
    logQuery({
      logger: fastify.log,
      query,
      context: "delete Role ",
      logTrace
    });
    const response = await query_delete;
    if (!response) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "Role not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
    return { success: true };
  }
  async function getRoleList({ body, params, logTrace }) {
    const knex = this;
    const query = knex(ROLES.NAME).where(
      ROLES.COLUMNS.COMPANY_ID,
      params.company_id
    ).orderBy(ROLES.COLUMNS.ID, "DESC");
    logQuery({
      logger: fastify.log,
      query,
      context: "Get Role",
      logTrace
    });
    const response = await query;
    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "Role type not found",
        property: "",
        code: "NOT_FOUND"
      });
    }

    return response;
  }

  return {
    getRole,
    postRole,
    putRole,
    deleteRole,
    getRoleInfo,
    getRoleList
  };
}

module.exports = roleRepo;
