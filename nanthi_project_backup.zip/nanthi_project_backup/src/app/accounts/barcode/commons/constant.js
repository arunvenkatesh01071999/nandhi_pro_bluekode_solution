const { PURCHASE_DETAILS } = require("../../../purchase/commons");

const BARCODE_CONFIG = {
    NAME: "barcode_config",
    COLUMNS: {
        ID: "id",
        IS_INDIVIDUAL: "is_individual",
        COMPANY_ID: "company_id",
        IS_ACTIVE: "is_active",
        CREATED_AT: "created_at",
        UPDATED_AT: "updated_at",
        CREATED_BY: "created_by",
        UPDATED_BY: "updated_by"
    }
};
const BARCODE_LIST = {
    NAME: "barcode_list",
    COLUMNS: {
        ID: "id",
        PROD_ID: "prod_id",
        BARCODE: "barcode",
        PRODUCT_CODE: "product_code",
        IS_SOLD: "is_sold",
        IS_ACTIVE: "is_active",
        COMPANY_ID: "company_id",
        OUTLET_ID: "outlet_id",
        IS_VERIFIED: "is_verified",
        CREATED_AT: "created_at",
        UPDATED_AT: "updated_at",
        CREATED_BY: "created_by",
        UPDATED_BY: "updated_by",
        PURCHASE_NO: "purchase_no",
        OUTLET_DISCOUNT: "outlet_discount",
        IS_CLOSED: "is_closed",
        PURCHASE_DETAILS_ID: "purchase_details_id",
        DIS_PER: "dis_per",
        IS_MISSED: "is_missed",
        WH_ID: "wh_id"
    }
};

module.exports = {
    BARCODE_CONFIG,
    BARCODE_LIST
};
