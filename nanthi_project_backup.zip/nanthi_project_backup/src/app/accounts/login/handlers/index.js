const customerSendOtpHandler = require("./customerSendOtpHandler");
const customerVerifyOtpHandler = require("./customerVerifyOtpHandler");

module.exports = {
  customerSendOtpHandler,
  customerVerifyOtpHandler
};
