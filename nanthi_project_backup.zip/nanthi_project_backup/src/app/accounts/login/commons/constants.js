const CUSTOMERS = {
  NAME: "customers",
  COLUMNS: {
    ID: "id",
    CUSTOMERS_NAME: "customers_name",
    CUSTOMERS_MOBILE: "customers_mobile",
    CUSTOMERS_EMAIL: "customers_email",
    CUSTOMERS_GENDER: "customers_gender",
    CUSTOMERS_DOB: "customers_dob",
    CUSTOMERS_BLOOD_GROUP: "customers_blood_group",
    CUSTOMERS_IMAGE: "customers_image",
    IS_ACTIVE: "is_active",
    IS_VERIFIED: "is_verified",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    DEVICETOKEN: "devicetoken"
  }
};

module.exports = {
  CUSTOMERS
};
