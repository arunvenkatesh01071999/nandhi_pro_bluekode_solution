const customerSendOtpSchema = require("./customerSendOtpSchema");
const customerVerifyOtpSchema = require("./customerVerifyOtpSchema");

module.exports = {
  customerSendOtpSchema,
  customerVerifyOtpSchema
};
