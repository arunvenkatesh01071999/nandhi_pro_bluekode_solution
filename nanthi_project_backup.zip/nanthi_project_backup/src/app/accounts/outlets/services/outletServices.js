const outletRepo = require("../repository/outlets");

function getOutletService(fastify) {
  const { getOutlet } = outletRepo(fastify);

  return async ({ params, body, logTrace }) => {
    const knex = fastify.knexMedical;
    const response = await getOutlet.call(knex, {
      params,
      body,
      logTrace
    });
    return response;
  };
}
function getExistingOutletPMService(fastify) {
  const { getExistingOutletPM } = outletRepo(fastify);

  return async ({ params, body, logTrace }) => {
    const knex = fastify.knexMedical;
    const response = await getExistingOutletPM.call(knex, {
      params,
      body,
      logTrace
    });
    return response;
  };
}

function getNewOutletPMService(fastify) {
  const { getNewOutletPM } = outletRepo(fastify);

  return async ({ params, body, logTrace }) => {
    const knex = fastify.knexMedical;
    const response = await getNewOutletPM.call(knex, {
      params,
      body,
      logTrace
    });
    return response;
  };
}
function getOutletListService(fastify) {
  const { getOutletList } = outletRepo(fastify);

  return async ({ params, body, logTrace }) => {
    const knex = fastify.knexMedical;
    const response = await getOutletList.call(knex, {
      params,
      body,
      logTrace
    });
    return response;
  };
}
function getOutletInfoService(fastify) {
  const { getOutletInfo } = outletRepo(fastify);

  return async ({ params, body, logTrace }) => {
    const knex = fastify.knexMedical;
    const response = await getOutletInfo.call(knex, {
      params,
      body,
      logTrace
    });
    return response;
  };
}
function postOutlettoOutletTransferService(fastify) {
  const { postOutlettoOutletTransfer } = outletRepo(fastify);
  return async ({ params, body, logTrace, userDetails }) => {
    const knex = fastify.knexMedical;

    const promise1 = postOutlettoOutletTransfer.call(knex, {
      params,
      body,
      logTrace,
      userDetails
    });
    const [response] = await Promise.all([promise1]);
    return response;
  };
}
function postOutletService(fastify) {
  const { postOutlet } = outletRepo(fastify);
  return async ({ params, body, logTrace, userDetails }) => {
    const knex = fastify.knexMedical;

    const promise1 = postOutlet.call(knex, {
      params,
      body,
      logTrace,
      userDetails
    });
    const [response] = await Promise.all([promise1]);
    return response;
  };
}
function putOutletService(fastify) {
  const { putOutlet } = outletRepo(fastify);
  return async ({ params, body, logTrace, userDetails }) => {
    const knex = fastify.knexMedical;
    const { outlet_id } = params;
    const promise1 = putOutlet.call(knex, {
      outlet_id,
      body,
      logTrace,
      userDetails
    });
    const [response] = await Promise.all([promise1]);
    return response;
  };
}
function putOutletProductMappingService(fastify) {
  const { putOutletProductMapping } = outletRepo(fastify);
  return async ({ params, body, logTrace, userDetails }) => {
    const knex = fastify.knexMedical;
    const { outlet_id, product_id } = params;
    const promise1 = putOutletProductMapping.call(knex, {
      outlet_id,
      product_id,
      body,
      logTrace,
      userDetails
    });
    const [response] = await Promise.all([promise1]);
    return response;
  };
}

function deleteOutletService(fastify) {
  const { deleteOutlet } = outletRepo(fastify);
  return async ({ params, body, logTrace }) => {
    const knex = fastify.knexMedical;
    const { outlet_id } = params;
    const promise1 = deleteOutlet.call(knex, {
      outlet_id,
      body,
      logTrace
    });
    const [response] = await Promise.all([promise1]);
    return response;
  };
}

module.exports = {
  getOutletService,
  postOutletService,
  putOutletService,
  deleteOutletService,
  getOutletInfoService,
  getOutletListService,
  postOutlettoOutletTransferService,
  getExistingOutletPMService,
  getNewOutletPMService,
  putOutletProductMappingService
};
