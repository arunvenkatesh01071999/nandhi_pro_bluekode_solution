const { StatusCodes } = require("http-status-codes");
const { CustomError } = require("../../../errorHandler");
const { logQuery } = require("../../../commons/helpers");
const { ROLES } = require("../commons/constants");
const { OUTLETS, OUTLETTYPE, FRANCHISETYPE } = require("../commons/constants");
const { STATES } = require("../../../masterData/commons/constants");
const { CITIES } = require("../../../masterData/commons/constants");
const { COUNTRIES } = require("../../../masterData/commons/constants");
const { OUTLET_PRODUCT_MAPPING } = require("../../../catalog/commons");


function outletRepo(fastify) {
  async function getOutlet({ body, params, logTrace }) {
    const knex = this;
    const query = knex
      .select([
        `${OUTLETS.NAME}.*`,
        `${STATES.NAME}.${STATES.COLUMNS.NAME} as state_name`,
        `${CITIES.NAME}.${CITIES.COLUMNS.NAME} as city_name`,
        `${COUNTRIES.NAME}.${COUNTRIES.COLUMNS.NAME} as country_name`,
        `${OUTLETTYPE.NAME}.${OUTLETTYPE.COLUMNS.OUTLETTYPE} as outlet_type_name`,
        `${FRANCHISETYPE.NAME}.${FRANCHISETYPE.COLUMNS.FRANCHISETYPE} as franchise_type_name`
      ])
      .from(`${OUTLETS.NAME} as ${OUTLETS.NAME}`)
      .leftJoin(
        `${STATES.NAME} as ${STATES.NAME}`,
        `${OUTLETS.NAME}.${OUTLETS.COLUMNS.STATE}`,
        `${STATES.NAME}.${STATES.COLUMNS.ID}`
      )
      .leftJoin(
        `${CITIES.NAME} as ${CITIES.NAME}`,
        `${OUTLETS.NAME}.${OUTLETS.COLUMNS.CITY}`,
        `${CITIES.NAME}.${CITIES.COLUMNS.ID}`
      )
      .leftJoin(
        `${COUNTRIES.NAME} as ${COUNTRIES.NAME}`,
        `${OUTLETS.NAME}.${OUTLETS.COLUMNS.COUNTRY}`,
        `${COUNTRIES.NAME}.${COUNTRIES.COLUMNS.ID}`
      )
      .leftJoin(
        `${OUTLETTYPE.NAME} as ${OUTLETTYPE.NAME}`,
        `${OUTLETS.NAME}.${OUTLETS.COLUMNS.OUTLETTYPE}`,
        `${OUTLETTYPE.NAME}.${OUTLETTYPE.COLUMNS.ID}`
      )
      .leftJoin(
        `${FRANCHISETYPE.NAME} as ${FRANCHISETYPE.NAME}`,
        `${OUTLETS.NAME}.${OUTLETS.COLUMNS.FRANCHISETYPE}`,
        `${FRANCHISETYPE.NAME}.${FRANCHISETYPE.COLUMNS.ID}`
      )
      .orderBy(OUTLETS.COLUMNS.ID, "DESC");

    logQuery({
      logger: fastify.log,
      query,
      context: "Get Outlet",
      logTrace
    });
    if (params.search && params.search.length >= 1) {
      query
        .where(OUTLETS.COLUMNS.CODE, "ilike", `%${params.search}%`)
        .orWhere(OUTLETS.COLUMNS.SHORTNAME, "ilike", `%${params.search}%`)
        .orWhere(OUTLETS.COLUMNS.FULLNAME, "ilike", `%${params.search}%`)
        .orWhere(OUTLETS.COLUMNS.ADD1, "ilike", `%${params.search}%`)
        .orWhere(OUTLETS.COLUMNS.ADD2, "ilike", `%${params.search}%`)
        .orWhere(OUTLETS.COLUMNS.ADD3, "ilike", `%${params.search}%`)
        .orWhere(OUTLETS.COLUMNS.ADD4, "ilike", `%${params.search}%`)
        .orWhere(OUTLETS.COLUMNS.PHONE, "ilike", `%${params.search}%`)
        .orWhere(OUTLETS.COLUMNS.MOBILE, "ilike", `%${params.search}%`)
        .orWhere(OUTLETS.COLUMNS.EMAIL, "ilike", `%${params.search}%`)
        .orWhere(OUTLETS.COLUMNS.WEBSITE, "ilike", `%${params.search}%`)
        .orWhere(OUTLETS.COLUMNS.GSTIN, "ilike", `%${params.search}%`)
        .orWhere(OUTLETS.COLUMNS.FSSAI, "ilike", `%${params.search}%`)
        .orWhere(OUTLETS.COLUMNS.BANKACNO, "ilike", `%${params.search}%`)
        .orWhere(OUTLETS.COLUMNS.FSSAI, "ilike", `%${params.search}%`)
        .orWhere(OUTLETS.COLUMNS.BANKNAME, "ilike", `%${params.search}%`)
        .orWhere(OUTLETS.COLUMNS.ACNAME, "ilike", `%${params.search}%`)
        .orWhere(OUTLETS.COLUMNS.IFSCCODE, "ilike", `%${params.search}%`);
    }
    const response = await query.paginate({
      pageSize: params.page_size, // Customize as needed
      currentPage: params.current_page // Customize as needed
    });
    if (response.meta.pagination.total_pages < params.current_page) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_ACCEPTABLE,
        message: "Requested page is beyond the available data",
        property: "",
        code: "NOT_ACCEPTABLE"
      });
    }
    if (!response.data.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "Role type not found",
        property: "",
        code: "NOT_FOUND"
      });
    }

    return response;
  }

  async function getExistingOutletPM({ body, params, logTrace }) {
    const knex = this;

    var query = knex
      .select([
        `${OUTLET_PRODUCT_MAPPING.NAME}.${OUTLET_PRODUCT_MAPPING.COLUMNS.OUTLET_ID}`,
        `${OUTLETS.NAME}.${OUTLETS.COLUMNS.SHORTNAME}`,
        `${OUTLETS.NAME}.${OUTLETS.COLUMNS.FULLNAME}`

      ])
      .distinct(`${OUTLET_PRODUCT_MAPPING.NAME}.${OUTLET_PRODUCT_MAPPING.COLUMNS.OUTLET_ID}`)
      .from(`${OUTLET_PRODUCT_MAPPING.NAME} as ${OUTLET_PRODUCT_MAPPING.NAME}`)
      .leftJoin(
        `${OUTLETS.NAME} as ${OUTLETS.NAME}`,
        `${OUTLET_PRODUCT_MAPPING.NAME}.${OUTLET_PRODUCT_MAPPING.COLUMNS.OUTLET_ID}`,
        `${OUTLETS.NAME}.${OUTLETS.COLUMNS.ID}`
      );


    logQuery({
      logger: fastify.log,
      query,
      context: "Get Outlet to outlet transfer",
      logTrace
    });

    const response = await query

    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "outlets not found",
        property: "",
        code: "NOT_FOUND"
      });
    }

    return response;

  }

  async function getNewOutletPM({ body, params, logTrace }) {
    const knex = this;

    var subquery = knex
      .select(`${OUTLET_PRODUCT_MAPPING.NAME}.${OUTLET_PRODUCT_MAPPING.COLUMNS.OUTLET_ID}`)
      .distinct()
      .from(`${OUTLET_PRODUCT_MAPPING.NAME}`);

    var query = knex(`${OUTLETS.NAME}`)
      .select([
        `${OUTLETS.NAME}.${OUTLETS.COLUMNS.ID}`,
        `${OUTLETS.NAME}.${OUTLETS.COLUMNS.SHORTNAME}`,
        `${OUTLETS.NAME}.${OUTLETS.COLUMNS.FULLNAME}`
      ])
      .whereNotIn(`${OUTLETS.NAME}.${OUTLETS.COLUMNS.ID}`, subquery);


    logQuery({
      logger: fastify.log,
      query,
      context: "Get Outlet to outlet transfer",
      logTrace
    });

    const response = await query

    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "outlets not found",
        property: "",
        code: "NOT_FOUND"
      });
    }

    return response;

  }
  async function getOutletInfo({ body, params, logTrace }) {
    const knex = this;

    const query = knex
      .select([
        `${OUTLETS.NAME}.*`,
        `${STATES.NAME}.${STATES.COLUMNS.NAME} as state_name`,
        `${CITIES.NAME}.${CITIES.COLUMNS.NAME} as city_name`,
        `${COUNTRIES.NAME}.${COUNTRIES.COLUMNS.NAME} as country_name`,
        `${OUTLETTYPE.NAME}.${OUTLETTYPE.COLUMNS.OUTLETTYPE} as outlet_type_name`,
        `${FRANCHISETYPE.NAME}.${FRANCHISETYPE.COLUMNS.FRANCHISETYPE} as franchise_type_name`
      ])
      .from(`${OUTLETS.NAME} as ${OUTLETS.NAME}`)
      .leftJoin(
        `${STATES.NAME} as ${STATES.NAME}`,
        `${OUTLETS.NAME}.${OUTLETS.COLUMNS.STATE}`,
        `${STATES.NAME}.${STATES.COLUMNS.ID}`
      )
      .leftJoin(
        `${CITIES.NAME} as ${CITIES.NAME}`,
        `${OUTLETS.NAME}.${OUTLETS.COLUMNS.CITY}`,
        `${CITIES.NAME}.${CITIES.COLUMNS.ID}`
      )
      .leftJoin(
        `${COUNTRIES.NAME} as ${COUNTRIES.NAME}`,
        `${OUTLETS.NAME}.${OUTLETS.COLUMNS.COUNTRY}`,
        `${COUNTRIES.NAME}.${COUNTRIES.COLUMNS.ID}`
      )
      .leftJoin(
        `${OUTLETTYPE.NAME} as ${OUTLETTYPE.NAME}`,
        `${OUTLETS.NAME}.${OUTLETS.COLUMNS.OUTLETTYPE}`,
        `${OUTLETTYPE.NAME}.${OUTLETTYPE.COLUMNS.ID}`
      )
      .leftJoin(
        `${FRANCHISETYPE.NAME} as ${FRANCHISETYPE.NAME}`,
        `${OUTLETS.NAME}.${OUTLETS.COLUMNS.FRANCHISETYPE}`,
        `${FRANCHISETYPE.NAME}.${FRANCHISETYPE.COLUMNS.ID}`
      )
      .where(`${OUTLETS.NAME}.${OUTLETS.COLUMNS.ID}`, params.outlet_id);
    logQuery({
      logger: fastify.log,
      query,
      context: "Get Role",
      logTrace
    });

    const response = await query;

    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "outlets not found",
        property: "",
        code: "NOT_FOUND"
      });
    }

    return response[0];
  }
  async function postOutlet({ params, body, logTrace, userDetails }) {
    const knex = this;
    const created_by = userDetails.id;

    const query = knex(`${OUTLETS.NAME}`).insert({
      [OUTLETS.COLUMNS.CODE]: body.code,
      [OUTLETS.COLUMNS.SHORTNAME]: body.short_name,
      [OUTLETS.COLUMNS.FULLNAME]: body.fullname,
      [OUTLETS.COLUMNS.ADD1]: body.add1,
      [OUTLETS.COLUMNS.ADD2]: body.add2,
      [OUTLETS.COLUMNS.ADD3]: body.add3,
      [OUTLETS.COLUMNS.ADD4]: body.add4,
      [OUTLETS.COLUMNS.CITY]: body.city,
      [OUTLETS.COLUMNS.PINCODE]: body.pincode,
      [OUTLETS.COLUMNS.STATE]: body.state,
      [OUTLETS.COLUMNS.COUNTRY]: body.country,
      [OUTLETS.COLUMNS.PHONE]: body.phone,
      [OUTLETS.COLUMNS.MOBILE]: body.mobile,
      [OUTLETS.COLUMNS.EMAIL]: body.email,
      [OUTLETS.COLUMNS.WEBSITE]: body.website,
      [OUTLETS.COLUMNS.GSTIN]: body.gstin,
      [OUTLETS.COLUMNS.FSSAI]: body.fssai,
      [OUTLETS.COLUMNS.OUTLETTYPE]: body.outlet_type,
      [OUTLETS.COLUMNS.BANKACNO]: body.bankacno,
      [OUTLETS.COLUMNS.BANKNAME]: body.bankname,
      [OUTLETS.COLUMNS.ACNAME]: body.acname,
      [OUTLETS.COLUMNS.IFSCCODE]: body.ifsccode,
      [OUTLETS.COLUMNS.COMPANY_ID]: body.company_id,
      [OUTLETS.COLUMNS.CREATED_BY]: created_by,
      [OUTLETS.COLUMNS.UPDATED_BY]: created_by,
      [OUTLETS.COLUMNS.FRANCHISETYPE]: body.franchise_type || 0,
      [OUTLETS.COLUMNS.CREDIT_LIMIT]: body.credit_limit || 0,
      [OUTLETS.COLUMNS.ISGST]: body.is_gst,
      [OUTLETS.COLUMNS.LIMITATION]: body.limitation,
      [OUTLETS.COLUMNS.WALLET_BALANCE]: body.wallet_balance,


    });


    logQuery({
      logger: fastify.log,
      query,
      context: "outlets",
      logTrace
    });

    const response = await query;
    if (!response) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_IMPLEMENTED,
        message: "Error while creating outlets",
        property: "",
        code: "NOT_IMPLEMENTED"
      });
    }

    return { success: true };
  }

  async function putOutletProductMapping({ outlet_id, product_id, body, logTrace, userDetails }) {
    const knex = this;
    console.log(outlet_id, "outlet_id");
    console.log(product_id, "product_id");


    const created_by = userDetails.id;
    const query = knex(OUTLET_PRODUCT_MAPPING.NAME)
      .where(`${OUTLET_PRODUCT_MAPPING.COLUMNS.OUTLET_ID}`, outlet_id)
      .andWhere(`${OUTLET_PRODUCT_MAPPING.COLUMNS.PRODUCT_ID}`, product_id)

    const exists_response = await query;

    if (!exists_response.length > 0) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_ACCEPTABLE,
        message: "outler product  not found to update",
        property: "",
        code: "NOT_ACCEPTABLE"
      });
    }

    const query_update = await knex(`${OUTLET_PRODUCT_MAPPING.NAME}`)
      .where(`${OUTLET_PRODUCT_MAPPING.COLUMNS.PRODUCT_ID}`, product_id)
      .andWhere(`${OUTLET_PRODUCT_MAPPING.COLUMNS.OUTLET_ID}`, outlet_id)
      .update({
        [OUTLET_PRODUCT_MAPPING.COLUMNS.MIN_STOCK]: body.min_stock,
        [OUTLET_PRODUCT_MAPPING.COLUMNS.ALLOW_NEG_STK]: body.allow_neg_stk,
        [OUTLET_PRODUCT_MAPPING.COLUMNS.WSCALE]: body.wscale,
        // [OUTLET_PRODUCT_MAPPING.COLUMNS.UPDATED_AT]: new Date(),
        // [OUTLET_PRODUCT_MAPPING.COLUMNS.UPDATED_BY]: created_by

      });

    console.log(body, "bodyy");

    const response = await query_update;

    console.log(response, "response");

    if (!response) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_IMPLEMENTED,
        message: "Error while updating outlets",
        property: "",
        code: "NOT_IMPLEMENTED"
      });
    }

    return { success: true };
  }
  async function putOutlet({ outlet_id, body, logTrace, userDetails }) {
    const knex = this;
    const created_by = userDetails.id;
    const query = knex(OUTLETS.NAME).where(OUTLETS.COLUMNS.ID, outlet_id);

    const exists_response = await query;

    if (!exists_response.length > 0) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_ACCEPTABLE,
        message: "outlers not found to update",
        property: "",
        code: "NOT_ACCEPTABLE"
      });
    }

    const query_update = await knex(`${OUTLETS.NAME}`)
      .where(`${OUTLETS.COLUMNS.ID}`, outlet_id)
      .update({
        [OUTLETS.COLUMNS.CODE]: body.code,
        [OUTLETS.COLUMNS.SHORTNAME]: body.short_name,
        [OUTLETS.COLUMNS.FULLNAME]: body.fullname,
        [OUTLETS.COLUMNS.ADD1]: body.add1,
        [OUTLETS.COLUMNS.ADD2]: body.add2,
        [OUTLETS.COLUMNS.ADD3]: body.add3,
        [OUTLETS.COLUMNS.ADD4]: body.add4,
        [OUTLETS.COLUMNS.CITY]: body.city,
        [OUTLETS.COLUMNS.PINCODE]: body.pincode,
        [OUTLETS.COLUMNS.STATE]: body.state,
        [OUTLETS.COLUMNS.COUNTRY]: body.country,
        [OUTLETS.COLUMNS.PHONE]: body.phone,
        [OUTLETS.COLUMNS.MOBILE]: body.mobile,
        [OUTLETS.COLUMNS.EMAIL]: body.email,
        [OUTLETS.COLUMNS.WEBSITE]: body.website,
        [OUTLETS.COLUMNS.GSTIN]: body.gstin,
        [OUTLETS.COLUMNS.FSSAI]: body.fssai,
        [OUTLETS.COLUMNS.OUTLETTYPE]: body.outlet_type,
        [OUTLETS.COLUMNS.BANKACNO]: body.bankacno,
        [OUTLETS.COLUMNS.BANKNAME]: body.bankname,
        [OUTLETS.COLUMNS.ACNAME]: body.acname,
        [OUTLETS.COLUMNS.IFSCCODE]: body.ifsccode,
        [OUTLETS.COLUMNS.COMPANY_ID]: body.company_id,
        [OUTLETS.COLUMNS.UPDATED_AT]: new Date(),
        [OUTLETS.COLUMNS.UPDATED_BY]: created_by,
        [OUTLETS.COLUMNS.FRANCHISETYPE]: body.franchise_type || 0,
        [OUTLETS.COLUMNS.CREDIT_LIMIT]: body.credit_limit || 0,
        [OUTLETS.COLUMNS.ISGST]: body.is_gst,
        [OUTLETS.COLUMNS.LIMITATION]: body.limitation,
        [OUTLETS.COLUMNS.WALLET_BALANCE]: body.wallet_balance,

      });

    console.log(body, "bodyy");

    const response = await query_update;

    console.log(response, "response");

    if (!response) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_IMPLEMENTED,
        message: "Error while updating outlets",
        property: "",
        code: "NOT_IMPLEMENTED"
      });
    }

    return { success: true };
  }
  async function deleteOutlet({ outlet_id, body, logTrace }) {
    const knex = this;
    const query = knex(OUTLETS.NAME).where(OUTLETS.COLUMNS.ID, outlet_id);

    const exists_response = await query;

    if (!exists_response.length > 0) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_ACCEPTABLE,
        message: "outlet not found to delete",
        property: "",
        code: "NOT_ACCEPTABLE"
      });
    }

    const query_delete = knex(OUTLETS.NAME)
      .where(OUTLETS.COLUMNS.ID, outlet_id)
      .del();
    logQuery({
      logger: fastify.log,
      query,
      context: "delete Role ",
      logTrace
    });
    const response = await query_delete;
    if (!response) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "Role not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
    return { success: true };
  }

  async function getOutletList({ body, params, logTrace }) {
    const knex = this;

    const query = knex
      .select([
        `${OUTLETS.NAME}.*`,
        `${STATES.NAME}.${STATES.COLUMNS.NAME} as state_name`,
        `${CITIES.NAME}.${CITIES.COLUMNS.NAME} as city_name`,
        `${COUNTRIES.NAME}.${COUNTRIES.COLUMNS.NAME} as country_name`,
        `${OUTLETTYPE.NAME}.${OUTLETTYPE.COLUMNS.OUTLETTYPE} as outlet_type_name`,
        `${FRANCHISETYPE.NAME}.${FRANCHISETYPE.COLUMNS.FRANCHISETYPE} as franchise_type_name`,
        'opm.opng_stock',
        'opm.balnc_stock',
        'opm.min_stock',
        'opm.allow_neg_stk',
        'opm.wscale',
      ])
      .from(`${OUTLETS.NAME} as ${OUTLETS.NAME}`)
      .leftJoin(
        `${STATES.NAME} as ${STATES.NAME}`,
        `${OUTLETS.NAME}.${OUTLETS.COLUMNS.STATE}`,
        `${STATES.NAME}.${STATES.COLUMNS.ID}`
      )
      .leftJoin(
        `${CITIES.NAME} as ${CITIES.NAME}`,
        `${OUTLETS.NAME}.${OUTLETS.COLUMNS.CITY}`,
        `${CITIES.NAME}.${CITIES.COLUMNS.ID}`
      )
      .leftJoin(
        `${COUNTRIES.NAME} as ${COUNTRIES.NAME}`,
        `${OUTLETS.NAME}.${OUTLETS.COLUMNS.COUNTRY}`,
        `${COUNTRIES.NAME}.${COUNTRIES.COLUMNS.ID}`
      )
      .leftJoin(
        `${OUTLETTYPE.NAME} as ${OUTLETTYPE.NAME}`,
        `${OUTLETS.NAME}.${OUTLETS.COLUMNS.OUTLETTYPE}`,
        `${OUTLETTYPE.NAME}.${OUTLETTYPE.COLUMNS.ID}`
      )
      .leftJoin(
        `${FRANCHISETYPE.NAME} as ${FRANCHISETYPE.NAME}`,
        `${OUTLETS.NAME}.${OUTLETS.COLUMNS.FRANCHISETYPE}`,
        `${FRANCHISETYPE.NAME}.${FRANCHISETYPE.COLUMNS.ID}`
      )
      .leftJoin(
        knex
          .select([
            'outlet_id',
            'opng_stock',
            'balnc_stock',
            'min_stock',
            'allow_neg_stk',
            'wscale',
            'created_at',
          ])
          .from(function () {
            this.select('*', knex.raw(`ROW_NUMBER() OVER (PARTITION BY outlet_id ORDER BY created_at DESC) as rank`))
              .from('outlet_products_mapping')
              .as('ranked_opm');
          })
          .where('rank', 1)
          .as('opm'),
        `${OUTLETS.NAME}.${OUTLETS.COLUMNS.ID}`,
        'opm.outlet_id'
      )
    // .orderBy(OUTLETS.COLUMNS.ID, "DESC");

    logQuery({
      logger: fastify.log,
      query,
      context: "Get Outlet",
      logTrace
    });

    const response = await query;

    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "Role type not found",
        property: "",
        code: "NOT_FOUND"
      });
    }

    return response;
  }
  async function postOutlettoOutletTransfer({ params, body, logTrace, userDetails }) {
    const knex = this;
    const from_outlet = body.from_outlet
    const to_outlet = body.to_outlet

    console.log(from_outlet, "from_outlet");
    console.log(to_outlet, "to_outlet");


    const query = await knex.raw(`
      WITH selected_rows AS (
          SELECT pro_id, pro_code, opng_stock, balnc_stock, company_id, is_active, created_by, updated_by
          FROM public.outlet_products_mapping 
          WHERE outlet_id = ?
      )
      INSERT INTO public.outlet_products_mapping (pro_id, pro_code, opng_stock, balnc_stock, company_id, is_active, created_by, updated_by, outlet_id)
      SELECT pro_id, pro_code, opng_stock, balnc_stock, company_id, is_active, created_by, updated_by, ?
      FROM selected_rows
    `, [from_outlet, to_outlet])
      .then(response => {
        console.log('Query executed successfully:', response);
      })
      .catch(error => {
        console.error('Error executing query:', error);
      });

    const response = await query

    // logQuery({
    //   logger: fastify.log,
    //   query,
    //   context: "outlets",
    //   logTrace
    // });


    return { success: true };
  }
  return {
    getOutlet,
    postOutlet,
    putOutlet,
    deleteOutlet,
    getOutletInfo,
    getOutletList,
    postOutlettoOutletTransfer,
    getExistingOutletPM,
    getNewOutletPM,
    putOutletProductMapping
  };
}

module.exports = outletRepo;
