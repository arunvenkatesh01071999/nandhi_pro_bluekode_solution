const getOutletHandler = require("./getOutletHandler");
const putOutletHandler = require("./putOutletHandler");
const postOutletHandler = require("./postOutletHandler");
const deleteOutletHandler = require("./deleteOutletHandler");
const getOutletInfoHandler = require("./getOutletInfoHandler");
const getOutletListHandler = require("./getOutletListHandler");
const postOutlettoOutletTransfer = require("./postOutlettoOutletTransfer.js")
const getExistingOutletPMHandler = require("./getExistingOutletPMHandler.js")
const getNewOutletPMHandler = require("./getNewOutletPMHandler.js")
const putOutletProductMappingHandler = require("./putOutletProductMappingHandler.js")

module.exports = {
  getOutletHandler,
  putOutletHandler,
  postOutletHandler,
  deleteOutletHandler,
  getOutletInfoHandler,
  getOutletListHandler,
  postOutlettoOutletTransfer,
  getExistingOutletPMHandler,
  getNewOutletPMHandler,
  putOutletProductMappingHandler
};
