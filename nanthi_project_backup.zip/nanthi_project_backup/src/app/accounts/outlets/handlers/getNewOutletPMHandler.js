const outletServices = require("../services/outletServices");

function getNewOutletPMHandler(fastify) {
  const getNewOutletPM = outletServices.getNewOutletPMService(fastify);
  return async (request, reply) => {
    const { body, params, logTrace } = request;
    const response = await getNewOutletPM({ body, params, logTrace });
    return reply.code(200).send(response);
  };
}

module.exports = getNewOutletPMHandler;
