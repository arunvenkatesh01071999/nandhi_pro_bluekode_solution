const outletServices = require("../services/outletServices");

function getOutletListHandler(fastify) {
  const getOutletList = outletServices.getOutletListService(fastify);
  return async (request, reply) => {
    const { body, params, logTrace } = request;
    const response = await getOutletList({ body, params, logTrace });
    return reply.code(200).send(response);
  };
}

module.exports = getOutletListHandler;
