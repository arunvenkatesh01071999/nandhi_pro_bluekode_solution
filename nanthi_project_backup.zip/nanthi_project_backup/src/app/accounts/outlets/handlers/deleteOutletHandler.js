const outletServices = require("../services/outletServices");

function deleteOutletHandler(fastify) {
  const deleteOutlet = outletServices.deleteOutletService(fastify);

  return async (request, reply) => {
    const { params, body, logTrace } = request;
    const response = await deleteOutlet({ params, body, logTrace });
    return reply.code(200).send(response);
  };
}

module.exports = deleteOutletHandler;
