const outletServices = require("../services/outletServices");

function putOutletProductMappingHandler(fastify) {
  const putOutletProductMapping = outletServices.putOutletProductMappingService(fastify);

  return async (request, reply) => {
    const { params, body, logTrace, userDetails } = request;
    const response = await putOutletProductMapping({ params, body, logTrace, userDetails });
    return reply.code(200).send(response);
  };
}

module.exports = putOutletProductMappingHandler;
