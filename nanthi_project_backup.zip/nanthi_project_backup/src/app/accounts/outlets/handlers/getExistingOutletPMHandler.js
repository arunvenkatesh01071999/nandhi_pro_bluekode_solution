const outletServices = require("../services/outletServices");

function getExistingOutletPMHandler(fastify) {
  const getExistingOutletPM = outletServices.getExistingOutletPMService(fastify);
  return async (request, reply) => {
    const { body, params, logTrace } = request;
    const response = await getExistingOutletPM({ body, params, logTrace });
    return reply.code(200).send(response);
  };
}

module.exports = getExistingOutletPMHandler;
