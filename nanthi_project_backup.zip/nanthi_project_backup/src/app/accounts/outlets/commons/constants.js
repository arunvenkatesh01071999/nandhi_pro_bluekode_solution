const OUTLETS = {
  NAME: "outlets",
  COLUMNS: {
    ID: "id",
    CODE: "code",
    SHORTNAME: "short_name",
    FULLNAME: "fullname",
    ADD1: "add1",
    ADD2: "add2",
    ADD3: "add3",
    ADD4: "add4",
    CITY: "city",
    PINCODE: "pincode",
    STATE: "state",
    COUNTRY: "country",
    PHONE: "phone",
    MOBILE: "mobile",
    EMAIL: "email",
    WEBSITE: "website",
    GSTIN: "gstin",
    FSSAI: "fssai",
    OUTLETTYPE: "outlet_type",
    BANKACNO: "bankacno",
    BANKNAME: "bankname",
    ACNAME: "acname",
    IFSCCODE: "ifsccode",
    BALANCE: "balance",
    COMPANY_ID: "company_id",
    IS_ACTIVE: "is_active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by",
    ISGST: "is_gst",
    FRANCHISETYPE: "franchise_type",
    BALANCE: "balance",
    CREDIT_LIMIT: "credit_limit",
    LIMITATION: "limitation",
    WALLET_BALANCE: "wallet_balance",
    REF_DOC_NO: "ref_doc_no"

  }
};
const OUTLETTYPE = {
  NAME: "outlet_type",
  COLUMNS: {
    ID: "id",
    OUTLETTYPE: "outlet_type",
    COMPANY_ID: "company_id",
    IS_ACTIVE: "is_active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at"
  }
};
const FRANCHISETYPE = {
  NAME: "franchise_type",
  COLUMNS: {
    ID: "id",
    FRANCHISETYPE: "franchise_type",
    COMPANY_ID: "company_id",
    IS_ACTIVE: "is_active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at"
  }
};

module.exports = {
  OUTLETS,
  OUTLETTYPE,
  FRANCHISETYPE
};
