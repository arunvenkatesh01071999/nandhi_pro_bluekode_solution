const { errorSchemas } = require("../../../commons/schemas/errorSchemas");

const postOutletSchema = {
  tags: ["CREATE OUTLETS"],
  summary: "This API is to create outlets",
  headers: { $ref: "request-headers#" },
  body: {
    type: "object",
    required: [
      "code",
      "short_name",
      "fullname",
      "add1",
      "add2",
      "add3",
      "add4",
      "city",
      "pincode",
      "state",
      "country",
      "phone",
      "mobile",
      "email",
      "website",
      "gstin",
      "fssai",
      "outlet_type",
      "bankacno",
      "bankname",
      "acname",
      "ifsccode",
      "is_gst",
      "limitation",
      "wallet_balance"
    ],
    properties: {
      code: { type: "string" },
      short_name: { type: "string" },
      fullname: { type: "string" },
      add1: { type: "string" },
      add2: { type: "string" },
      add3: { type: "string" },
      add4: { type: "string" },
      city: { type: "integer" },
      pincode: { type: "string" },
      state: { type: "integer" },
      country: { type: "integer" },
      phone: { type: "string" },
      mobile: { type: "string" },
      email: { type: "string", format: "email" },
      website: {
        type: "string",
        pattern: "^(https?://)?([\\da-z.-]+)\\.([a-z.]{2,6})([/\\w.-]*)*/?$"
      },
      gstin: { type: "string" },
      fssai: { type: "string" },
      outlet_type: { type: "integer" },
      franchise_type: { type: "integer" },
      bankacno: { type: "string" },
      bankname: { type: "string" },
      acname: { type: "string" },
      ifsccode: { type: "string" },
      is_gst: { type: "boolean" },
      credit_limit: { type: "number" },
      limitation: { type: "number" },
      wallet_balance: { type: "number" },
    }
  },
  response: {
    200: {
      type: "object",
      properties: {
        success: { type: "boolean" }
      }
    },
    ...errorSchemas
  }
};

module.exports = postOutletSchema;
