const getOutletSchema = require("./getOutletSchema");
const postOutletSchema = require("./postOutletSchema");
const putOutletSchema = require("./putOutletSchema");
const deleteOutletSchema = require("./deleteOutletSchema");
const getOutletInfoSchema = require("./getOutletInfoSchema");
const getOutletListSchema = require("./getOutletListSchema");
const postOutlettoOutletTransferSchema = require("./postOutlettoOutletTransferSchema.js")
const putOutletProductMappingSchema = require("./putOutletProductMappingSchema.js")
module.exports = {
  getOutletSchema,
  postOutletSchema,
  putOutletSchema,
  deleteOutletSchema,
  getOutletInfoSchema,
  getOutletListSchema,
  postOutlettoOutletTransferSchema,
  putOutletProductMappingSchema
};
