const { errorSchemas } = require("../../../commons/schemas/errorSchemas");

const putOutletProductMappingSchema = {
  tags: ["UPDATE OUTLETS PRODUCTS MAPPING"],
  summary: "This API is to update outlets",
  headers: { $ref: "request-headers#" },
  params: {
    type: "object",
    properties: {
      outlet_id: { type: "integer" },
      product_id: { type: "integer" }
    }
  },
  body: {
    type: "object",
    required: [
      "min_stock",
      "allow_neg_stk",
      "wscale",
    ],
    properties: {
      min_stock: { type: "number" },
      allow_neg_stk: { type: "boolean" },
      wscale: { type: "boolean" },
    }
  },
  response: {
    200: {
      type: "object",
      properties: {
        success: { type: "boolean" }
      }
    },
    ...errorSchemas
  }
};

module.exports = putOutletProductMappingSchema;
