const { errorSchemas } = require("../../../commons/schemas/errorSchemas");

const postOutlettoOutletTransferSchema = {
  tags: ["TRANSFER OUTLETS"],
  summary: "This API is to create outlets",
  headers: { $ref: "request-headers#" },
  body: {
    type: "object",
    required: [
      "from_outlet",
      "to_outlet",
    ],
    properties: {
      from_outlet: { type: "integer" },
      to_outlet: { type: "integer" },
    }
  },
  response: {
    200: {
      type: "object",
      properties: {
        success: { type: "boolean" }
      }
    },
    ...errorSchemas
  }
};

module.exports = postOutlettoOutletTransferSchema;
