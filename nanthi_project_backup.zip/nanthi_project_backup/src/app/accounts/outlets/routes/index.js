const schemas = require("../schemas");
const handlers = require("../handlers");

module.exports = async fastify => {
  fastify.route({
    method: "GET",
    url: "/outlet/:company_id/:page_size/:current_page/:search?",
    schema: schemas.getOutletSchema,
    preHandler: fastify.authenticate, // Apply JWT authentication decorator
    handler: handlers.getOutletHandler(fastify)
  });
  fastify.route({
    method: "GET",
    url: "/outlet/info/:outlet_id",
    preHandler: fastify.authenticate, // Apply JWT authentication decorator
    schema: schemas.getOutletInfoSchema,
    handler: handlers.getOutletInfoHandler(fastify)
  });
  fastify.route({
    method: "POST",
    url: "/outlet",
    schema: schemas.postOutletSchema,
    preHandler: fastify.authenticate, // Apply JWT authentication decorator
    handler: handlers.postOutletHandler(fastify)
  });
  fastify.route({
    method: "PUT",
    url: "/outlet/:outlet_id",
    schema: schemas.putOutletSchema,
    preHandler: fastify.authenticate, // Apply JWT authentication decorator
    handler: handlers.putOutletHandler(fastify)
  });

  fastify.route({
    method: "PUT",
    url: "/outlet/product/mapping/:outlet_id/:product_id",
    preHandler: fastify.authenticate,
    schema: schemas.putOutletProductMappingSchema,
    handler: handlers.putOutletProductMappingHandler(fastify)
  });
  fastify.route({
    method: "DELETE",
    url: "/outlet/:outlet_id",
    schema: schemas.deleteOutletSchema,
    preHandler: fastify.authenticate, // Apply JWT authentication decorator
    handler: handlers.deleteOutletHandler(fastify)
  });
  fastify.route({
    method: "GET",
    url: "/outlet/list/:company_id",
    schema: schemas.getOutletListSchema,
    preHandler: fastify.authenticate, // Apply JWT authentication decorator
    handler: handlers.getOutletListHandler(fastify)
  });

  fastify.route({
    method: "POST",
    url: "/outlet/to/outlet/transfer",
    schema: schemas.postOutlettoOutletTransferSchema,
    preHandler: fastify.authenticate,
    handler: handlers.postOutlettoOutletTransfer(fastify)
  });

  fastify.route({
    method: "GET",
    url: "/outlet/to/outlet/transfer/existing",
    // schema: schemas.postOutlettoOutletTransferSchema,
    // preHandler: fastify.authenticate,
    handler: handlers.getExistingOutletPMHandler(fastify)
  });

  fastify.route({
    method: "GET",
    url: "/outlet/to/outlet/transfer/new",
    // schema: schemas.postOutlettoOutletTransferSchema,
    // preHandler: fastify.authenticate,
    handler: handlers.getNewOutletPMHandler(fastify)
  });
};
