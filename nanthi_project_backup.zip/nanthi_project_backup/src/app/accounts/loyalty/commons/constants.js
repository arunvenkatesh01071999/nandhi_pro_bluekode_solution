const LOYALTY = {
    NAME: "loyalty",
    COLUMNS: {
        ID: "id",
        LOYALTY_AMOUNT: "loyalty_amount",
        LOYALTY_POINTS: "loyalty_points",
        REDEMPTION_AMOUNT: "redemption_amount",
        REDEMPTION_PERCENTAGE: "redemption_percentage",
        COMPANY_ID: "company_id",
        IS_ACTIVE: "is_active",
        CREATED_AT: "created_at",
        UPDATED_AT: "updated_at",
        CREATED_BY: "created_by",
        UPDATED_BY: "updated_by"
    }
};
module.exports = {
    LOYALTY
};
