const getLoyaltyInfoSchema = require("./getLoyaltyInfoSchema");
const postLoyaltySchema = require("./postLoyaltySchema");

module.exports = {
    getLoyaltyInfoSchema,
    postLoyaltySchema,
};
