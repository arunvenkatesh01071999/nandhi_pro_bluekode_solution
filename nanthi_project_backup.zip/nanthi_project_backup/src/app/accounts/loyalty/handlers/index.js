const getLoyaltyInfoHandler = require("./getLoyaltyInfoHandler");
const postLoyaltyHandler = require("./postLoyaltyHandler");
module.exports = {
    getLoyaltyInfoHandler,
    postLoyaltyHandler,
};
