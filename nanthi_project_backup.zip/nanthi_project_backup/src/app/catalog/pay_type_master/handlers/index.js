const getPayTypeMasterHandler = require("./getPayTypeMasterHandler.js");
const getPayTypeMasterKeyHandler = require("./getPayTypeMasterKeyHandler.js")
const putPayTypeMasterHandler = require("./putPayTypeMasterHandler.js");
const postPayTypeMasterHandler = require("./postPayTypeMasterHandler.js");
const deletePayTypeMasterHandler = require("./deletePayTypeMasterHandler.js");


module.exports = {
  getPayTypeMasterHandler,
  putPayTypeMasterHandler,
  postPayTypeMasterHandler,
  deletePayTypeMasterHandler,
  getPayTypeMasterKeyHandler
};
