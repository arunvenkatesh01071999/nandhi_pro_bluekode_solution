const getPayTypeMasterSchema = require("./getPayTypeMasterSchema");
const postPayTypeMasterSchema = require("./postPayTypeMasterSchema");
const putPayTypeMasterSchema = require("./putPayTypeMasterSchema");
const deletePayTypeMasterSchema = require("./deletePayTypeMasterSchema");
const getPayTypeMasterKeySchema = require("./getPayTypeMasterKeySchema");

module.exports = {
  getPayTypeMasterSchema,
  postPayTypeMasterSchema,
  putPayTypeMasterSchema,
  deletePayTypeMasterSchema,
  getPayTypeMasterKeySchema
};
