const { errorSchemas } = require("../../../commons/schemas/errorSchemas");

const getPayTypeMasterSchema = {
  tags: ["PayType Master"],
  summary: "This API is to get PayType Master",
  headers: { $ref: "request-headers#" },
  response: {
    200: {
      type: "array",
      items: {
        type: "object",
        properties: {
          id: { type: "integer" },
          pay_type_name: { type: "string" },
          pay_type_key: { type: "string" },
          is_active: { type: "boolean" }
        }
      }
    },
    ...errorSchemas
  }
};

module.exports = getPayTypeMasterSchema;
