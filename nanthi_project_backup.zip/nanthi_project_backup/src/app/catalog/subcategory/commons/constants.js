const MAIN_CATEGORY = {
  NAME: "main_category",
  COLUMNS: {
    ID: "id",
    CATEGORY_NAME: "category_name",
    CATEGORY_IMAGE: "category_image",
    COMPANY_ID: "company_id",
    IS_ACTIVE: "is_active"
  }
};

const SUB_CATEGORY = {
  NAME: "sub_category",
  COLUMNS: {
    ID: "id",
    SUBCATEGORY_NAME: "subcategory_name",
    CATEGORY_ID: "category_id",
    SUBCATEGORY_IMAGE: "subcategory_image",
    COMPANY_ID: "company_id",
    IS_ACTIVE: "is_active"
  }
};
const BRANDS = {
  NAME: "brands",
  COLUMNS: {
    ID: "id",
    BRAND_NAME: "brand_name",
    BRAND_IMAGE: "brand_image",
    IS_ACTIVE: "is_active"
  }
};

module.exports = {
  MAIN_CATEGORY,
  SUB_CATEGORY,
  BRANDS
};
