const postSubCategoryHandler = require("./postSubCategoryHandler");
const putSubCategoryHandler = require("./putSubCategoryHandler");
const getSubCategoryHandler = require("./getSubCategoryHandler");
const deleteSubCategoryHandler = require("./deleteSubCategoryHandler");
const getSubCategoryInfoHandler = require("./getSubCategoryInfoHandler");
const getSubCategoryPaginateHandler = require("./getSubCategoryPaginateHandler");
const getCategorySubCategoryInfoHandler = require("./getCategorySubCategoryInfoHandler.js");


module.exports = {
  postSubCategoryHandler,
  putSubCategoryHandler,
  getSubCategoryHandler,
  deleteSubCategoryHandler,
  getSubCategoryInfoHandler,
  getSubCategoryPaginateHandler,
  getCategorySubCategoryInfoHandler
};
