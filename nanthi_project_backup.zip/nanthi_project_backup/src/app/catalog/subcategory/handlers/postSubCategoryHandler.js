const postSubCategoryServices = require("../services/postSubCategoryService");

function postSubCategoryHandler(fastify) {
  const postSubCategory =
    postSubCategoryServices.postSubCategoryService(fastify);

  return async (request, reply) => {
    const { params, body, logTrace } = request;
    const response = await postSubCategory({ params, body, logTrace });
    return reply.code(200).send(response);
  };
}

module.exports = postSubCategoryHandler;
