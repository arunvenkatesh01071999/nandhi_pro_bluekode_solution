const { StatusCodes } = require("http-status-codes");
const { CustomError } = require("../../../errorHandler");
const { logQuery } = require("../../../commons/helpers");
const { HEADS } = require("../../commons");
const { ITEM } = require("../../commons");



function headRepo(fastify) {
  async function getHead({ logTrace }) {
    const knex = this;
    const query = knex(HEADS.NAME).where(HEADS.COLUMNS.IS_ACTIVE, "1");
    logQuery({
      logger: fastify.log,
      query,
      context: "Get HEADS",
      logTrace
    });
    const response = await query;
    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "HEADS not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
    return response;
  }

  async function getHeadPaginate({ params, logTrace }) {
    const knex = this;
    const query = knex(HEADS.NAME);
    if (params.search && params.search.length >= 3) {
      query.where(function () {
        this.where(HEADS.COLUMNS.CATEOGORY_NAME, "ilike", `%${params.search}%`);
      });
    }
    logQuery({
      logger: fastify.log,
      query,
      context: "Get HEADS",
      logTrace
    });
    const response = await query.paginate({
      pageSize: params.page_size, // Customize as needed
      currentPage: params.current_page // Customize as needed
    });
    if (!response.data.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "HEADS not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
    if (response.meta.pagination.total_pages < params.current_page) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_ACCEPTABLE,
        message: "Requested page is beyond the available data",
        property: "",
        code: "NOT_ACCEPTABLE"
      });
    }

    return response;
  }
  async function postHead({ params, body, logTrace, userDetails }) {
    const knex = this;
    const query = knex(HEADS.NAME).where(
      HEADS.COLUMNS.CATEOGORY_NAME,
      body.cateogory_name
    );

    const exists_response = await query;

    if (exists_response.length > 0) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_ACCEPTABLE,
        message: "Head Name Already Exists",
        property: "",
        code: "NOT_ACCEPTABLE"
      });
    }

    const query_insert = await knex(`${HEADS.NAME}`).insert({
      [HEADS.COLUMNS.CATEOGORY_NAME]: body.cateogory_name,
      [HEADS.COLUMNS.COMPANY_ID]: body.company_id,
      [HEADS.COLUMNS.IS_ACTIVE]: body.is_active,
      [HEADS.COLUMNS.CREATED_BY]: userDetails.id
    });

    const response = await query_insert;
    if (!response) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_IMPLEMENTED,
        message: "Error while creating HEADS",
        property: "",
        code: "NOT_IMPLEMENTED"
      });
    }

    return { success: true };
  }

  async function putHead({ head_id, body, logTrace, userDetails }) {
    const knex = this;
    const query = knex(HEADS.NAME).where(HEADS.COLUMNS.ID, head_id);

    const exists_response = await query;
    if (!exists_response.length > 0) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_ACCEPTABLE,
        message: "Head not found to update",
        property: "",
        code: "NOT_ACCEPTABLE"
      });
    }

    const query_update = await knex(`${HEADS.NAME}`)
      .where(`${HEADS.COLUMNS.ID}`, head_id)
      .update({
        [HEADS.COLUMNS.CATEOGORY_NAME]: body.cateogory_name,
        [HEADS.COLUMNS.COMPANY_ID]: body.company_id,
        [HEADS.COLUMNS.IS_ACTIVE]: body.is_active,
        // [HEADS.COLUMNS.UPDATED_BY]: userDetails.result.id
        [HEADS.COLUMNS.UPDATED_BY]: userDetails.id
      });

    const response = await query_update;
    if (!response) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_IMPLEMENTED,
        message: "Error while updatind HEADS",
        property: "",
        code: "NOT_IMPLEMENTED"
      });
    }

    return { success: true };
  }

  async function deleteHead({ head_id, body, logTrace }) {
    const knex = this;
    const query = knex(HEADS.NAME).where(HEADS.COLUMNS.ID, head_id);

    const exists_response = await query;

    if (!exists_response.length > 0) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_ACCEPTABLE,
        message: "Head not found to delete",
        property: "",
        code: "NOT_ACCEPTABLE"
      });
    }

    const query_delete = knex(HEADS.NAME)
      .where(HEADS.COLUMNS.ID, head_id)
      .del();
    logQuery({
      logger: fastify.log,
      query,
      context: "delete HEADS",
      logTrace
    });
    const response = await query_delete;
    if (!response) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "HEADS not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
    return { success: true };
  }
  async function getHeadInfo({ params, logTrace }) {
    const knex = this;
    const query = knex(HEADS.NAME).where(HEADS.COLUMNS.ID, params.head_id);
    logQuery({
      logger: fastify.log,
      query,
      context: "Get HEADS Info",
      logTrace
    });
    const response = await query;
    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "HEADS not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
    return response[0];
  }

  async function getHeadBrandInfo({ params, logTrace }) {
    const knex = this;

    const query = knex
      .distinct([
        `${HEADS.NAME}.*`,
      ])
      .from(`${HEADS.NAME} as ${HEADS.NAME}`)
      .leftJoin(
        `${ITEM.NAME} as ${ITEM.NAME}`,
        `${HEADS.NAME}.${HEADS.COLUMNS.ID}`,
        `${ITEM.NAME}.${ITEM.COLUMNS.HEADID}`
      )
      .where(
        `${ITEM.NAME}.${ITEM.COLUMNS.CATID}`,
        params.cat_id
      )
      .where(
        `${ITEM.NAME}.${ITEM.COLUMNS.SUB_CATEGORY}`,
        params.sub_cat_id
      );


    logQuery({
      logger: fastify.log,
      query,
      context: "Get HEADS Info",
      logTrace
    });

    const response = await query;

    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "HEADS or brand info not found",
        property: "",
        code: "NOT_FOUND"
      });
    }

    return response;
  }



  return {
    getHead,
    postHead,
    putHead,
    deleteHead,
    getHeadInfo,
    getHeadPaginate,
    getHeadBrandInfo
  };
}

module.exports = headRepo;
