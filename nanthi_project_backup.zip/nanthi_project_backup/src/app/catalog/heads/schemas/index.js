const getHeadSchema = require("./getHeadSchema");
const postHeadSchema = require("./postHeadSchema");
const putHeadSchema = require("./putHeadSchema");
const deleteHeadSchema = require("./deleteHeadSchema");
const getHeadInfoSchema = require("./getHeadInfoSchema");
const getHeadPaginateSchema = require("./getHeadPaginateSchema");

module.exports = {
  getHeadSchema,
  postHeadSchema,
  putHeadSchema,
  deleteHeadSchema,
  getHeadInfoSchema,
  getHeadPaginateSchema
};
