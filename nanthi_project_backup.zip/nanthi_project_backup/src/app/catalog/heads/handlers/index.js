const getHeadHandler = require("./getHeadHandler");
const putHeadHandler = require("./putHeadHandler");
const postHeadHandler = require("./postHeadHandler");
const deleteHeadHandler = require("./deleteHeadHandler");
const getHeadInfoHandler = require("./getHeadInfoHandler");
const getHeadPaginateHandler = require("./getHeadPaginateHandler");
const getHeadBrandInfoHandler = require("./getHeadBrandInfoHandler");

module.exports = {
  getHeadHandler,
  putHeadHandler,
  postHeadHandler,
  deleteHeadHandler,
  getHeadInfoHandler,
  getHeadPaginateHandler,
  getHeadBrandInfoHandler
};
