const getGroupHandler = require("./getGroupHandler");
const putGroupHandler = require("./putGroupHandler");
const postGroupHandler = require("./postGroupHandler");
const deleteGroupHandler = require("./deleteGroupHandler");
const getGroupInfoHandler = require("./getGroupInfoHandler");
const getGroupPaginateHandler = require("./getGroupPaginateHandler");

module.exports = {
  getGroupHandler,
  putGroupHandler,
  postGroupHandler,
  deleteGroupHandler,
  getGroupInfoHandler,
  getGroupPaginateHandler
};
