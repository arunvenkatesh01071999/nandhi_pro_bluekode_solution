const getGroupSchema = require("./getGroupSchema");
const postGroupSchema = require("./postGroupSchema");
const putGroupSchema = require("./putGroupSchema");
const deleteGroupSchema = require("./deleteGroupSchema");
const getGroupInfoSchema = require("./getGroupInfoSchema");
const getGroupPaginateSchema = require("./getGroupPaginateSchema");

module.exports = {
  getGroupSchema,
  postGroupSchema,
  putGroupSchema,
  deleteGroupSchema,
  getGroupInfoSchema,
  getGroupPaginateSchema
};
