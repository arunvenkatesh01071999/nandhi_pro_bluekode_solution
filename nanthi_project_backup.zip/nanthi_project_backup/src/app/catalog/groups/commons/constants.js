const GROUPS = {
  NAME: "groups",
  COLUMNS: {
    ID: "id",
    GROUP_NAME: "group_name",
    GROUP_IMAGE: "group_image",
    IS_ACTIVE: "is_active"
  }
};

module.exports = {
  GROUPS
};
