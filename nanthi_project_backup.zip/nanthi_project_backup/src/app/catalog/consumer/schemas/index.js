const getConsumerSchema = require("./getConsumerSchema");
const postConsumerSchema = require("./postConsumerSchema");
const putConsumerSchema = require("./putConsumerSchema");
const deleteConsumerSchema = require("./deleteConsumerSchema");
const getConsumerInfoSchema = require("./getConsumerInfoSchema");
const getConsumerPaginateSchema = require("./getConsumerPaginateSchema");

module.exports = {
  getConsumerSchema,
  postConsumerSchema,
  putConsumerSchema,
  deleteConsumerSchema,
  getConsumerInfoSchema,
  getConsumerPaginateSchema
};
