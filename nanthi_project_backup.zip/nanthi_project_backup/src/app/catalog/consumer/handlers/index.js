const getConsumerHandler = require("./getConsumerHandler");
const putConsumerHandler = require("./putConsumerHandler");
const postConsumerHandler = require("./postConsumerHandler");
const deleteConsumerHandler = require("./deleteConsumerHandler");
const getConsumerInfoHandler = require("./getConsumerInfoHandler");
const getConsumerPaginateHandler = require("./getConsumerPaginateHandler");

module.exports = {
  getConsumerHandler,
  putConsumerHandler,
  postConsumerHandler,
  deleteConsumerHandler,
  getConsumerInfoHandler,
  getConsumerPaginateHandler
};
