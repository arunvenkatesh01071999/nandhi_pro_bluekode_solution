const HEADS = {
  NAME: "heads",
  COLUMNS: {
    ID: "id",
    CATEOGORY_NAME: "cateogory_name",
    COMPANY_ID: "company_id",
    IS_ACTIVE: "is_active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }
};
const CONSUMER = {
  NAME: "consumer",
  COLUMNS: {
    ID: "id",
    CONSUMER_NAME: "consumer_name",
    COMPANY_ID: "company_id",
    IS_ACTIVE: "is_active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }
};
const TYPEDESIGN = {
  NAME: "typedesign",
  COLUMNS: {
    ID: "id",
    TYPE_NAME: "type_name",
    TYPE_ID: "type_id",
    COMPANY_ID: "company_id",
    IS_ACTIVE: "is_active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }
};

const ACCOUNTMASTER = {
  NAME: "accountmaster",
  COLUMNS: {
    ID: "id",
    ACNAME: "acname",
    ACTYPEID: "actype_id",
    COMPANY_ID: "company_id",
    IS_ACTIVE: "is_active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }
};
const WAREHOUSE = {
  NAME: "warehouse",
  COLUMNS: {
    ID: "id",
    WHNAME: "wh_name",
    SHORT_NAME: "short_name",
    ADD1: "add1",
    ADD2: "add2",
    ADD3: "add3",
    ADD4: "add4",
    CITY: "city",
    PINCODE: "pincode",
    STATE: "state",
    PHONE: "phone",
    MOBILE: "mobile",
    EMAIL: "email",
    COMPANY_ID: "company_id",
    IS_ACTIVE: "is_active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by",
    COUNTRY: "country",
    CITYID: "city_id",
    STATEID: "state_id",
    COUNTRYID: "country_id",
    LIMITATION: "limitation",
    //new
    GSTIN: "gstin",
    FSSAI: "fssai",
    ISGST: "is_gst",
    WALLET_BALANCE: "wallet_balance",
    BANKACNO: "bankacno",
    BANKNAME: "bankname",
    ACNAME: "acname",
    IFSCCODE: "ifsccode",
    MAIN_WAREHOUSE: "main_warehouse"
    //fields
  }
};

const SALESMAN = {
  NAME: "salesman",
  COLUMNS: {
    ID: "id",
    SALESMANCODE: "sales_man_code",
    SALESMANNAME: "sales_man_name",
    SHORT_NAME: "short_name",
    FATHER_NAME: "father_name",
    MOTHER_NAME: "mother_name",
    CODE: "code",
    ADD1: "add1",
    ADD2: "add2",
    ADD3: "add3",
    DOB: "dob",
    SEX: "sex",
    MOBILE: "mobile",
    PHOTO: "photo",
    ID_PROOF: "id_proof",
    PASSBOOK: "passbook",
    COMPANY_ID: "company_id",
    IS_ACTIVE: "is_active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }
};

const SUPPLIER = {
  NAME: "supplier",
  COLUMNS: {
    ID: "id",
    NAME: "name",
    SHORTNAME: "short_name",
    ADD1: "add1",
    ADD2: "add2",
    ADD3: "add3",
    ADD4: "add4",
    CITY: "city",
    PINCODE: "pincode",
    STATE: "state",
    PHONE: "phone",
    MOBILE: "mobile",
    EMAIL: "email",
    WEBSITE: "website",
    GSTIN: "gstin",
    OP_BAL: "op_bal",
    BALANCE: "balance",
    CUSTTYPE: "custtype",
    BANK_AC_NO: "bank_ac_no",
    BANKNAME: "bankname",
    AC_NAME: "ac_name",
    IFSCCODE: "ifsccode",
    COUNTRY: "country",
    FSSAI: "fssaino",
    COMPANY_ID: "company_id",
    IS_ACTIVE: "is_active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }
};

const ITEM = {
  NAME: "item",
  COLUMNS: {
    ID: "id",
    PRODUCT_CODE: "pro_code",
    PRODUCT_NAME: "pro_name",
    SHORT_NAME: "short_name",
    PRO_DESCRIPTION: "pro_description",
    MANUFACTURING_DATE: "manufacturing_date",
    EXPIRY_DATE: "expiry_date",
    TYPE: "type",
    SUB_CATEGORY: "sub_cat",
    UOM: "uom",
    BARCODE: "barcode",
    PARCHASE_RATE: "pur_rate",
    SALE_RATE: "sale_rate",
    WHOLESALE_RATE: "wholesale_rate",
    MRP: "mrp",
    GST: "gst",
    CESS: "cess",
    HSN: "hsn",
    OP_STK: "op_stk",
    BALANCE: "balance",
    MIN_STOCK: "min_stock",
    ALLOW_NEG_STK: "allow_neg_stk",
    WSCALE: "wscale",
    VENDOR: "vendor",
    COMPANY_ID: "company_id",
    IS_ACTIVE: "is_active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by",
    HEADID: "head_id",
    CATID: "cat_id",
    PRODUCT_TYPE: "product_type",
    MAIN_PRODUCT_ID: "main_product_id",
    MAIN_UOM_ID: "main_uom_id",
    CONVERTION_FACTOR: "convertion_factor"

  }
};

const OUTLET_PRODUCT_MAPPING = {
  NAME: "outlet_products_mapping",
  COLUMNS: {
    ID: "id",
    PRODUCT_ID: "pro_id",
    PRODUCT_CODE: "pro_code",
    OUTLET_ID: "outlet_id",
    OPENING_STOCK: "opng_stock",
    BALENCE_STOCK: "balnc_stock",
    MIN_STOCK: "min_stock",
    ALLOW_NEG_STK: "allow_neg_stk",
    WSCALE: "wscale",
    COMPANY_ID: "company_id",
    IS_ACTIVE: "is_active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by",
    MIN_WARN_STOCK: "min_warn_stock"
  }
};

const BARCODE_LIST = {
  NAME: "barcode_list",
  COLUMNS: {
    ID: "id",
    PROD_ID: "prod_id",
    BARCODE: "barcode",
    IS_SOLD: "is_sold",
    IS_ACTIVE: "is_active",
    COMPANY_ID: "company_id",
    OUTLET_ID: "outlet_id",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by",
    PURCHASE_NO: "purchase_no",
    IS_VERIFIED: "is_verified"
  }
};

const VENDORS_MAPPING = {
  NAME: "vendors_mapping",
  COLUMNS: {
    ID: "id",
    VENDORS_ID: "vendors_id",
    PRODUCT_ID: "pro_id",
    PRODUCT_CODE: "pro_code",
    COMPANY_ID: "company_id",
    IS_ACTIVE: "is_active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }
};

const SALESMAN_OUTLET_MAPPING = {
  NAME: "salesman_outlet_mapping",
  COLUMNS: {
    ID: "id",
    SALESMAN_ID: "salesman_id",
    OUTLET_ID: "outlet_id",
    COMPANY_ID: "company_id",
    IS_ACTIVE: "is_active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }
};

const TRANSACTION_PROVIDER = {
  NAME: "transaction_provider_master",
  COLUMNS: {
    ID: "id",
    TRANSACTION_PROVIDER: "transaction_provider",
    MERCHANT_ID: "merchant_id",
    MERCHANT_KEY: "merchant_key",
    URL: "url",
    IS_ACTIVE: "is_active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }
};

const TRANSACTION_TYPE = {
  NAME: "transaction_type_master",
  COLUMNS: {
    ID: "id",
    TRANSACTION_TYPE: "transaction_type",
    IS_ACTIVE: "is_active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }
};
const PAY_TYPE_MASTER = {
  NAME: "pay_type_master",
  COLUMNS: {
    ID: "id",
    PAY_TYPE_NAME: "pay_type_name",
    PAY_TYPE_KEY: "pay_type_key",
    IS_ACTIVE: "is_active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }
};

module.exports = {
  HEADS,
  CONSUMER,
  TYPEDESIGN,
  ACCOUNTMASTER,
  WAREHOUSE,
  SALESMAN,
  SUPPLIER,
  ITEM,
  OUTLET_PRODUCT_MAPPING,
  BARCODE_LIST,
  VENDORS_MAPPING,
  SALESMAN_OUTLET_MAPPING,
  TRANSACTION_PROVIDER,
  TRANSACTION_TYPE,
  PAY_TYPE_MASTER
};
