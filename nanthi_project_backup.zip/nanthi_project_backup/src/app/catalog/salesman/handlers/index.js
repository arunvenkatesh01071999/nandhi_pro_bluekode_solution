const getSalesManHandler = require("./getSalesManHandler");
const putSalesManHandler = require("./putSalesManHandler");
const postSalesManHandler = require("./postSalesManHandler");
const deleteSalesManHandler = require("./deleteSalesManHandler");
const getSalesManInfoHandler = require("./getSalesManInfoHandler");
const getSalesManPaginateHandler = require("./getSalesManPaginateHandler");
const postSalesManOutletMappingHandler = require("./postSalesManOutletMappingHandler.js")
const putSalesManOutletMappingHandler = require("./putSalesManOutletMappingHandler.js")
const getSalesManOutletMappingHandler = require("./getSalesManOutletMappingHandler.js")
const getSalesManInfoOutletMappingOneHandler = require("./getSalesManInfoOutletMappingOneHandler.js")
const getSalesManInfoOutletMappingOnePaginateHandler = require("./getSalesManInfoOutletMappingOnePaginateHandler.js")
const getSalesManByOutletHandler = require("./getSalesManByOutletHandler.js")
module.exports = {
  getSalesManHandler,
  putSalesManHandler,
  postSalesManHandler,
  deleteSalesManHandler,
  getSalesManInfoHandler,
  getSalesManPaginateHandler,
  postSalesManOutletMappingHandler,
  putSalesManOutletMappingHandler,
  getSalesManOutletMappingHandler,
  getSalesManInfoOutletMappingOneHandler,
  getSalesManInfoOutletMappingOnePaginateHandler,
  getSalesManByOutletHandler
};
