const getSalesManSchema = require("./getSalesManSchema");
const postSalesManSchema = require("./postSalesManSchema");
const putSalesManSchema = require("./putSalesManSchema");
const deleteSalesManSchema = require("./deleteSalesManSchema");
const getSalesManInfoSchema = require("./getSalesManInfoSchema");
const getSalesManPaginateSchema = require("./getSalesManPaginateSchema");
const getSalesManByOutletSchema = require("./getSalesManByOutletSchema");

module.exports = {
  getSalesManSchema,
  postSalesManSchema,
  putSalesManSchema,
  deleteSalesManSchema,
  getSalesManInfoSchema,
  getSalesManPaginateSchema,
  getSalesManByOutletSchema
};
