const getAccountMasterHandler = require("./getAccountMaster");
const putAccountMasterHandler = require("./putAccountMasterHandler");
const postAccountMasterHandler = require("./postAccountMasterHandler");
const deleteAccountMasterHandler = require("./deleteAccountMasterHandler");
const getAccountMasterInfoHandler = require("./getAccountMasterInfoHandler");
const getAccountMasterPaginateHandler = require("./getAccountMasterPaginateHandler");

module.exports = {
  getAccountMasterHandler,
  putAccountMasterHandler,
  postAccountMasterHandler,
  deleteAccountMasterHandler,
  getAccountMasterInfoHandler,
  getAccountMasterPaginateHandler
};
