const { errorSchemas } = require("../../../commons/schemas/errorSchemas");

const getSubAccountsPaginateSchema = {
  tags: ["CATEGORY"],
  summary: "This API is to fetch sub categories",
  headers: { $ref: "request-headers#" },
  params: {
    type: "object",
    properties: {
      page_size: { type: "integer" },
      current_page: { type: "integer" }
    }
  },
  response: {
    200: {
      type: "object",
      properties: {
        data: {
          type: "array",
          items: {
            type: "object",
            properties: {
              id: { type: "integer" },
              sub_account_name: { type: "string" },
              acc_id: { type: "integer" },
              acname: { type: "string" },
              is_active: { type: "boolean" }
            }
          }
        },
        meta: { $ref: "response-meta#" }
      }
    },
    ...errorSchemas
  }
};

module.exports = getSubAccountsPaginateSchema;
