const BANNER = {
  NAME: "banners",
  COLUMNS: {
    ID: "id",
    BANNERNAME: "banner_name",
    BANNERIMAGEURL: "banner_image_url",
    ISACTIVE: "is_active"
  }
};

module.exports = {
  BANNER
};
