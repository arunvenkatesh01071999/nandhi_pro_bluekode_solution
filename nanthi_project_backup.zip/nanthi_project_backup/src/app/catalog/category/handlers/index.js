const patchCategoryImage = require("./patchCategoryImage");
const postCategoryHandler = require("./postCategoryHandler");
const putCategoryHandler = require("./putCategoryHandler");
const getCategoryHandler = require("./getCategoryHandler");
const deleteCategoryHandler = require("./deleteCategoryHandler");
const getCategoryInfoHandler = require("./getCategoryInfoHandler");
const getCategoryPaginateHandler = require("./getCategoryPaginateHandler");
const getHomeCategoryHandler = require("./getHomeCategoryHandler");

module.exports = {
  patchCategoryImage,
  postCategoryHandler,
  putCategoryHandler,
  getCategoryHandler,
  deleteCategoryHandler,
  getCategoryInfoHandler,
  getCategoryPaginateHandler,
  getHomeCategoryHandler
};
