const postCategoryService = require("../services/postCategoryService");

function putCategoryHandler(fastify) {
  const putCategory = postCategoryService.putCategoryService(fastify);

  return async (request, reply) => {
    const { params, body, logTrace } = request;
    const response = await putCategory({ params, body, logTrace });
    return reply.code(200).send(response);
  };
}

module.exports = putCategoryHandler;
