const { StatusCodes } = require("http-status-codes");
const { CustomError } = require("../../../errorHandler");
const { logQuery } = require("../../../commons/helpers");
const { MAIN_CATEGORY } = require("../commons/constants");
const { SUB_CATEGORY } = require("../commons/constants");

// Need Catalog DB Connection

function mainCategoryRepo(fastify) {
  async function postCategories({ params, body, logTrace }) {
    const knex = this;
    const query = knex(MAIN_CATEGORY.NAME).where(
      MAIN_CATEGORY.COLUMNS.CATEGORY_NAME,
      body.category_name
    );

    const exists_response = await query;

    if (exists_response.length > 0) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_ACCEPTABLE,
        message: "Category Already Exists",
        property: "",
        code: "NOT_ACCEPTABLE"
      });
    }
    const query_insert = await knex(`${MAIN_CATEGORY.NAME}`).insert({
      [MAIN_CATEGORY.COLUMNS.CATEGORY_NAME]: body.category_name,
      [MAIN_CATEGORY.COLUMNS.CATEGORY_IMAGE]: body.category_image,
      [MAIN_CATEGORY.COLUMNS.COMPANY_ID]: body.company_id,
      [MAIN_CATEGORY.COLUMNS.IS_ACTIVE]: body.is_active
    });

    const response = await query_insert;
    if (!response) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_IMPLEMENTED,
        message: "Error while creating category",
        property: "",
        code: "NOT_IMPLEMENTED"
      });
    }

    return { success: true };
  }
  async function putCategories({ category_id, body, logTrace }) {
    const knex = this;
    const query = knex(MAIN_CATEGORY.NAME).where(
      MAIN_CATEGORY.COLUMNS.ID,
      category_id
    );

    const exists_response = await query;

    if (!exists_response.length > 0) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_ACCEPTABLE,
        message: "Category not found to update",
        property: "",
        code: "NOT_ACCEPTABLE"
      });
    }

    const query_update = await knex(`${MAIN_CATEGORY.NAME}`)
      .where(`${MAIN_CATEGORY.COLUMNS.ID}`, category_id)
      .update({
        [MAIN_CATEGORY.COLUMNS.CATEGORY_NAME]: body.category_name,
        [MAIN_CATEGORY.COLUMNS.CATEGORY_IMAGE]: body.category_image,
        [MAIN_CATEGORY.COLUMNS.IS_ACTIVE]: body.is_active
      });

    const response = await query_update;
    if (!response) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_IMPLEMENTED,
        message: "Error while updatind category",
        property: "",
        code: "NOT_IMPLEMENTED"
      });
    }

    return { success: true };
  }
  async function getCategories({ logTrace }) {
    const knex = this;
    const query = knex(MAIN_CATEGORY.NAME)
      .where(MAIN_CATEGORY.COLUMNS.IS_ACTIVE, "1")
      .orderBy(MAIN_CATEGORY.COLUMNS.CATEGORY_NAME, "ASC");
    logQuery({
      logger: fastify.log,
      query,
      context: "Get Categories",
      logTrace
    });
    const response = await query;
    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "Categories not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
    return response;
  }
  async function getCategoriesPaginate({ params, logTrace }) {
    const knex = this;
    const query = knex(MAIN_CATEGORY.NAME).orderBy(
      MAIN_CATEGORY.COLUMNS.CATEGORY_NAME,
      "ASC"
    );
    logQuery({
      logger: fastify.log,
      query,
      context: "Get Categories",
      logTrace
    });
    const response = await query.paginate({
      pageSize: params.page_size, // Customize as needed
      currentPage: params.current_page // Customize as needed
    });
    if (!response.data.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "Categories not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
    if (response.meta.pagination.total_pages < params.current_page) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_ACCEPTABLE,
        message: "Requested page is beyond the available data",
        property: "",
        code: "NOT_ACCEPTABLE"
      });
    }

    return response;
  }
  async function deleteCategories({ category_id, body, logTrace }) {
    const knex = this;

    const query = knex(MAIN_CATEGORY.NAME).where(
      MAIN_CATEGORY.COLUMNS.ID,
      category_id
    );

    const exists_response = await query;

    if (!exists_response.length > 0) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_ACCEPTABLE,
        message: "Category not found to delete",
        property: "",
        code: "NOT_ACCEPTABLE"
      });
    }

    const query_delete = knex(MAIN_CATEGORY.NAME)
      .where(MAIN_CATEGORY.COLUMNS.ID, category_id)
      .del();
    logQuery({
      logger: fastify.log,
      query,
      context: "delete Categories",
      logTrace
    });
    const response = await query_delete;
    if (!response) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "Categories not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
    return { success: true };
  }

  async function getCategoriesInfo({ params, logTrace }) {
    const knex = this;
    const query = knex(MAIN_CATEGORY.NAME).where(
      MAIN_CATEGORY.COLUMNS.ID,
      params.category_id
    );
    logQuery({
      logger: fastify.log,
      query,
      context: "Get Categories Info",
      logTrace
    });
    const response = await query;
    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "Categories not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
    return response[0];
  }
  async function getHomeCategories({ category_id, logTrace }) {
    const knex = this;

    const response = await knex.transaction(async trx => {
      const query = knex(MAIN_CATEGORY.NAME)
        .where(MAIN_CATEGORY.COLUMNS.IS_ACTIVE, "1")
        .orderBy(MAIN_CATEGORY.COLUMNS.CATEGORY_NAME, "ASC");
      // const query = knex(SUB_CATEGORY.NAME)
      //   .where(SUB_CATEGORY.COLUMNS.IS_ACTIVE, true)
      //   .where(SUB_CATEGORY.COLUMNS.CATEGORY_ID, category_id)
      //   .orderBy(SUB_CATEGORY.COLUMNS.SUBCATEGORY_NAME, "ASC");

      logQuery({
        logger: fastify.log,
        query,
        context: "Get product list details",
        logTrace
      });

      const categories = await query;

      if (!categories.length) {
        throw CustomError.create({
          httpCode: StatusCodes.NOT_FOUND,
          message: "Products not found",
          property: "",
          code: "NOT_FOUND"
        });
      }

      const sub_category = await Promise.all(
        categories.map(async category => {
          const sub_categories = await trx(SUB_CATEGORY.NAME)
            .where(SUB_CATEGORY.COLUMNS.CATEGORY_ID, category.id)
            .where(SUB_CATEGORY.COLUMNS.IS_ACTIVE, true)
            .select(`${SUB_CATEGORY.NAME}.*`);

          return {
            ...category,
            sub_categories
          };
        })
      );

      return sub_category;
    });

    return response;
  }
  return {
    postCategories,
    putCategories,
    getCategories,
    deleteCategories,
    getCategoriesInfo,
    getCategoriesPaginate,
    getHomeCategories
  };
}

module.exports = mainCategoryRepo;
