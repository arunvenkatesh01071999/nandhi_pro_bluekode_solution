const patchCategoryImageSchema = require("./patchCategoryImage");
const postCategorySchema = require("./postCategorySchema");
const putCategorySchema = require("./putCategorySchema");
const getCategorySchema = require("./getCategorySchema");
const deleteCategorySchema = require("./deleteCategorySchema");
const getCategoryInfoSchema = require("./getCategoryInfoSchema");
const getCategoryPaginateSchema = require("./getCategoryPaginateSchema");
const getHomeCategorySchema = require("./getHomeCategorySchema");

module.exports = {
  patchCategoryImageSchema,
  postCategorySchema,
  putCategorySchema,
  getCategorySchema,
  deleteCategorySchema,
  getCategoryInfoSchema,
  getCategoryPaginateSchema,
  getHomeCategorySchema
};
