const { errorSchemas } = require("../../../commons/schemas/errorSchemas");

const getCategoryPaginateSchema = {
  tags: ["CATEGORY"],
  summary: "This API is to fetch categories",
  headers: { $ref: "request-headers#" },
  params: {
    type: "object",
    properties: {
      page_size: { type: "integer" },
      current_page: { type: "integer" }
    }
  },
  response: {
    200: {
      type: "object",
      properties: {
        data: {
          type: "array",
          items: {
            type: "object",
            properties: {
              id: { type: "integer" },
              category_name: { type: "string" },
              category_image: { type: "string" },
              is_active: { type: "boolean" }
            }
          }
        },
        meta: { $ref: "response-meta#" }
      }
    },
    ...errorSchemas
  }
};

module.exports = getCategoryPaginateSchema;
