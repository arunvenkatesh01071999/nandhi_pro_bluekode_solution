const schemas = require("../schemas");
const handlers = require("../handlers");

module.exports = async fastify => {

  fastify.route({
    method: "GET",
    url: "/outlet_item_filter/:outlet_id/:search?",
    preHandler: fastify.authenticate,
    // schema: schemas.getItemOutletSchema,
    handler: handlers.getItemOutletHandler(fastify)
  });

  fastify.route({
    method: "GET",
    url: "/Item",
    preHandler: fastify.authenticate,
    // schema: schemas.getItemSchema,
    handler: handlers.getItemHandler(fastify)
  });

  fastify.route({
    method: "GET",
    url: "/Item/purchase/product",
    preHandler: fastify.authenticate,
    schema: schemas.getItemPurchaseProductSchema,
    handler: handlers.getItemPurchaseProductHandler(fastify)
  })

  fastify.route({
    method: "POST",
    url: "/Item",
    preHandler: fastify.authenticate,
    schema: schemas.postItemSchema,
    handler: handlers.postItemHandler(fastify)
  });

  fastify.route({
    method: "PUT",
    url: "/Item/:id",
    preHandler: fastify.authenticate,
    schema: schemas.putItemSchema,
    handler: handlers.putItemHandler(fastify)
  });

  fastify.route({
    method: "POST",
    url: "/Item/barcode/dis/update",
    preHandler: fastify.authenticate,
    schema: schemas.putItemDiscountSchema,
    handler: handlers.putItemDiscountHandler(fastify)
  });

  fastify.route({
    method: "DELETE",
    url: "/Item/:id",
    preHandler: fastify.authenticate,
    schema: schemas.deleteItemSchema,
    handler: handlers.deleteItemHandler(fastify)
  });

  fastify.route({
    method: "GET",
    url: "/Item/:id",
    preHandler: fastify.authenticate,
    schema: schemas.getItemInfoSchema,
    handler: handlers.getItemInfoHandler(fastify)
  });

  fastify.route({
    method: "POST",
    url: "/Item/info/procode",
    // preHandler: fastify.authenticate,
    // schema: schemas.getItemInfoSchema,
    handler: handlers.getItemInfoWithProcodeHandler(fastify)
  });

  fastify.route({
    method: "GET",
    url: "/ItemCode/:code",
    preHandler: fastify.authenticate,
    // schema: schemas.getItemInfoSchema,
    handler: handlers.getItemCodeHandler(fastify)
  });

  fastify.route({
    method: "GET",
    url: "/Item/:page_size/:current_page/:search?",
    preHandler: fastify.authenticate,
    // schema: schemas.getItemPaginateSchema,
    handler: handlers.getItemPaginateHandler(fastify)
  });

  fastify.route({
    method: "GET",
    url: "/itemcode/:search?",
    preHandler: fastify.authenticate,
    handler: handlers.getItemSearch(fastify)
  });

  fastify.route({
    method: "GET",
    url: "/itemdetails/barcode/:barcode/:outlet_id?",
    // preHandler: fastify.authenticate,
    // schema: schemas.getBarcodeSchema,
    handler: handlers.getBarcodeSearch(fastify)
  });

  fastify.route({
    method: "GET",
    url: "/itemdetails/barcode/issue/:barcode",
    preHandler: fastify.authenticate,
    // schema: schemas.getBarcodeIssueSchema,
    handler: handlers.getBarcodeIssueSearch(fastify)
  });

  fastify.route({
    method: "GET",
    url: "/itemdetails/outlet/sales/product/:outlet_id/:barcode",
    preHandler: fastify.authenticate,
    schema: schemas.getItemDetailsOutletsSalesProductSchema,
    handler: handlers.getItemDetailsOutletsSalesProductHandler(fastify)
  });

  fastify.route({
    method: "GET",
    url: "/itemdetails/closingStock/barcode/:barcode/:outlet_id/:cat_id/:sub_cat_id",
    // preHandler: fastify.authenticate,
    // schema: schemas.getBarcodeSchema,
    handler: handlers.getClosingStockBarcodeSearch(fastify)
  });
};
