const { StatusCodes } = require("http-status-codes");
const { CustomError } = require("../../../errorHandler");
const { logQuery } = require("../../../commons/helpers");
const { ITEM, VENDORS_MAPPING } = require("../../commons");
const { OUTLET_PRODUCT_MAPPING } = require("../../commons");
const { TYPEDESIGN } = require("../../commons");
const { HEADS } = require("../../commons");
const { MAIN_CATEGORY } = require("../../category/commons/constants");
const { SUB_CATEGORY } = require("../../category/commons/constants");
const { UNITS } = require("../../units/commons/constants");
const { OUTLETS } = require("../../../accounts/outlets/commons/constants");
const { BARCODE_LIST } = require("../../../accounts/barcode/commons/constant")
// const { SUPPLIER } = require("D:\girlush-scm-api-services\src\app\catalog\commons.js")
const { SUPPLIER } = require("../../../../app/catalog/commons")
const { SALESDETAILS } = require("../../../sales/commons")
const { PURCHASE_DETAILS } = require("../../../purchase/commons")
const { OUTLETSALESDETAILS } = require("../../../outlet_sales/outlet_sales_master/commons/constants")
const { CLOSING_STOCK_TEMP } = require("../../../closing_stock/commons");





function itemRepo(fastify) {


  async function getItemDetailsOutletsSalesProduct({ body, params, logTrace }) {
    const knex = this;


    const query = knex(BARCODE_LIST.NAME)
      .select(
        // `${BARCODE_LIST.NAME}.*`,
        `${ITEM.NAME}.*`,
        `${BARCODE_LIST.NAME}.${BARCODE_LIST.COLUMNS.BARCODE} as product_barcode`,
        // `${ITEM.NAME}.${ITEM.COLUMNS.BALANCE} as qty`, // Cast to numeric
        `${OUTLET_PRODUCT_MAPPING.NAME}.${OUTLET_PRODUCT_MAPPING.COLUMNS.OPENING_STOCK} as outlet_opening_stock`,
        `${OUTLET_PRODUCT_MAPPING.NAME}.${OUTLET_PRODUCT_MAPPING.COLUMNS.BALENCE_STOCK} as outlet_balance_stock`,
        `${OUTLET_PRODUCT_MAPPING.NAME}.${OUTLET_PRODUCT_MAPPING.COLUMNS.MIN_STOCK} as outlet_min_stock`,
        `${OUTLET_PRODUCT_MAPPING.NAME}.${OUTLET_PRODUCT_MAPPING.COLUMNS.ALLOW_NEG_STK} as outlet_allow_neg_stock`,
        `${OUTLET_PRODUCT_MAPPING.NAME}.${OUTLET_PRODUCT_MAPPING.COLUMNS.WSCALE} as outlet_wscale`,
        `${OUTLET_PRODUCT_MAPPING.NAME}.${OUTLET_PRODUCT_MAPPING.COLUMNS.MIN_WARN_STOCK} as outlet_min_warn_stock`

      )
      .leftJoin(
        ITEM.NAME,
        `${ITEM.NAME}.${ITEM.COLUMNS.ID}`,
        '=',
        `${BARCODE_LIST.NAME}.${BARCODE_LIST.COLUMNS.PROD_ID}`
      )
      .leftJoin(
        `${OUTLET_PRODUCT_MAPPING.NAME} as ${OUTLET_PRODUCT_MAPPING.NAME}`,
        `${ITEM.NAME}.${ITEM.COLUMNS.ID}`,
        `${OUTLET_PRODUCT_MAPPING.NAME}.${OUTLET_PRODUCT_MAPPING.COLUMNS.PRODUCT_ID}`
      )
      .andWhere(
        `${OUTLET_PRODUCT_MAPPING.NAME}.${OUTLET_PRODUCT_MAPPING.COLUMNS.OUTLET_ID}`,
        params.outlet_id)
      .where(`${BARCODE_LIST.NAME}.${BARCODE_LIST.COLUMNS.BARCODE}`, params.barcode)
      .orWhere(`${BARCODE_LIST.NAME}.${BARCODE_LIST.COLUMNS.PRODUCT_CODE}`, params.barcode)

    logQuery({
      logger: fastify.log,
      query,
      context: "Get item",
      logTrace
    });
    const response = await query;
    console.log(response, "response");

    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "Item not found",
        property: "",
        code: "NOT_FOUND"
      });
    }

    let transformedResponse = response.map((item) => {

      let min_warn_stock = item.outlet_min_warn_stock || false;
      let negative_stock = item.outlet_allow_neg_stock;
      let balance_stock = item.outlet_balance_stock;
      let min_stock = item.outlet_min_stock;

      let min_stock_waring_message = "";
      let min_stock_waring_flag = false;

      if (min_warn_stock) {
        if (Number(balance_stock) <= Number(min_stock)) {
          min_stock_waring_message = "Product reaches the Minimum Stock Level...";
          min_stock_waring_flag = true;
        }
      }
      if (negative_stock == false && Number(balance_stock) <= 0) {
        throw CustomError.create({
          httpCode: StatusCodes.NOT_ACCEPTABLE,
          message: "Negative Stock Not Allowed...",
          property: "",
          code: "NOT_ACCEPTABLE"
        });
      }
      return {
        ...item,
        min_stock_waring_message,
        min_stock_waring_flag,
      };
    })


    return transformedResponse;
  }
  async function getItemOutlet({ body, params, logTrace }) {
    const knex = this;

    var itemWithOutlets = knex
      .distinct([`${ITEM.NAME}.*`])
      .from(`${ITEM.NAME} as ${ITEM.NAME}`)
      .innerJoin(
        `${OUTLET_PRODUCT_MAPPING.NAME} as ${OUTLET_PRODUCT_MAPPING.NAME}`,
        `${ITEM.NAME}.${ITEM.COLUMNS.ID}`,
        `${OUTLET_PRODUCT_MAPPING.NAME}.${OUTLET_PRODUCT_MAPPING.COLUMNS.PRODUCT_ID}`
      )
      .where(
        `${OUTLET_PRODUCT_MAPPING.NAME}.${OUTLET_PRODUCT_MAPPING.COLUMNS.OUTLET_ID}`,
        params.outlet_id
      )

    if (params.search && params.search.length >= 3) {
      itemWithOutlets.where(function () {
        // console.log("search");
        this.where(
          `${ITEM.NAME}.${ITEM.COLUMNS.PRODUCT_NAME}`,
          "ilike",
          `%${params.search}%`
        )
      });
    }


    const response = await itemWithOutlets;
    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "Item not found",
        property: "",
        code: "NOT_FOUND"
      });
    }

    return response;
  }

  async function getItemPurchaseProduct({ logTrace }) {
    const knex = this;

    const query = knex
      .select([
        `${ITEM.NAME}.${ITEM.COLUMNS.ID} as main_product_id`,
        `${ITEM.NAME}.${ITEM.COLUMNS.PRODUCT_NAME}`,
        // `${UNITS.NAME}.${UNITS.COLUMNS.UNITS_SHORT_NAME} as uom_name`,
        // `${HEADS.NAME}.${HEADS.COLUMNS.CATEOGORY_NAME} as head_name`,
        // `${TYPEDESIGN.NAME}.${TYPEDESIGN.COLUMNS.TYPE_NAME} as type_name`,
        // `${MAIN_CATEGORY.NAME}.${MAIN_CATEGORY.COLUMNS.CATEGORY_NAME} as cat_name`,
        // `${SUB_CATEGORY.NAME}.${SUB_CATEGORY.COLUMNS.SUBCATEGORY_NAME} as sub_cat_name`
      ])
      .from(`${ITEM.NAME} as ${ITEM.NAME}`)
      // .leftJoin(
      //   `${UNITS.NAME} as ${UNITS.NAME}`,
      //   `${ITEM.NAME}.${ITEM.COLUMNS.UOM}`,
      //   `${UNITS.NAME}.${UNITS.COLUMNS.ID}`
      // )
      // .leftJoin(
      //   `${HEADS.NAME} as ${HEADS.NAME}`,
      //   `${ITEM.NAME}.${ITEM.COLUMNS.HEADID}`,
      //   `${HEADS.NAME}.${HEADS.COLUMNS.ID}`
      // )
      // .leftJoin(
      //   `${TYPEDESIGN.NAME} as ${TYPEDESIGN.NAME}`,
      //   `${ITEM.NAME}.${ITEM.COLUMNS.TYPE}`,
      //   `${TYPEDESIGN.NAME}.${TYPEDESIGN.COLUMNS.ID}`
      // )
      // .leftJoin(
      //   `${MAIN_CATEGORY.NAME} as ${MAIN_CATEGORY.NAME}`,
      //   `${ITEM.NAME}.${ITEM.COLUMNS.CATID}`,
      //   `${MAIN_CATEGORY.NAME}.${MAIN_CATEGORY.COLUMNS.ID}`
      // )
      // .leftJoin(
      //   `${SUB_CATEGORY.NAME} as ${SUB_CATEGORY.NAME}`,
      //   `${ITEM.NAME}.${ITEM.COLUMNS.SUB_CATEGORY}`,
      //   `${SUB_CATEGORY.NAME}.${SUB_CATEGORY.COLUMNS.ID}`
      // )
      .where(
        `${ITEM.NAME}.${ITEM.COLUMNS.PRODUCT_TYPE}`, "purchase"
      )
      .orderBy(ITEM.COLUMNS.ID, "DESC");

    logQuery({
      logger: fastify.log,
      query,
      context: "Get Item",
      logTrace
    });
    const response = await query;
    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "Item not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
    return response;
  }
  async function getItem({ logTrace }) {
    const knex = this;
    // const query = knex(ITEM.NAME).where(ITEM.COLUMNS.IS_ACTIVE, "1");
    // outlet product map

    const query = knex
      .select([
        `${ITEM.NAME}.*`,
        `${UNITS.NAME}.${UNITS.COLUMNS.UNITS_SHORT_NAME} as uom_name`,
        `${HEADS.NAME}.${HEADS.COLUMNS.CATEOGORY_NAME} as head_name`,
        `${TYPEDESIGN.NAME}.${TYPEDESIGN.COLUMNS.TYPE_NAME} as type_name`,
        `${MAIN_CATEGORY.NAME}.${MAIN_CATEGORY.COLUMNS.CATEGORY_NAME} as cat_name`,
        `${SUB_CATEGORY.NAME}.${SUB_CATEGORY.COLUMNS.SUBCATEGORY_NAME} as sub_cat_name`
      ])
      .from(`${ITEM.NAME} as ${ITEM.NAME}`)
      .leftJoin(
        `${UNITS.NAME} as ${UNITS.NAME}`,
        `${ITEM.NAME}.${ITEM.COLUMNS.UOM}`,
        `${UNITS.NAME}.${UNITS.COLUMNS.ID}`
      )
      .leftJoin(
        `${HEADS.NAME} as ${HEADS.NAME}`,
        `${ITEM.NAME}.${ITEM.COLUMNS.HEADID}`,
        `${HEADS.NAME}.${HEADS.COLUMNS.ID}`
      )
      .leftJoin(
        `${TYPEDESIGN.NAME} as ${TYPEDESIGN.NAME}`,
        `${ITEM.NAME}.${ITEM.COLUMNS.TYPE}`,
        `${TYPEDESIGN.NAME}.${TYPEDESIGN.COLUMNS.ID}`
      )
      .leftJoin(
        `${MAIN_CATEGORY.NAME} as ${MAIN_CATEGORY.NAME}`,
        `${ITEM.NAME}.${ITEM.COLUMNS.CATID}`,
        `${MAIN_CATEGORY.NAME}.${MAIN_CATEGORY.COLUMNS.ID}`
      )
      .leftJoin(
        `${SUB_CATEGORY.NAME} as ${SUB_CATEGORY.NAME}`,
        `${ITEM.NAME}.${ITEM.COLUMNS.SUB_CATEGORY}`,
        `${SUB_CATEGORY.NAME}.${SUB_CATEGORY.COLUMNS.ID}`
      )
      .orderBy(ITEM.COLUMNS.ID, "DESC");

    logQuery({
      logger: fastify.log,
      query,
      context: "Get Item",
      logTrace
    });
    const response = await query;
    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "Item not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
    // return response;
    const itemWithOutlets = await Promise.all(
      response.map(async item => {

        const outlets = await knex
          .select([`${OUTLETS.NAME}.*`])
          .from(`${OUTLET_PRODUCT_MAPPING.NAME} as ${OUTLET_PRODUCT_MAPPING.NAME}`)
          .leftJoin(
            `${OUTLETS.NAME} as ${OUTLETS.NAME}`,
            `${OUTLET_PRODUCT_MAPPING.NAME}.${OUTLET_PRODUCT_MAPPING.COLUMNS.OUTLET_ID}`,
            `${OUTLETS.NAME}.${OUTLETS.COLUMNS.ID}`
          )
          .where(
            `${OUTLET_PRODUCT_MAPPING.NAME}.${OUTLET_PRODUCT_MAPPING.COLUMNS.IS_ACTIVE}`,
            true
          )
          .where(
            `${OUTLET_PRODUCT_MAPPING.NAME}.${OUTLET_PRODUCT_MAPPING.COLUMNS.PRODUCT_ID}`,
            item.id
          );
        const vendors = await knex
          .select([`${SUPPLIER.NAME}.*`])
          .from(`${VENDORS_MAPPING.NAME} as ${VENDORS_MAPPING.NAME}`)
          .leftJoin(
            `${SUPPLIER.NAME} as ${SUPPLIER.NAME}`,
            `${VENDORS_MAPPING.NAME}.${VENDORS_MAPPING.COLUMNS.VENDORS_ID}`,//22222
            `${SUPPLIER.NAME}.${SUPPLIER.COLUMNS.ID}`//123
          )
          .where(
            `${VENDORS_MAPPING.NAME}.${VENDORS_MAPPING.COLUMNS.IS_ACTIVE}`,
            true
          )
          .where(
            `${VENDORS_MAPPING.NAME}.${VENDORS_MAPPING.COLUMNS.PRODUCT_ID}`,
            item.id
          );


        return { ...item, outlets, vendors };
      })
    );


    return itemWithOutlets;
  }

  async function getItemPaginate({ params, logTrace }) {

    const knex = this;
    const query = knex
      .select([
        `${ITEM.NAME}.*`,
        `${UNITS.NAME}.${UNITS.COLUMNS.UNITS_SHORT_NAME} as uom_name`,
        `${HEADS.NAME}.${HEADS.COLUMNS.CATEOGORY_NAME} as head_name`,
        `${TYPEDESIGN.NAME}.${TYPEDESIGN.COLUMNS.TYPE_NAME} as type_name`,
        `${MAIN_CATEGORY.NAME}.${MAIN_CATEGORY.COLUMNS.CATEGORY_NAME} as cat_name`,
        `${SUB_CATEGORY.NAME}.${SUB_CATEGORY.COLUMNS.SUBCATEGORY_NAME} as sub_cat_name`
      ])
      .from(`${ITEM.NAME} as ${ITEM.NAME}`)
      .leftJoin(
        `${UNITS.NAME} as ${UNITS.NAME}`,
        `${ITEM.NAME}.${ITEM.COLUMNS.UOM}`,
        `${UNITS.NAME}.${UNITS.COLUMNS.ID}`
      )
      .leftJoin(
        `${HEADS.NAME} as ${HEADS.NAME}`,
        `${ITEM.NAME}.${ITEM.COLUMNS.HEADID}`,
        `${HEADS.NAME}.${HEADS.COLUMNS.ID}`
      )
      .leftJoin(
        `${TYPEDESIGN.NAME} as ${TYPEDESIGN.NAME}`,
        `${ITEM.NAME}.${ITEM.COLUMNS.TYPE}`,
        `${TYPEDESIGN.NAME}.${TYPEDESIGN.COLUMNS.ID}`
      )
      .leftJoin(
        `${MAIN_CATEGORY.NAME} as ${MAIN_CATEGORY.NAME}`,
        `${ITEM.NAME}.${ITEM.COLUMNS.CATID}`,
        `${MAIN_CATEGORY.NAME}.${MAIN_CATEGORY.COLUMNS.ID}`
      )
      .leftJoin(
        `${SUB_CATEGORY.NAME} as ${SUB_CATEGORY.NAME}`,
        `${ITEM.NAME}.${ITEM.COLUMNS.SUB_CATEGORY}`,
        `${SUB_CATEGORY.NAME}.${SUB_CATEGORY.COLUMNS.ID}`
      )
      .orderBy(ITEM.COLUMNS.ID, "DESC");

    if (params.search && params.search.length >= 3) {
      query.where(function () {
        this.where(knex.raw('UPPER(??) LIKE ?', [ITEM.COLUMNS.PRODUCT_NAME, `%${params.search.toUpperCase()}%`]));
      });
    }

    logQuery({
      logger: fastify.log,
      query,
      context: "Get Item",
      logTrace
    });

    const response = await query.paginate({
      pageSize: params.page_size, // Customize as needed
      currentPage: params.current_page // Customize as needed
    });
    if (!response.data.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "Item not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
    if (response.meta.pagination.total_pages < params.current_page) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_ACCEPTABLE,
        message: "Requested page is beyond the available data",
        property: "",
        code: "NOT_ACCEPTABLE"
      });
    }

    const itemWithOutlets = await Promise.all(
      response.data.map(async item => {

        const outlets = await knex
          // .select([`${OUTLETS.NAME}.*`])
          .select([`${OUTLETS.NAME}.*`,
          `${OUTLET_PRODUCT_MAPPING.NAME}.${OUTLET_PRODUCT_MAPPING.COLUMNS.OPENING_STOCK} as outlet_opng_stock`,
          `${OUTLET_PRODUCT_MAPPING.NAME}.${OUTLET_PRODUCT_MAPPING.COLUMNS.BALENCE_STOCK} as outlet_balnc_stock`,
          `${OUTLET_PRODUCT_MAPPING.NAME}.${OUTLET_PRODUCT_MAPPING.COLUMNS.MIN_STOCK} as outlet_min_stock`,
          `${OUTLET_PRODUCT_MAPPING.NAME}.${OUTLET_PRODUCT_MAPPING.COLUMNS.ALLOW_NEG_STK} as outlet_allow_neg_stk`,
          `${OUTLET_PRODUCT_MAPPING.NAME}.${OUTLET_PRODUCT_MAPPING.COLUMNS.WSCALE} as outlet_wscale`
          ])
          .from(`${OUTLET_PRODUCT_MAPPING.NAME} as ${OUTLET_PRODUCT_MAPPING.NAME}`)
          .leftJoin(
            `${OUTLETS.NAME} as ${OUTLETS.NAME}`,
            `${OUTLET_PRODUCT_MAPPING.NAME}.${OUTLET_PRODUCT_MAPPING.COLUMNS.OUTLET_ID}`,
            `${OUTLETS.NAME}.${OUTLETS.COLUMNS.ID}`
          )
          .where(
            `${OUTLET_PRODUCT_MAPPING.NAME}.${OUTLET_PRODUCT_MAPPING.COLUMNS.IS_ACTIVE}`,
            true
          )
          .where(
            `${OUTLET_PRODUCT_MAPPING.NAME}.${OUTLET_PRODUCT_MAPPING.COLUMNS.PRODUCT_ID}`,
            item.id
          );

        const vendors = await knex
          .select([`${SUPPLIER.NAME}.*`])
          .from(`${VENDORS_MAPPING.NAME} as ${VENDORS_MAPPING.NAME}`)
          .leftJoin(
            `${SUPPLIER.NAME} as ${SUPPLIER.NAME}`,
            `${VENDORS_MAPPING.NAME}.${VENDORS_MAPPING.COLUMNS.VENDORS_ID}`,
            `${SUPPLIER.NAME}.${SUPPLIER.COLUMNS.ID}`
          )
          .where(
            `${VENDORS_MAPPING.NAME}.${VENDORS_MAPPING.COLUMNS.IS_ACTIVE}`,
            true
          )
          .where(
            `${VENDORS_MAPPING.NAME}.${VENDORS_MAPPING.COLUMNS.PRODUCT_ID}`,
            item.id
          );

        const barcode_list = await knex
          .select([`${BARCODE_LIST.NAME}.*`])
          .from(`${BARCODE_LIST.NAME} as ${BARCODE_LIST.NAME}`)
          .leftJoin(
            `${ITEM.NAME} as ${ITEM.NAME}`,
            `${BARCODE_LIST.NAME}.${BARCODE_LIST.COLUMNS.PROD_ID}`,
            `${ITEM.NAME}.${ITEM.COLUMNS.ID}`
          )
          .where(
            `${BARCODE_LIST.NAME}.${BARCODE_LIST.COLUMNS.IS_ACTIVE}`,
            true
          )
          .where(
            `${BARCODE_LIST.NAME}.${BARCODE_LIST.COLUMNS.PROD_ID}`,
            item.id
          );


        return { ...item, outlets, vendors, barcode_list };
      })
    );
    const combinedResponse = {
      data: itemWithOutlets,
      meta: response.meta
    };

    return combinedResponse;


  }

  async function postItem({ params, body, logTrace, userDetails }) {
    const knex = this;
    const query = knex(ITEM.NAME)
      .where(ITEM.COLUMNS.PRODUCT_NAME, body.pro_name)

    const exists_response = await query;

    if (exists_response.length > 0) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_ACCEPTABLE,
        message: "Item Name Already Exists",
        property: "",
        code: "NOT_ACCEPTABLE"
      });
    }

    const query_insert = await knex(`${ITEM.NAME}`)
      .returning("id")
      .insert({
        [ITEM.COLUMNS.PRODUCT_CODE]: body.pro_code,
        [ITEM.COLUMNS.PRODUCT_NAME]: body.pro_name,
        [ITEM.COLUMNS.SHORT_NAME]: body.short_name || null,
        [ITEM.COLUMNS.PRO_DESCRIPTION]: body.pro_description || null,
        [ITEM.COLUMNS.MANUFACTURING_DATE]: body.manufacturing_date || null,
        [ITEM.COLUMNS.EXPIRY_DATE]: body.expiry_date || null,
        [ITEM.COLUMNS.TYPE]: body.type,
        [ITEM.COLUMNS.SUB_CATEGORY]: body.sub_cat,
        [ITEM.COLUMNS.UOM]: body.uom,
        [ITEM.COLUMNS.BARCODE]: body.barcode,
        [ITEM.COLUMNS.PARCHASE_RATE]: body.pur_rate,
        [ITEM.COLUMNS.SALE_RATE]: body.sale_rate,
        [ITEM.COLUMNS.WHOLESALE_RATE]: body.wholesale_rate,
        [ITEM.COLUMNS.MRP]: body.mrp,
        [ITEM.COLUMNS.GST]: body.gst,
        [ITEM.COLUMNS.CESS]: body.cess,
        [ITEM.COLUMNS.HSN]: body.hsn,
        [ITEM.COLUMNS.OP_STK]: body.op_stk,
        [ITEM.COLUMNS.BALANCE]: body.balance,
        [ITEM.COLUMNS.MIN_STOCK]: body.min_stock,
        [ITEM.COLUMNS.ALLOW_NEG_STK]: body.allow_neg_stock,
        [ITEM.COLUMNS.WSCALE]: body.wscale,
        [ITEM.COLUMNS.HEADID]: body.head_id,
        [ITEM.COLUMNS.CATID]: body.cat_id,
        [ITEM.COLUMNS.COMPANY_ID]: 1,
        [ITEM.COLUMNS.IS_ACTIVE]: body.is_active,
        [ITEM.COLUMNS.CREATED_BY]: userDetails.id,
        [ITEM.COLUMNS.PRODUCT_TYPE]: body.product_type,
        [ITEM.COLUMNS.MAIN_UOM_ID]: body.main_uom_id,
        [ITEM.COLUMNS.CONVERTION_FACTOR]: body.convertion_factor,
        [ITEM.COLUMNS.MAIN_PRODUCT_ID]: body.main_product_id

      });

    const response = await query_insert;

    if (!response) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_IMPLEMENTED,
        message: "Error while creating Item",
        property: "",
        code: "NOT_IMPLEMENTED"
      });
    }

    const pro_id = response[0].id;

    if (body.outlets.length > 0) {

      const outlets = body.outlets.map(outlet => ({
        [OUTLET_PRODUCT_MAPPING.COLUMNS.PRODUCT_CODE]: body.pro_code,
        [OUTLET_PRODUCT_MAPPING.COLUMNS.OUTLET_ID]: outlet.outlet_id,
        [OUTLET_PRODUCT_MAPPING.COLUMNS.PRODUCT_ID]: pro_id,
        [OUTLET_PRODUCT_MAPPING.COLUMNS.OPENING_STOCK]: outlet.outlet_opng_stock,
        [OUTLET_PRODUCT_MAPPING.COLUMNS.BALENCE_STOCK]: outlet.outlet_balnc_stock,
        [OUTLET_PRODUCT_MAPPING.COLUMNS.MIN_STOCK]: outlet.outlet_min_stock,
        [OUTLET_PRODUCT_MAPPING.COLUMNS.ALLOW_NEG_STK]: outlet.outlet_allow_neg_stk,
        [OUTLET_PRODUCT_MAPPING.COLUMNS.WSCALE]: outlet.outlet_wscale,
        [OUTLET_PRODUCT_MAPPING.COLUMNS.COMPANY_ID]: 1,
        [OUTLET_PRODUCT_MAPPING.COLUMNS.CREATED_BY]: userDetails.id,
        [OUTLET_PRODUCT_MAPPING.COLUMNS.IS_ACTIVE]: body.is_active
      }));

      const insertedRoles = await knex(`${OUTLET_PRODUCT_MAPPING.NAME}`).insert(
        outlets
      );
      if (!insertedRoles) {
        throw CustomError.create({
          httpCode: StatusCodes.NOT_IMPLEMENTED,
          message: "Error while creating Role Mapping",
          property: "",
          code: "NOT_IMPLEMENTED"
        });
      }
    }


    if (body.vendors.length > 0) {

      const vendors = body.vendors.map(vendor => ({
        [VENDORS_MAPPING.COLUMNS.VENDORS_ID]: vendor.vendor_id,
        [VENDORS_MAPPING.COLUMNS.PRODUCT_CODE]: body.pro_code,
        [VENDORS_MAPPING.COLUMNS.PRODUCT_ID]: pro_id,
        [VENDORS_MAPPING.COLUMNS.COMPANY_ID]: 1,
        [VENDORS_MAPPING.COLUMNS.CREATED_BY]: userDetails.id,
        [VENDORS_MAPPING.COLUMNS.IS_ACTIVE]: body.is_active
      }));

      const insertedVendors = await knex(`${VENDORS_MAPPING.NAME}`).insert(
        vendors
      );
      if (!insertedVendors) {
        throw CustomError.create({
          httpCode: StatusCodes.NOT_IMPLEMENTED,
          message: "Error while creating Vendors Mapping",
          property: "",
          code: "NOT_IMPLEMENTED"
        });
      }
    }

    if (body.barcode_details.length > 0) {

      const barcode_generate = body.barcode_details.map(bar => ({
        [BARCODE_LIST.COLUMNS.PROD_ID]: pro_id,
        [BARCODE_LIST.COLUMNS.PRODUCT_CODE]: body.pro_code,
        [BARCODE_LIST.COLUMNS.BARCODE]: bar.barcode,
        [BARCODE_LIST.COLUMNS.CREATED_BY]: userDetails.id
      }));

      const insertedBarcode = await knex(`${BARCODE_LIST.NAME}`).insert(
        barcode_generate
      );

      if (!insertedBarcode) {
        throw CustomError.create({
          httpCode: StatusCodes.NOT_IMPLEMENTED,
          message: "Error while creating barcode inserting",
          property: "",
          code: "NOT_IMPLEMENTED"
        });
      }
    }


    return { success: true };
  }

  async function putItem({ id, body, logTrace, userDetails }) {
    const knex = this;
    const query = knex(ITEM.NAME).where(ITEM.COLUMNS.ID, id);

    const exists_response = await query;
    if (!exists_response.length > 0) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_ACCEPTABLE,
        message: "Item not found to update",
        property: "",
        code: "NOT_ACCEPTABLE"
      });
    }

    const query_update = await knex(`${ITEM.NAME}`)
      .where(`${ITEM.COLUMNS.ID}`, id)
      .update({
        [ITEM.COLUMNS.PRODUCT_CODE]: body.pro_code,
        [ITEM.COLUMNS.PRODUCT_NAME]: body.pro_name,
        [ITEM.COLUMNS.SHORT_NAME]: body.short_name || null,
        [ITEM.COLUMNS.PRO_DESCRIPTION]: body.pro_description || null,
        [ITEM.COLUMNS.MANUFACTURING_DATE]: body.manufacturing_date || null,
        [ITEM.COLUMNS.EXPIRY_DATE]: body.expiry_date || null,
        [ITEM.COLUMNS.TYPE]: body.type,
        [ITEM.COLUMNS.SUB_CATEGORY]: body.sub_cat,
        [ITEM.COLUMNS.UOM]: body.uom,
        [ITEM.COLUMNS.BARCODE]: body.barcode,
        [ITEM.COLUMNS.PARCHASE_RATE]: body.pur_rate,
        [ITEM.COLUMNS.SALE_RATE]: body.sale_rate,
        [ITEM.COLUMNS.WHOLESALE_RATE]: body.wholesale_rate,
        [ITEM.COLUMNS.MRP]: body.mrp,
        [ITEM.COLUMNS.GST]: body.gst,
        [ITEM.COLUMNS.CESS]: body.cess,
        [ITEM.COLUMNS.HSN]: body.hsn,
        [ITEM.COLUMNS.OP_STK]: body.op_stk,
        [ITEM.COLUMNS.BALANCE]: body.balance,
        [ITEM.COLUMNS.MIN_STOCK]: body.min_stock,
        [ITEM.COLUMNS.ALLOW_NEG_STK]: body.allow_neg_stock,
        [ITEM.COLUMNS.WSCALE]: body.wscale,
        [ITEM.COLUMNS.VENDOR]: body.vendor,
        [ITEM.COLUMNS.HEADID]: body.head_id,
        [ITEM.COLUMNS.CATID]: body.cat_id,
        [ITEM.COLUMNS.COMPANY_ID]: 1,
        [ITEM.COLUMNS.IS_ACTIVE]: body.is_active,
        [ITEM.COLUMNS.UPDATED_BY]: userDetails.id,
        [ITEM.COLUMNS.UPDATED_AT]: new Date(),
        [ITEM.COLUMNS.CREATED_BY]: userDetails.id,
        [ITEM.COLUMNS.PRODUCT_TYPE]: body.product_type,
        [ITEM.COLUMNS.MAIN_UOM_ID]: body.main_uom_id,
        [ITEM.COLUMNS.CONVERTION_FACTOR]: body.convertion_factor

      });

    const response = await query_update;
    if (!response) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_IMPLEMENTED,
        message: "Error while updatind Item",
        property: "",
        code: "NOT_IMPLEMENTED"
      });
    }

    if (body.product_type == "sales") {

      const update_main_product_id_query = await knex(ITEM.NAME)
        .where(ITEM.COLUMNS.ID, id)
        .update({
          [ITEM.COLUMNS.MAIN_PRODUCT_ID]: id,
        })
    } else {
      const update_main_product_id_query = await knex(ITEM.NAME)
        .where(ITEM.COLUMNS.ID, id)
        .update({
          [ITEM.COLUMNS.MAIN_PRODUCT_ID]: null,
        })
    }


    if (body.outlets.length > 0) {
      const query_update1 = await knex(`${OUTLET_PRODUCT_MAPPING.NAME}`)
        .where(`${OUTLET_PRODUCT_MAPPING.COLUMNS.PRODUCT_ID}`, id)
        .where(`${OUTLET_PRODUCT_MAPPING.COLUMNS.COMPANY_ID}`, 1)
        .update({
          [OUTLET_PRODUCT_MAPPING.COLUMNS.IS_ACTIVE]: false,
          [OUTLET_PRODUCT_MAPPING.COLUMNS.UPDATED_BY]: userDetails.id,
          [OUTLET_PRODUCT_MAPPING.COLUMNS.CREATED_AT]: new Date(),
          [OUTLET_PRODUCT_MAPPING.COLUMNS.UPDATED_AT]: new Date(),
        });
      const outlets_logic = await Promise.all(
        body.outlets.map(async outlet => {
          const outlets = {
            [OUTLET_PRODUCT_MAPPING.COLUMNS.PRODUCT_CODE]: body.pro_code,
            [OUTLET_PRODUCT_MAPPING.COLUMNS.OUTLET_ID]: outlet.outlet_id,
            [OUTLET_PRODUCT_MAPPING.COLUMNS.PRODUCT_ID]: id,
            [OUTLET_PRODUCT_MAPPING.COLUMNS.OPENING_STOCK]: outlet.outlet_opng_stock,
            [OUTLET_PRODUCT_MAPPING.COLUMNS.BALENCE_STOCK]: outlet.outlet_balnc_stock,
            [OUTLET_PRODUCT_MAPPING.COLUMNS.MIN_STOCK]: outlet.outlet_min_stock,
            [OUTLET_PRODUCT_MAPPING.COLUMNS.ALLOW_NEG_STK]: outlet.outlet_allow_neg_stk,
            [OUTLET_PRODUCT_MAPPING.COLUMNS.WSCALE]: outlet.outlet_wscale,
            [OUTLET_PRODUCT_MAPPING.COLUMNS.COMPANY_ID]: 1,
            [OUTLET_PRODUCT_MAPPING.COLUMNS.CREATED_BY]: userDetails.id,
            [OUTLET_PRODUCT_MAPPING.COLUMNS.IS_ACTIVE]: body.is_active,
            [OUTLET_PRODUCT_MAPPING.COLUMNS.CREATED_AT]: new Date(),
          };
          const query_check = knex(OUTLET_PRODUCT_MAPPING.NAME)
            .where(OUTLET_PRODUCT_MAPPING.COLUMNS.PRODUCT_ID, id)
            .where(OUTLET_PRODUCT_MAPPING.COLUMNS.OUTLET_ID, outlet.outlet_id);

          const check_response = await query_check;
          if (check_response.length > 0) {
            const query_update2 = await knex(`${OUTLET_PRODUCT_MAPPING.NAME}`)
              .where(`${OUTLET_PRODUCT_MAPPING.COLUMNS.PRODUCT_ID}`, id)
              .where(`${OUTLET_PRODUCT_MAPPING.COLUMNS.COMPANY_ID}`, 1)
              .where(`${OUTLET_PRODUCT_MAPPING.COLUMNS.OUTLET_ID}`, outlet.outlet_id)
              .update({
                [OUTLET_PRODUCT_MAPPING.COLUMNS.OPENING_STOCK]: outlet.outlet_opng_stock,
                [OUTLET_PRODUCT_MAPPING.COLUMNS.BALENCE_STOCK]: outlet.outlet_balnc_stock,
                [OUTLET_PRODUCT_MAPPING.COLUMNS.MIN_STOCK]: outlet.outlet_min_stock,
                [OUTLET_PRODUCT_MAPPING.COLUMNS.ALLOW_NEG_STK]: outlet.outlet_allow_neg_stk,
                [OUTLET_PRODUCT_MAPPING.COLUMNS.WSCALE]: outlet.outlet_wscale,
                [OUTLET_PRODUCT_MAPPING.COLUMNS.IS_ACTIVE]: true,
                [OUTLET_PRODUCT_MAPPING.COLUMNS.UPDATED_BY]: userDetails.id,
                [OUTLET_PRODUCT_MAPPING.COLUMNS.UPDATED_AT]: new Date(),
                [OUTLET_PRODUCT_MAPPING.COLUMNS.CREATED_AT]: new Date()
              });
          } else {
            await knex(`${OUTLET_PRODUCT_MAPPING.NAME}`)
              .insert(outlets);
          }
        })
      );
    }

    if (body.vendors.length > 0) {
      const query_update1 = await knex(`${VENDORS_MAPPING.NAME}`)
        .where(`${VENDORS_MAPPING.COLUMNS.PRODUCT_ID}`, id)//43
        .where(`${VENDORS_MAPPING.COLUMNS.COMPANY_ID}`, 1)//3
        .update({
          [VENDORS_MAPPING.COLUMNS.IS_ACTIVE]: false,
          [VENDORS_MAPPING.COLUMNS.UPDATED_BY]: userDetails.id,
          [VENDORS_MAPPING.COLUMNS.UPDATED_AT]: new Date(),
        });

      const outlets_logic = await Promise.all(
        body.vendors.map(async vendor => {
          const vendors = {
            [VENDORS_MAPPING.COLUMNS.PRODUCT_CODE]: body.pro_code,
            [VENDORS_MAPPING.COLUMNS.PRODUCT_ID]: id,
            [VENDORS_MAPPING.COLUMNS.VENDORS_ID]: vendor.vendor_id,
            [VENDORS_MAPPING.COLUMNS.COMPANY_ID]: body.company_id,
            [VENDORS_MAPPING.COLUMNS.CREATED_BY]: userDetails.id,
            [VENDORS_MAPPING.COLUMNS.IS_ACTIVE]: body.is_active
          };
          const query_check = knex(VENDORS_MAPPING.NAME).where(VENDORS_MAPPING.COLUMNS.PRODUCT_ID, id)
            .where(VENDORS_MAPPING.COLUMNS.VENDORS_ID, vendor.vendor_id);

          const check_response = await query_check;
          if (check_response.length > 0) {
            const query_update2 = await knex(`${VENDORS_MAPPING.NAME}`)
              .where(`${VENDORS_MAPPING.COLUMNS.PRODUCT_ID}`, id)
              .where(`${VENDORS_MAPPING.COLUMNS.COMPANY_ID}`, 1)
              .where(`${VENDORS_MAPPING.COLUMNS.VENDORS_ID}`, vendor.vendor_id)
              .update({
                [VENDORS_MAPPING.COLUMNS.IS_ACTIVE]: true,
                [VENDORS_MAPPING.COLUMNS.UPDATED_BY]: userDetails.id,
                [VENDORS_MAPPING.COLUMNS.UPDATED_AT]: new Date(),
              });
          } else {
            await knex(`${VENDORS_MAPPING.NAME}`)
              .insert(vendors);
          }
        })
      );
    }

    // if (body.barcode_details && body.barcode_details.length > 0) {
    //   for (const bar of body.barcode_details) {
    //     await knex(`${BARCODE_LIST.NAME}`)
    //       .where({ [BARCODE_LIST.COLUMNS.PROD_ID]: id })
    //       .update({
    //         [BARCODE_LIST.COLUMNS.BARCODE]: bar.barcode,
    //         [BARCODE_LIST.COLUMNS.PRODUCT_CODE]: body.pro_code,
    //         [BARCODE_LIST.COLUMNS.CREATED_BY]: userDetails.id,
    //       });
    //   }
    // }

    if (body.barcode_details.length > 0) {
      const query_update1 = await knex(`${BARCODE_LIST.NAME}`)
        .where(`${BARCODE_LIST.COLUMNS.PROD_ID}`, id)//43
        // .where(`${BARCODE_LIST.COLUMNS.COMPANY_ID}`, 1)//3
        .update({
          [BARCODE_LIST.COLUMNS.IS_ACTIVE]: false,
          [BARCODE_LIST.COLUMNS.UPDATED_BY]: userDetails.id,
          [BARCODE_LIST.COLUMNS.UPDATED_AT]: new Date(),
        });

      const batcode_update_logic = await Promise.all(
        body.barcode_details.map(async bar => {
          console.log(bar, "bar");

          const barcodes = {
            [BARCODE_LIST.COLUMNS.PRODUCT_CODE]: body.pro_code,
            [BARCODE_LIST.COLUMNS.BARCODE]: bar.barcode,
            [BARCODE_LIST.COLUMNS.PROD_ID]: id,
            // [BARCODE_LIST.COLUMNS.COMPANY_ID]: body.company_id,
            [BARCODE_LIST.COLUMNS.CREATED_BY]: userDetails.id,
            [BARCODE_LIST.COLUMNS.IS_ACTIVE]: body.is_active
          };
          const query_check = knex(BARCODE_LIST.NAME).where(BARCODE_LIST.COLUMNS.PROD_ID, id)
            .where(BARCODE_LIST.COLUMNS.BARCODE, bar.barcode);

          const check_response = await query_check;
          if (check_response.length > 0) {
            const query_update2 = await knex(`${BARCODE_LIST.NAME}`)
              .where(`${BARCODE_LIST.COLUMNS.PROD_ID}`, id)
              // .where(`${BARCODE_LIST.COLUMNS.COMPANY_ID}`, 1)
              .where(`${BARCODE_LIST.COLUMNS.BARCODE}`, bar.barcode)
              .update({
                [BARCODE_LIST.COLUMNS.IS_ACTIVE]: true,
                [BARCODE_LIST.COLUMNS.UPDATED_BY]: userDetails.id,
                [BARCODE_LIST.COLUMNS.UPDATED_AT]: new Date(),
              });
          } else {
            await knex(`${BARCODE_LIST.NAME}`)
              .insert(barcodes);
          }
        })
      );
    }

    return { success: true };
  }

  async function putItemDiscount({ body, logTrace, userDetails }) {
    const knex = this;

    const barcode_details = body.barcode_details;
    const special_discount = body.special_discount;

    for (let detail of barcode_details) {
      const { barcode, prod_id } = detail;


      const exists_response = await knex(BARCODE_LIST.NAME)
        .where(BARCODE_LIST.COLUMNS.PROD_ID, prod_id)
        .andWhere(BARCODE_LIST.COLUMNS.BARCODE, barcode);

      if (!exists_response.length) {
        throw CustomError.create({
          httpCode: StatusCodes.NOT_ACCEPTABLE,
          message: "Item not found to update",
          property: "",
          code: "NOT_ACCEPTABLE"
        });
      }

      const query_update = await knex(BARCODE_LIST.NAME)
        .where(BARCODE_LIST.COLUMNS.PROD_ID, prod_id)
        .andWhere(BARCODE_LIST.COLUMNS.BARCODE, barcode)
        .update({
          [BARCODE_LIST.COLUMNS.DIS_PER]: special_discount,
          [BARCODE_LIST.COLUMNS.UPDATED_BY]: 2,
          [BARCODE_LIST.COLUMNS.UPDATED_AT]: new Date(),
        });

      if (!query_update) {
        throw CustomError.create({
          httpCode: StatusCodes.NOT_IMPLEMENTED,
          message: "Item not found to update",
          property: "",
          code: "NOT_IMPLEMENTED"
        });
      }
    }

    return { success: true };
  }


  async function deleteItem({ id, body, logTrace }) {
    const knex = this;

    // Check if item exists in ITEM table
    const exists_responseItem = await knex(ITEM.NAME).where(ITEM.COLUMNS.ID, id);

    if (exists_responseItem.length === 0) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_ACCEPTABLE,
        message: "Item not found to delete",
        property: "",
        code: "NOT_ACCEPTABLE"
      });
    }

    // Check if item exists in related tables
    const [
      exists_responsePurchaseDetail,
      exists_responSalesDetail,
      exists_responOutletSalesDetail,
      exists_responBarcodeList,
      exists_responOutletMapping
    ] = await Promise.all([
      knex(PURCHASE_DETAILS.NAME).where(PURCHASE_DETAILS.COLUMNS.PROD_ID, id),
      knex(SALESDETAILS.NAME).where(SALESDETAILS.COLUMNS.PRODID, id),
      knex(OUTLETSALESDETAILS.NAME).where(OUTLETSALESDETAILS.COLUMNS.PRODID, id),
      knex(BARCODE_LIST.NAME).where(BARCODE_LIST.COLUMNS.PROD_ID, id),
      knex(OUTLET_PRODUCT_MAPPING.NAME).where(OUTLET_PRODUCT_MAPPING.COLUMNS.PRODUCT_ID, id)
    ]);

    // If the item exists in any of these tables, throw a conflict error
    if (
      exists_responsePurchaseDetail.length > 0 ||
      exists_responSalesDetail.length > 0 ||
      exists_responOutletSalesDetail.length > 0 ||
      exists_responBarcodeList.length > 0 ||
      exists_responOutletMapping.length > 0
    ) {
      throw CustomError.create({
        httpCode: StatusCodes.CONFLICT,
        message: "Cannot delete item as it is referenced in related tables",
        property: "",
        code: "CONFLICT"
      });
    }

    // Proceed to delete the item if it is not referenced in any other table
    const query_delete = knex(ITEM.NAME).where(ITEM.COLUMNS.ID, id).del();

    logQuery({
      logger: fastify.log,
      query: query_delete,  // Log the actual query being executed
      context: "delete Item",
      logTrace
    });

    const response = await query_delete;

    if (!response) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "Item not found",
        property: "",
        code: "NOT_FOUND"
      });
    }

    return { success: true };
  }


  async function getItemInfo({ params, logTrace }) {
    const knex = this;
    const query = knex
      .select([
        `${ITEM.NAME}.*`,
        `${UNITS.NAME}.${UNITS.COLUMNS.UNITS_SHORT_NAME} as uom_name`,
        `${HEADS.NAME}.${HEADS.COLUMNS.CATEOGORY_NAME} as head_name`,
        `${TYPEDESIGN.NAME}.${TYPEDESIGN.COLUMNS.TYPE_NAME} as type_name`,
        `${MAIN_CATEGORY.NAME}.${MAIN_CATEGORY.COLUMNS.CATEGORY_NAME} as cat_name`,
        `${SUB_CATEGORY.NAME}.${SUB_CATEGORY.COLUMNS.SUBCATEGORY_NAME} as sub_cat_name`
      ])
      .from(`${ITEM.NAME} as ${ITEM.NAME}`)
      .leftJoin(
        `${UNITS.NAME} as ${UNITS.NAME}`,
        `${ITEM.NAME}.${ITEM.COLUMNS.UOM}`,
        `${UNITS.NAME}.${UNITS.COLUMNS.ID}`
      )
      .leftJoin(
        `${HEADS.NAME} as ${HEADS.NAME}`,
        `${ITEM.NAME}.${ITEM.COLUMNS.HEADID}`,
        `${HEADS.NAME}.${HEADS.COLUMNS.ID}`
      )
      .leftJoin(
        `${TYPEDESIGN.NAME} as ${TYPEDESIGN.NAME}`,
        `${ITEM.NAME}.${ITEM.COLUMNS.TYPE}`,
        `${TYPEDESIGN.NAME}.${TYPEDESIGN.COLUMNS.ID}`
      )
      .leftJoin(
        `${MAIN_CATEGORY.NAME} as ${MAIN_CATEGORY.NAME}`,
        `${ITEM.NAME}.${ITEM.COLUMNS.CATID}`,
        `${MAIN_CATEGORY.NAME}.${MAIN_CATEGORY.COLUMNS.ID}`
      )
      .leftJoin(
        `${SUB_CATEGORY.NAME} as ${SUB_CATEGORY.NAME}`,
        `${ITEM.NAME}.${ITEM.COLUMNS.SUB_CATEGORY}`,
        `${SUB_CATEGORY.NAME}.${SUB_CATEGORY.COLUMNS.ID}`
      )
      .where(`${ITEM.NAME}.${ITEM.COLUMNS.ID}`, params.id);
    logQuery({
      logger: fastify.log,
      query,
      context: "Get Item Info",
      logTrace
    });
    const response = await query;
    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "Item not found",
        property: "",
        code: "NOT_FOUND"
      });
    }

    const itemWithOutlets = await Promise.all(
      response.map(async item => {
        const outlets = await knex
          .select([`${OUTLETS.NAME}.*`,
          `${OUTLET_PRODUCT_MAPPING.NAME}.${OUTLET_PRODUCT_MAPPING.COLUMNS.OPENING_STOCK} as outlet_opng_stock`,
          `${OUTLET_PRODUCT_MAPPING.NAME}.${OUTLET_PRODUCT_MAPPING.COLUMNS.BALENCE_STOCK} as outlet_balnc_stock`,
          `${OUTLET_PRODUCT_MAPPING.NAME}.${OUTLET_PRODUCT_MAPPING.COLUMNS.MIN_STOCK} as outlet_min_stock`,
          `${OUTLET_PRODUCT_MAPPING.NAME}.${OUTLET_PRODUCT_MAPPING.COLUMNS.ALLOW_NEG_STK} as outlet_allow_neg_stk`,
          `${OUTLET_PRODUCT_MAPPING.NAME}.${OUTLET_PRODUCT_MAPPING.COLUMNS.WSCALE} as outlet_wscale`

          ])
          .from(`${OUTLET_PRODUCT_MAPPING.NAME} as ${OUTLET_PRODUCT_MAPPING.NAME}`)
          .leftJoin(
            `${OUTLETS.NAME} as ${OUTLETS.NAME}`,
            `${OUTLET_PRODUCT_MAPPING.NAME}.${OUTLET_PRODUCT_MAPPING.COLUMNS.OUTLET_ID}`,
            `${OUTLETS.NAME}.${OUTLETS.COLUMNS.ID}`
          )
          .where(
            `${OUTLET_PRODUCT_MAPPING.NAME}.${OUTLET_PRODUCT_MAPPING.COLUMNS.IS_ACTIVE}`,
            true
          )
          .where(
            `${OUTLET_PRODUCT_MAPPING.NAME}.${OUTLET_PRODUCT_MAPPING.COLUMNS.PRODUCT_ID}`,
            item.id
          );

        const vendors = await knex
          .select([`${SUPPLIER.NAME}.*`])
          .from(`${VENDORS_MAPPING.NAME} as ${VENDORS_MAPPING.NAME}`)
          .leftJoin(
            `${SUPPLIER.NAME} as ${SUPPLIER.NAME}`,
            `${VENDORS_MAPPING.NAME}.${VENDORS_MAPPING.COLUMNS.VENDORS_ID}`,//22222
            `${SUPPLIER.NAME}.${SUPPLIER.COLUMNS.ID}`//123
          )
          .where(
            `${VENDORS_MAPPING.NAME}.${VENDORS_MAPPING.COLUMNS.IS_ACTIVE}`,
            true
          )
          .where(
            `${VENDORS_MAPPING.NAME}.${VENDORS_MAPPING.COLUMNS.PRODUCT_ID}`,
            item.id
          );

        const barcode_list = await knex
          .select([`${BARCODE_LIST.NAME}.*`])
          .from(`${BARCODE_LIST.NAME} as ${BARCODE_LIST.NAME}`)
          .leftJoin(
            `${ITEM.NAME} as ${ITEM.NAME}`,
            `${BARCODE_LIST.NAME}.${BARCODE_LIST.COLUMNS.PROD_ID}`,
            `${ITEM.NAME}.${ITEM.COLUMNS.ID}`
          )
          .where(
            `${BARCODE_LIST.NAME}.${BARCODE_LIST.COLUMNS.PROD_ID}`,
            item.id
          );

        return { ...item, outlets, vendors, barcode_list };
      })
    );


    return itemWithOutlets[0];
  }

  async function getItemInfoWithProcode({ body, params, logTrace }) {
    const knex = this;
    // const query = knex(ITEM.NAME).where(ITEM.COLUMNS.ID, params.id);
    const pro_code = body.pro_code
    const query = knex
      .select([
        `${ITEM.NAME}.*`,
        `${UNITS.NAME}.${UNITS.COLUMNS.UNITS_SHORT_NAME} as uom_name`,
        `${HEADS.NAME}.${HEADS.COLUMNS.CATEOGORY_NAME} as head_name`,
        `${TYPEDESIGN.NAME}.${TYPEDESIGN.COLUMNS.TYPE_NAME} as type_name`,
        `${MAIN_CATEGORY.NAME}.${MAIN_CATEGORY.COLUMNS.CATEGORY_NAME} as cat_name`,
        `${SUB_CATEGORY.NAME}.${SUB_CATEGORY.COLUMNS.SUBCATEGORY_NAME} as sub_cat_name`
      ])
      .from(`${ITEM.NAME} as ${ITEM.NAME}`)
      .leftJoin(
        `${UNITS.NAME} as ${UNITS.NAME}`,
        `${ITEM.NAME}.${ITEM.COLUMNS.UOM}`,
        `${UNITS.NAME}.${UNITS.COLUMNS.ID}`
      )
      .leftJoin(
        `${HEADS.NAME} as ${HEADS.NAME}`,
        `${ITEM.NAME}.${ITEM.COLUMNS.HEADID}`,
        `${HEADS.NAME}.${HEADS.COLUMNS.ID}`
      )
      .leftJoin(
        `${TYPEDESIGN.NAME} as ${TYPEDESIGN.NAME}`,
        `${ITEM.NAME}.${ITEM.COLUMNS.TYPE}`,
        `${TYPEDESIGN.NAME}.${TYPEDESIGN.COLUMNS.ID}`
      )
      .leftJoin(
        `${MAIN_CATEGORY.NAME} as ${MAIN_CATEGORY.NAME}`,
        `${ITEM.NAME}.${ITEM.COLUMNS.CATID}`,
        `${MAIN_CATEGORY.NAME}.${MAIN_CATEGORY.COLUMNS.ID}`
      )
      .leftJoin(
        `${SUB_CATEGORY.NAME} as ${SUB_CATEGORY.NAME}`,
        `${ITEM.NAME}.${ITEM.COLUMNS.SUB_CATEGORY}`,
        `${SUB_CATEGORY.NAME}.${SUB_CATEGORY.COLUMNS.ID}`
      )
      .where(`${ITEM.NAME}.${ITEM.COLUMNS.PRODUCT_CODE}`, pro_code);
    logQuery({
      logger: fastify.log,
      query,
      context: "Get Item Info",
      logTrace
    });
    const response = await query;
    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "Item not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
    // return response;
    const itemWithOutlets = await Promise.all(
      response.map(async item => {

        const outlets = await knex
          .select([`${OUTLETS.NAME}.*`])
          .from(`${OUTLET_PRODUCT_MAPPING.NAME} as ${OUTLET_PRODUCT_MAPPING.NAME}`)
          .leftJoin(
            `${OUTLETS.NAME} as ${OUTLETS.NAME}`,
            `${OUTLET_PRODUCT_MAPPING.NAME}.${OUTLET_PRODUCT_MAPPING.COLUMNS.OUTLET_ID}`,
            `${OUTLETS.NAME}.${OUTLETS.COLUMNS.ID}`
          )
          .where(
            `${OUTLET_PRODUCT_MAPPING.NAME}.${OUTLET_PRODUCT_MAPPING.COLUMNS.IS_ACTIVE}`,
            true
          )
          .where(
            `${OUTLET_PRODUCT_MAPPING.NAME}.${OUTLET_PRODUCT_MAPPING.COLUMNS.PRODUCT_ID}`,
            item.id
          );

        const vendors = await knex
          .select([`${SUPPLIER.NAME}.*`])
          .from(`${VENDORS_MAPPING.NAME} as ${VENDORS_MAPPING.NAME}`)
          .leftJoin(
            `${SUPPLIER.NAME} as ${SUPPLIER.NAME}`,
            `${VENDORS_MAPPING.NAME}.${VENDORS_MAPPING.COLUMNS.VENDORS_ID}`,//22222
            `${SUPPLIER.NAME}.${SUPPLIER.COLUMNS.ID}`//123
          )
          .where(
            `${VENDORS_MAPPING.NAME}.${VENDORS_MAPPING.COLUMNS.IS_ACTIVE}`,
            true
          )
          .where(
            `${VENDORS_MAPPING.NAME}.${VENDORS_MAPPING.COLUMNS.PRODUCT_ID}`,
            item.id
          );

        return { ...item, outlets, vendors };
      })
    );


    return itemWithOutlets[0];
  }
  async function getItemCodeInfo({ params, logTrace }) {

    const knex = this;
    const query = knex
      .select([
        `${ITEM.NAME}.*`,
        `${UNITS.NAME}.${UNITS.COLUMNS.UNITS_SHORT_NAME} as uom_name`,
        `${HEADS.NAME}.${HEADS.COLUMNS.CATEOGORY_NAME} as head_name`,
        `${TYPEDESIGN.NAME}.${TYPEDESIGN.COLUMNS.TYPE_NAME} as type_name`,
        `${MAIN_CATEGORY.NAME}.${MAIN_CATEGORY.COLUMNS.CATEGORY_NAME} as cat_name`,
        `${SUB_CATEGORY.NAME}.${SUB_CATEGORY.COLUMNS.SUBCATEGORY_NAME} as sub_cat_name`
      ])
      .from(`${ITEM.NAME} as ${ITEM.NAME}`)
      .leftJoin(
        `${UNITS.NAME} as ${UNITS.NAME}`,
        `${ITEM.NAME}.${ITEM.COLUMNS.UOM}`,
        `${UNITS.NAME}.${UNITS.COLUMNS.ID}`
      )
      .leftJoin(
        `${HEADS.NAME} as ${HEADS.NAME}`,
        `${ITEM.NAME}.${ITEM.COLUMNS.HEADID}`,
        `${HEADS.NAME}.${HEADS.COLUMNS.ID}`
      )
      .leftJoin(
        `${TYPEDESIGN.NAME} as ${TYPEDESIGN.NAME}`,
        `${ITEM.NAME}.${ITEM.COLUMNS.TYPE}`,
        `${TYPEDESIGN.NAME}.${TYPEDESIGN.COLUMNS.ID}`
      )
      .leftJoin(
        `${MAIN_CATEGORY.NAME} as ${MAIN_CATEGORY.NAME}`,
        `${ITEM.NAME}.${ITEM.COLUMNS.CATID}`,
        `${MAIN_CATEGORY.NAME}.${MAIN_CATEGORY.COLUMNS.ID}`
      )
      .leftJoin(
        `${SUB_CATEGORY.NAME} as ${SUB_CATEGORY.NAME}`,
        `${ITEM.NAME}.${ITEM.COLUMNS.SUB_CATEGORY}`,
        `${SUB_CATEGORY.NAME}.${SUB_CATEGORY.COLUMNS.ID}`
      )
      .where(`${ITEM.NAME}.${ITEM.COLUMNS.PRODUCT_CODE}`, params.code)
      .where(`${ITEM.NAME}.${ITEM.COLUMNS.PRODUCT_TYPE}`, "purchase")

    logQuery({
      logger: fastify.log,
      query,
      context: "Get Item Info",
      logTrace
    });
    const response = await query;

    if (response.length === 0) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "Item not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
    return response[0];
  }

  async function itemSearch({ params, logTrace }) {
    const knex = this;
    const query = knex(ITEM.NAME);
    if (params.search) {
      query.where(function () {
        this.where(
          `${ITEM.NAME}.${ITEM.COLUMNS.PRODUCT_NAME}`,
          "like",
          `%${params.search}%`
        );
        this.orWhere(
          `${ITEM.NAME}.${ITEM.COLUMNS.PRODUCT_CODE}`,
          "like",
          `%${params.search}%`
        );
        this.orWhere(
          `${ITEM.NAME}.${ITEM.COLUMNS.BARCODE}`,
          "like",
          `%${params.search}%`
        );
      });
    }

    const response = await query;

    logQuery({
      logger: fastify.log,
      query,
      context: "Get Item",
      logTrace
    });

    if (response.length === 0) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: " not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
    return response;
  }

  async function itemBarcodeSearch({ params, logTrace }) {
    const knex = this;

    const invalidBarcodeQuery = await knex(BARCODE_LIST.NAME)
      .select(
        `${BARCODE_LIST.NAME}.*`,
      )
      .where(`${BARCODE_LIST.NAME}.${BARCODE_LIST.COLUMNS.BARCODE}`, params.barcode)

    if (invalidBarcodeQuery.length == 0) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: `This is barcode is invalid`,
        property: "",
        code: "NOT_FOUND"
      });
    }

    const warhouseBarcodeQuery = await knex(BARCODE_LIST.NAME)
      .select(
        `${BARCODE_LIST.NAME}.*`,
      )
      .where(`${BARCODE_LIST.NAME}.${BARCODE_LIST.COLUMNS.BARCODE}`, params.barcode)
      .where(`${BARCODE_LIST.NAME}.${BARCODE_LIST.COLUMNS.OUTLET_ID}`, null)

    if (warhouseBarcodeQuery.length != 0) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: `This is mapped with warehouse`,
        property: "",
        code: "NOT_FOUND"
      });
    }

    const query = knex(BARCODE_LIST.NAME)
      .select(
        `${BARCODE_LIST.NAME}.*`,
        `${ITEM.NAME}.*`,
        `${BARCODE_LIST.NAME}.${BARCODE_LIST.COLUMNS.BARCODE}`,
        // `${BARCODE_LIST.NAME}.${BARCODE_LIST.COLUMNS.IS_SOLD}`,
        `${BARCODE_LIST.NAME}.${BARCODE_LIST.COLUMNS.OUTLET_ID}`,
        `${ITEM.NAME}.${ITEM.COLUMNS.PRODUCT_CODE} as description`,
        `${BARCODE_LIST.NAME}.${BARCODE_LIST.COLUMNS.DIS_PER} as special_discount`,
      )
      .leftJoin(
        ITEM.NAME,
        `${ITEM.NAME}.${ITEM.COLUMNS.ID}`,
        '=',
        `${BARCODE_LIST.NAME}.${BARCODE_LIST.COLUMNS.PROD_ID}`
      )
      .where(`${BARCODE_LIST.NAME}.${BARCODE_LIST.COLUMNS.BARCODE}`, params.barcode)
      .orWhere(`${BARCODE_LIST.NAME}.${BARCODE_LIST.COLUMNS.PRODUCT_CODE}`, params.barcode);

    const response1 = await query;

    if (params.outlet_id && params.outlet_id !== 0) {
      query.where(
        `${BARCODE_LIST.NAME}.${BARCODE_LIST.COLUMNS.OUTLET_ID}`,
        params.outlet_id
      );
    }


    const response = await query;


    if (response1[0].outlet_id != params.outlet_id) {

      const short_name = await knex(OUTLETS.NAME)
        .where(OUTLETS.COLUMNS.ID, response1[0].outlet_id)
        .select(OUTLETS.COLUMNS.SHORTNAME);

      const outlet_short_name = short_name[0].short_name

      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: `This is mapped with ${outlet_short_name} outlet`,
        property: "",
        code: "NOT_FOUND"
      });
    }


    return response[0];
  }
  async function getItemsSearchClosingStock({ params, logTrace }) {
    const knex = this;

    const invalidBarcodeQuery = await knex(BARCODE_LIST.NAME)
      .select(
        `${BARCODE_LIST.NAME}.*`,
      )
      .where(`${BARCODE_LIST.NAME}.${BARCODE_LIST.COLUMNS.BARCODE}`, params.barcode)

    if (invalidBarcodeQuery.length == 0) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: `This is barcode is invalid`,
        property: "",
        code: "NOT_FOUND"
      });
    }



    const barcodeTempQuery = await knex(CLOSING_STOCK_TEMP.NAME)
      .select(
        `${CLOSING_STOCK_TEMP.NAME}.*`,
      )
      .where(`${CLOSING_STOCK_TEMP.NAME}.${CLOSING_STOCK_TEMP.COLUMNS.BARCODE}`, params.barcode)
      .where(`${CLOSING_STOCK_TEMP.NAME}.${CLOSING_STOCK_TEMP.COLUMNS.OUTLET_ID}`, params.outlet_id)

    if (barcodeTempQuery.length != 0) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: `This barcode already exists`,
        property: "",
        code: "NOT_FOUND"
      });
    }



    const barcodeSoldQuery = await knex(BARCODE_LIST.NAME)
      .select(
        `${BARCODE_LIST.NAME}.*`,
      )
      .where(`${BARCODE_LIST.NAME}.${BARCODE_LIST.COLUMNS.BARCODE}`, params.barcode)
      .where(`${BARCODE_LIST.NAME}.${BARCODE_LIST.COLUMNS.OUTLET_ID}`, params.outlet_id)
      .where(`${BARCODE_LIST.NAME}.${BARCODE_LIST.COLUMNS.IS_SOLD}`, true)


    if (barcodeSoldQuery.length != 0) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: `This item is Sold`,
        property: "",
        code: "NOT_FOUND"
      });
    }

    const barcodeUnverifedQuery = await knex(BARCODE_LIST.NAME)
      .select(
        `${BARCODE_LIST.NAME}.*`,
      )
      .where(`${BARCODE_LIST.NAME}.${BARCODE_LIST.COLUMNS.BARCODE}`, params.barcode)
      .where(`${BARCODE_LIST.NAME}.${BARCODE_LIST.COLUMNS.OUTLET_ID}`, params.outlet_id)
      .where(`${BARCODE_LIST.NAME}.${BARCODE_LIST.COLUMNS.IS_VERIFIED}`, 0)

    if (barcodeUnverifedQuery.length != 0) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: `This item is not Verified`,
        property: "",
        code: "NOT_FOUND"
      });
    }

    const barcodeMissedQuery = await knex(BARCODE_LIST.NAME)
      .select(
        `${BARCODE_LIST.NAME}.*`,
      )
      .where(`${BARCODE_LIST.NAME}.${BARCODE_LIST.COLUMNS.BARCODE}`, params.barcode)
      .where(`${BARCODE_LIST.NAME}.${BARCODE_LIST.COLUMNS.IS_MISSED}`, true)

    if (barcodeMissedQuery.length != 0) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: `This item is in missed report`,
        property: "",
        code: "NOT_FOUND"
      });
    }

    const barcodeWarehouseQuery = await knex(BARCODE_LIST.NAME)
      .select(
        `${BARCODE_LIST.NAME}.*`,
      )
      .where(`${BARCODE_LIST.NAME}.${BARCODE_LIST.COLUMNS.BARCODE}`, params.barcode)
      .where(`${BARCODE_LIST.NAME}.${BARCODE_LIST.COLUMNS.OUTLET_ID}`, null)

    if (barcodeWarehouseQuery.length != 0) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: `This item is warehouse`,
        property: "",
        code: "NOT_FOUND"
      });
    }

    const barcodeCurrentMonthQuery = knex(BARCODE_LIST.NAME)
      .select(
        `${BARCODE_LIST.NAME}.*`
      )
      .where(`${BARCODE_LIST.NAME}.${BARCODE_LIST.COLUMNS.BARCODE}`, params.barcode)
      .andWhereRaw(
        `${BARCODE_LIST.NAME}.${BARCODE_LIST.COLUMNS.UPDATED_AT} < DATE_TRUNC('month', CURRENT_DATE) 
      OR ${BARCODE_LIST.NAME}.${BARCODE_LIST.COLUMNS.UPDATED_AT} >= DATE_TRUNC('month', CURRENT_DATE) + INTERVAL '1 month'`
      )

    var barcodeCurrentMonth = await barcodeCurrentMonthQuery

    if (barcodeCurrentMonth.length == 0) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: `Current Month New Item`,
        property: "",
        code: "NOT_FOUND"
      });
    }


    const query = knex(BARCODE_LIST.NAME)
      .select(
        `${BARCODE_LIST.NAME}.*`,
        `${ITEM.NAME}.*`,
        `${BARCODE_LIST.NAME}.${BARCODE_LIST.COLUMNS.BARCODE}`,
        `${BARCODE_LIST.NAME}.${BARCODE_LIST.COLUMNS.IS_SOLD}`,
        `${BARCODE_LIST.NAME}.${BARCODE_LIST.COLUMNS.OUTLET_ID}`,
        `${ITEM.NAME}.${ITEM.COLUMNS.PRODUCT_CODE} as description`
      )
      .leftJoin(
        ITEM.NAME,
        `${ITEM.NAME}.${ITEM.COLUMNS.ID}`,
        '=',
        `${BARCODE_LIST.NAME}.${BARCODE_LIST.COLUMNS.PROD_ID}`
      )
      .where(`${BARCODE_LIST.NAME}.${BARCODE_LIST.COLUMNS.BARCODE}`, params.barcode)
      .where(`${BARCODE_LIST.NAME}.${BARCODE_LIST.COLUMNS.OUTLET_ID}`, params.outlet_id)
      .where(`${BARCODE_LIST.NAME}.${BARCODE_LIST.COLUMNS.IS_SOLD}`, false)
      .where(`${BARCODE_LIST.NAME}.${BARCODE_LIST.COLUMNS.IS_CLOSED}`, 0)
      .where(`${BARCODE_LIST.NAME}.${BARCODE_LIST.COLUMNS.IS_VERIFIED}`, 1)
      .where(`${ITEM.NAME}.${ITEM.COLUMNS.CATID}`, params.cat_id)

    if (!params.sub_cat_id) {
      query.where(
        `${ITEM.NAME}.${ITEM.COLUMNS.SUB_CATEGORY}`,
        params.sub_cat_id
      );
    }


    const response = await query;


    if (response.length > 0) {

      if (response[0].outlet_id != params.outlet_id) {

        const short_name = await knex(OUTLETS.NAME)
          .where(OUTLETS.COLUMNS.ID, response[0].outlet_id)
          .select(OUTLETS.COLUMNS.SHORTNAME);

        const outlet_short_name = short_name[0].short_name

        throw CustomError.create({
          httpCode: StatusCodes.NOT_FOUND,
          message: `This is mapped with ${outlet_short_name} outlet`,
          property: "",
          code: "NOT_FOUND"
        });
      }
    }



    if (response.length === 0) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "This Barcode not belongs to this Category",
        property: "",
        code: "NOT_FOUND"
      });
    }
    return response[0];
  }
  async function getBarcodeIssueSearch({ params, logTrace }) {
    const knex = this;

    const query = knex(BARCODE_LIST.NAME)
      .select(
        `${BARCODE_LIST.NAME}.*`,
        `${ITEM.NAME}.*`,
        `${BARCODE_LIST.NAME}.${BARCODE_LIST.COLUMNS.BARCODE}`,
        `${ITEM.NAME}.${ITEM.COLUMNS.BALANCE} as qty`, // Cast to numeric
        `${ITEM.NAME}.${ITEM.COLUMNS.PRODUCT_CODE} as description`
      )
      .leftJoin(
        ITEM.NAME,
        `${ITEM.NAME}.${ITEM.COLUMNS.ID}`,
        '=',
        `${BARCODE_LIST.NAME}.${BARCODE_LIST.COLUMNS.PROD_ID}`
      )
      .where(`${BARCODE_LIST.NAME}.${BARCODE_LIST.COLUMNS.BARCODE}`, params.barcode)
      .orWhere(`${BARCODE_LIST.NAME}.${BARCODE_LIST.COLUMNS.PRODUCT_CODE}`, params.barcode);

    const response = await query;

    if (response.length === 0) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "Barcode not found. Please verify and enter a valid barcode",
        property: "",
        code: "NOT_FOUND"
      });
    }
    response[0].qty = Number(response[0].qty);
    return response[0];
  }


  return {
    getItem,
    postItem,
    putItem,
    deleteItem,
    getItemInfo,
    getItemPaginate,
    getItemCodeInfo,
    itemSearch,
    itemBarcodeSearch,
    getItemsSearchClosingStock,
    getBarcodeIssueSearch,
    getItemOutlet,
    getItemInfoWithProcode,
    putItemDiscount,
    getItemPurchaseProduct,
    getItemDetailsOutletsSalesProduct

  };
}

module.exports = itemRepo;
