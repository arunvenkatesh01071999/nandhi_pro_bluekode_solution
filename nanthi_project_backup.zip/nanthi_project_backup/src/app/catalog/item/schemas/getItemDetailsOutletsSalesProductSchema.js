const { errorSchemas } = require("../../../commons/schemas/errorSchemas");

const getOutletSalesProductSchema = {
  tags: ["OutletSales"],
  summary: "Get item details for outlet sales by product barcode",
  headers: { $ref: "request-headers#" },
  params: {
    type: "object",
    required: ["outlet_id", "barcode"],
    properties: {
      outlet_id: { type: "integer" },
      barcode: { type: "string" }
    }
  },
  response: {
    200: {
      type: "array",
      items: {
        type: "object",
        properties: {
          id: { type: "integer" },
          pro_code: { type: "string" },
          pro_name: { type: "string" },
          type: { type: "integer" },
          sub_cat: { type: "integer" },
          company_id: { type: "integer" },
          uom: { type: "integer" },
          // barcode: { type: "string" },
          pur_rate: { type: "string" },
          sale_rate: { type: "string" },
          wholesale_rate: { type: "string" },
          mrp: { type: "string" },
          gst: { type: "string" },
          cess: { type: "string" },
          hsn: { type: "string" },
          op_stk: { type: "string" },
          balance: { type: "string" },
          min_stock: { type: "string" },
          allow_neg_stk: { type: "boolean" },
          wscale: { type: "boolean" },
          // vendor: { type: "integer" },
          // is_active: { type: "boolean" },
          // created_at: { type: "string", format: "date-time" },
          // updated_at: { type: "string", format: "date-time" },
          // created_by: { type: "integer" },
          // updated_by: { type: "integer" },
          cat_id: { type: "integer" },
          head_id: { type: "integer" },
          discount: { type: "string" },
          short_name: { type: "string" },
          pro_description: { type: "string" },
          manufacturing_date: { type: "string", format: "date-time" },
          expiry_date: { type: "string", format: "date-time" },
          product_type: { type: "string" },
          main_product_id: { type: ["integer", "null"] },
          main_uom_id: { type: "integer" },
          convertion_factor: { type: "string" },
          product_barcode: { type: "string" },
          outlet_opening_stock: { type: "number" },
          outlet_balance_stock: { type: "number" },
          outlet_min_stock: { type: "number" },
          outlet_allow_neg_stock: { type: "boolean" },
          outlet_wscale: { type: "boolean" },
          outlet_min_warn_stock: { type: "boolean" },
          min_stock_waring_message: { type: "string" },
          min_stock_waring_flag: { type: "boolean" }
        }
      }
    },
    ...errorSchemas
  }
};

module.exports = getOutletSalesProductSchema;
