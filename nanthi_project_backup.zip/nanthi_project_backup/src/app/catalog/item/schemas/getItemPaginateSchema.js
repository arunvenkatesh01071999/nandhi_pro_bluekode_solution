const { errorSchemas } = require("../../../commons/schemas/errorSchemas");

const getItemPaginateSchema = {
  tags: ["Item"],
  summary: "This API is to get Item",
  headers: { $ref: "request-headers#" },
  params: {
    type: "object",
    properties: {
      page_size: { type: "integer" },
      current_page: { type: "integer" }
    }
  },
  response: {
    200: {
      type: "object",
      properties: {
        data: {
          type: "array",
          items: {
            type: "object",
            properties: {
              id: { type: "integer" },
              pro_code: { type: "string" },
              pro_name: { type: "string" },
              type: { type: "integer" },
              type_name: { type: "string" },
              sub_cat: { type: "integer" },
              sub_cat_name: { type: "string" },
              uom: { type: "integer" },
              uom_name: { type: "string" },
              head_id: { type: "integer" },
              head_name: { type: "string" },
              cat_id: { type: "integer" },
              cat_name: { type: "string" },
              barcode: { type: "string" },
              pur_rate: { type: "number" },
              sale_rate: { type: "number" },
              wholesale_rate: { type: "number" },
              mrp: { type: "number" },
              gst: { type: "number" },
              cess: { type: "number" },
              hsn: { type: "string" },
              op_stk: { type: "number" },
              balance: { type: "number" },
              min_stock: { type: "number" },
              allow_neg_stk: { type: "boolean" },
              wscale: { type: "boolean" },
              vendor: { type: "integer" },
              company_id: { type: "integer" },
              is_active: { type: "boolean" },
              item_barcode: { type: "string" },
              outlets: {
                type: "array",
                items: {
                  type: "object",
                  properties: {
                    id: { type: "integer" },
                    code: { type: "string" },
                    short_name: { type: "string" },
                    fullname: { type: "string" },
                    add1: { type: "string" },
                    add2: { type: "string" },
                    add3: { type: "string" },
                    add4: { type: "string" },
                    city: { type: "integer" },
                    pincode: { type: "string" },
                    state: { type: "integer" },
                    country: { type: "integer" },
                    phone: { type: "string" },
                    mobile: { type: "string" },
                    email: { type: "string" },
                    website: { type: "string" },
                    gstin: { type: "string" },
                    fssai: { type: "string" },
                    outlet_type: { type: "integer" },
                    bankacno: { type: "string" },
                    bankname: { type: "string" },
                    acname: { type: "string" },
                    ifsccode: { type: "string" },
                    company_id: { type: "integer" },
                    is_active: { type: "boolean" },
                    franchise_type: { type: "integer" },
                    balance: { type: "string" },
                    credit_limit: { type: "string" },
                    limitation: { type: "string" },
                    wallet_balance: { type: "string" },
                    ref_doc_no: { type: "string" },
                    outlet_opng_stock: { type: "string" },
                    outlet_balnc_stock: { type: "string" },
                    outlet_min_stock: { type: "string" },
                    outlet_allow_neg_stk: { type: "boolean" },
                    outlet_wscale: { type: "boolean" }
                  }
                }
              },
              vendors: {
                type: "array",
                items: {
                  type: "object",
                  properties: {
                    id: { type: "integer" },
                    name: { type: "string" },
                    short_name: { type: "string" },
                    company_id: { type: "integer" },
                    mobile: { type: "string" },
                    phone: { type: "string" },
                    add1: { type: "string" },
                    add2: { type: "string" },
                    add3: { type: "string" },
                    add4: { type: "string" },
                    city: { type: "integer" },
                    pincode: { type: "string" },
                    state: { type: "integer" },
                    email: { type: "string" },
                    website: { type: "string" },
                    op_bal: { type: "string" },
                    balance: { type: "string" },
                    custtype: { type: "string" },
                    bank_ac_no: { type: "string" },
                    bankname: { type: "string" },
                    ac_name: { type: "string" },
                    ifsccode: { type: "string" },
                    gstin: { type: "string" },
                    is_active: { type: "boolean" },
                    country: { type: "integer" },
                    fssaino: { type: "string" }
                  }
                }
              }
            }
          }
        },
        meta: { $ref: "response-meta#" }
      }
    },
    ...errorSchemas
  }
};

module.exports = getItemPaginateSchema;
