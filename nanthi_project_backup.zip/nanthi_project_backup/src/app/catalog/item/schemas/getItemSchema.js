const { errorSchemas } = require("../../../commons/schemas/errorSchemas");

const getItemInfoSchema = {
  tags: ["Item INFO"],
  summary: "This API is to get Item Info",
  headers: { $ref: "request-headers#" },
  params: {
    type: "object",
    properties: {
      code: { type: "string" }
    },
    required: ["code"]
  },
  response: {
    200: {
      type: "object",
      properties: {
        id: { type: "integer" },
        pro_code: { type: "string" },
        pro_name: { type: "string" },
        company_id: { type: "integer" },
        barcode: { type: "string" },
        pur_rate: { type: "number" },
        sale_rate: { type: "number" },
        wholesale_rate: { type: "number" },
        mrp: { type: "number" },
        gst: { type: "number" },
        cess: { type: "number" },
        hsn: { type: "string" },
        op_stk: { type: "number" },
        balance: { type: "number" },
        min_stock: { type: "number" },
        allow_neg_stk: { type: "number" },
        wscale: { type: "boolean" },
        discount: { type: "number" },
        short_name: { type: "string" },
        pro_description: { type: "string" },
        manufacturing_date: { type: "string" },
        expiry_date: { type: "string" },
        product_type: { type: "string" },
        main_product_id: { type: "integer" },
        main_uom_id: { type: "integer" },
        convertion_factor: { type: "number" },
        is_active: { type: "boolean" },
        created_at: { type: "string" },
        updated_at: { type: "string" },
        created_by: { type: "integer" },
        updated_by: { type: "integer" },
        cat_id: { type: "integer" },
        cat_name: { type: "string" },
        sub_cat: { type: "integer" },
        sub_cat_name: { type: "string" },
        head_id: { type: "integer" },
        head_name: { type: "string" },
        type: { type: "integer" },
        type_name: { type: "string" },
        uom: { type: "integer" },
        uom_name: { type: "string" }
      }
    },
    ...errorSchemas
  }
};

module.exports = getItemInfoSchema;
