const getItemSchema = require("./getItemSchema");
const postItemSchema = require("./postItemSchema");
const putItemSchema = require("./putItemSchema");
const deleteItemSchema = require("./deleteItemSchema");
const getItemInfoSchema = require("./getItemInfoSchema");
const getItemPaginateSchema = require("./getItemPaginateSchema");
const getBarcodeSchema = require("./getBarcodeSchema")
const putItemDiscountSchema = require("./putItemDiscountSchema.js")
const getBarcodeIssueSchema = require("./getBarcodeIssueSchema.js")
const getItemPurchaseProductSchema = require("./getItemPurchaseProductSchema.js")
const getItemDetailsOutletsSalesProductSchema = require("./getItemDetailsOutletsSalesProductSchema.js")
module.exports = {
  getItemSchema,
  postItemSchema,
  putItemSchema,
  deleteItemSchema,
  getItemInfoSchema,
  getItemPaginateSchema,
  getBarcodeSchema,
  putItemDiscountSchema,
  getBarcodeIssueSchema,
  getItemPurchaseProductSchema,
  getItemDetailsOutletsSalesProductSchema
};
