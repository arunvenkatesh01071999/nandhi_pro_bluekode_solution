const { errorSchemas } = require("../../../commons/schemas/errorSchemas");

const putItemSchema = {
  tags: ["Item"],
  summary: "This API is to update Item",
  headers: { $ref: "request-headers#" },
  params: {
    type: "object",
    properties: {
      id: { type: "integer" }
    }
  },
  body: {
    type: "object",
    required: [
      "pro_name",
      "pro_code",
      "type",
      "sub_cat",
      "uom",
      "pur_rate",
      "sale_rate",
      "gst",
      "hsn",
      "wscale",
      "allow_neg_stock",
      "balance",
      "company_id",
      "is_active",
      "head_id",
      "cat_id",
      "op_stk",
      "min_stock",
      "product_type",
      "main_uom_id",
      "convertion_factor",
      // "main_product_id",
      "outlets",
      "vendors",
      "barcode_details"
    ],
    properties: {
      pro_code: { type: "string" },
      pro_name: { type: "string" },
      type: { type: "integer" },
      sub_cat: { type: "integer" },
      uom: { type: "string" },
      barcode: { type: "string" },
      pur_rate: { type: "number" },
      sale_rate: { type: "number" },
      wholesale_rate: { type: "number" },
      mrp: { type: "integer" },
      gst: { type: "number" },
      cess: { type: "number" },
      hsn: { type: "string" },
      op_stk: { type: "number" },
      balance: { type: "number" },
      min_stock: { type: "number" },
      allow_neg_stock: { type: "boolean" },
      wscale: { type: "boolean" },
      vendor: { type: "integer" },
      company_id: { type: "integer" },
      is_active: { type: "boolean" },
      head_id: { type: "integer" },
      cat_id: { type: "integer" },
      product_type: { type: "string" },
      main_uom_id: { type: "integer" },
      convertion_factor: { type: "number" },
      main_product_id: { type: "integer" },
      outlets: {
        type: "array",
        items: {
          type: "object",
          required: ["outlet_id"],
          properties: {
            outlet_id: { type: "integer" },
            outlet_opng_stock: { type: "number" },
            outlet_balnc_stock: { type: "number" },
            outlet_min_stock: { type: "number" },
            outlet_allow_neg_stk: { type: "boolean" },
            outlet_wscale: { type: "boolean" }
          }
        }
      },
      vendors: {
        type: "array",
        items: {
          type: "object",
          required: ["vendor_id"],
          properties: {
            vendor_id: { type: "integer" },
          }
        }
      },
      barcode_details: {
        type: "array",
        items: {
          type: "object",
          required: ["barcode"],
          properties: {
            barcode: { type: "string" },
          }
        }
      },
    }
  },
  response: {
    200: {
      type: "object",
      properties: {
        success: { type: "boolean" }
      }
    },
    ...errorSchemas
  }
};

module.exports = putItemSchema;
