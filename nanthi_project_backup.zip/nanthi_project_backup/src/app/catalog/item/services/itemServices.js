const itemRepo = require("../repository/item.js");



function getItemDetailsOutletsSalesProductService(fastify) {
  const { getItemDetailsOutletsSalesProduct } = itemRepo(fastify);

  return async ({ body, params, logTrace }) => {
    const knex = fastify.knexMedical;
    const response = await getItemDetailsOutletsSalesProduct.call(knex, {
      body, params, logTrace
    });
    return response;

  };
}
function getItemOutletService(fastify) {
  const { getItemOutlet } = itemRepo(fastify);

  return async ({ body, params, logTrace }) => {
    const knex = fastify.knexMedical;
    const response = await getItemOutlet.call(knex, {
      body, params, logTrace
    });
    return response;

  };
}

function getItemService(fastify) {
  const { getItem } = itemRepo(fastify);

  return async ({ logTrace }) => {
    const knex = fastify.knexMedical;
    const response = await getItem.call(knex, {
      logTrace
    });
    return response;

  };
}
function getItemPurchaseProductService(fastify) {
  const { getItemPurchaseProduct } = itemRepo(fastify);

  return async ({ logTrace }) => {
    const knex = fastify.knexMedical;
    const response = await getItemPurchaseProduct.call(knex, {
      logTrace
    });
    return response;

  };
}
function getItemPaginateService(fastify) {
  const { getItemPaginate } = itemRepo(fastify);

  return async ({ params, logTrace }) => {
    const knex = fastify.knexMedical;
    const response = await getItemPaginate.call(knex, {
      params,
      logTrace
    });
    return response;
  };

}

function postItemService(fastify) {
  const { postItem } = itemRepo(fastify);
  return async ({ params, body, logTrace, userDetails }) => {
    const knex = fastify.knexMedical;
    const promise1 = postItem.call(knex, {
      params,
      body,
      logTrace, userDetails
    });
    const [response] = await Promise.all([promise1]);
    return response;
  };
}

function putItemService(fastify) {
  const { putItem } = itemRepo(fastify);
  return async ({ params, body, logTrace, userDetails }) => {
    const knex = fastify.knexMedical;
    const { id } = params;
    // console.log(id, "id");
    const promise1 = putItem.call(knex, {
      id,
      body,
      logTrace, userDetails
    });
    const [response] = await Promise.all([promise1]);
    return response;
  };
}

function putItemDiscountService(fastify) {
  const { putItemDiscount } = itemRepo(fastify);
  return async ({ params, body, logTrace, userDetails }) => {
    const knex = fastify.knexMedical;

    const promise1 = putItemDiscount.call(knex, {

      body,
      logTrace, userDetails
    });
    const [response] = await Promise.all([promise1]);
    return response;
  };
}

function deleteItemService(fastify) {
  const { deleteItem } = itemRepo(fastify);
  return async ({ params, body, logTrace }) => {
    const knex = fastify.knexMedical;
    const { id } = params;
    const promise1 = deleteItem.call(knex, {
      id,
      body,
      logTrace
    });
    const [response] = await Promise.all([promise1]);
    return response;
  };
}
function getItemInfoService(fastify) {
  const { getItemInfo } = itemRepo(fastify);

  return async ({ params, logTrace }) => {
    const knex = fastify.knexMedical;
    const response = await getItemInfo.call(knex, {
      params,
      logTrace
    });
    return response;
  };
}

function getItemInfoWithProcodeService(fastify) {
  const { getItemInfoWithProcode } = itemRepo(fastify);

  return async ({ body, params, logTrace }) => {
    const knex = fastify.knexMedical;
    const response = await getItemInfoWithProcode.call(knex, {
      body, params, logTrace
    });
    return response;
  };
}

function getItemCodeService(fastify) {
  const { getItemCodeInfo } = itemRepo(fastify);

  return async ({ params, logTrace }) => {
    const knex = fastify.knexMedical;
    const response = await getItemCodeInfo.call(knex, {
      params,
      logTrace
    });
    return response;
  };
}

function getItemSearchService(fastify) {
  const { itemSearch } = itemRepo(fastify);

  return async ({ params, logTrace }) => {
    const knex = fastify.knexMedical;
    const response = await itemSearch.call(knex, {
      params,
      logTrace
    });
    return response;
  };

}

function getBarcodeSearchService(fastify) {
  const { itemBarcodeSearch } = itemRepo(fastify);

  return async ({ params, logTrace }) => {
    const knex = fastify.knexMedical;
    const response = await itemBarcodeSearch.call(knex, {
      params,
      logTrace
    });
    return response;
  };

}
function getBarcodeSearchClosingStockService(fastify) {
  const { getItemsSearchClosingStock } = itemRepo(fastify);

  return async ({ params, logTrace }) => {
    const knex = fastify.knexMedical;
    const response = await getItemsSearchClosingStock.call(knex, {
      params,
      logTrace
    });
    return response;
  };

}

function getBarcodeIssueSearchService(fastify) {
  const { getBarcodeIssueSearch } = itemRepo(fastify);

  return async ({ params, logTrace }) => {
    const knex = fastify.knexMedical;
    const response = await getBarcodeIssueSearch.call(knex, {
      params,
      logTrace
    });
    return response;
  };

}

module.exports = {
  getItemService,
  postItemService,
  putItemService,
  deleteItemService,
  getItemInfoService,
  getItemPaginateService,
  getItemCodeService,
  getItemSearchService,
  getBarcodeSearchService,
  getBarcodeSearchClosingStockService,
  getBarcodeIssueSearchService,
  getItemOutletService,
  getItemInfoWithProcodeService,
  putItemDiscountService,
  getItemPurchaseProductService,
  getItemDetailsOutletsSalesProductService
};
