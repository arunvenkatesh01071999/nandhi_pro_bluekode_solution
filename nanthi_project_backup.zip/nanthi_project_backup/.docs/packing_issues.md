# Purchase Module Logics

## Tables

    1. packing_issue_master
        - id
        - docno
        - docdate
        - whid
        - total_items
        - total_qty
        - created_by
        - updated_by
        - created_at
        - updated_at

    2. packing_issue_details
        - id
        - issue_mst_id
        - docno
        - docdate
        - prodid
        - whid
        - total_qty
        - created_by
        - updated_by
        - created_at
        - updated_at
