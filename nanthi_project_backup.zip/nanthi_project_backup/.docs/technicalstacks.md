# TECHNOLOGY STACK
# Back End APIs
    1. Node JS - Fastify framework
    2. JWT Autentication 
# Front End
    1. React JS 
# Database
    1. Postgres SQL
# Source Controller
    1. Git Hub
# CI/CD Tools
    1. Jenkins
> ### Servers
    To be decided.