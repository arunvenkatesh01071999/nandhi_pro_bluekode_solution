# Purchase Orders 


## LOGICs


1. List out all the item master when balance is less than or equal to min stock by selecting supplier
2. Item masters item should be product type is equla to purchase(Bulk) 
3. List these items in sepearate screen
4. Here user can able select the items using box.
5. after slecting the item --> then click the Next button
6. 


## Tables
1. PO Masters
        - id
        - pono
        - podate 
        - supplier_id
        - total_items
        - total_order_qty
        - total_amt
        - total_gst
        - is_approved
        - is_approved_by
        - created_by
        - updated_by
        - created_at
        - updated_at

2. PO Details